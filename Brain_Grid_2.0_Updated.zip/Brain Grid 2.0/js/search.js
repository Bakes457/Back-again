/* Client-side search over the real puzzles and articles in BG_CATALOG (js/catalog.js).
   Also drives the filter controls and puzzle grid on play.html. */
(function () {
  'use strict';
  var BG = window.BG = window.BG || {};
  var U = BG.util, el = U.el;
  var CAT_NAMES = { logic: 'Logic', word: 'Word games', number: 'Number games', memory: 'Memory games', visual: 'Visual puzzles' };
  BG.catNames = CAT_NAMES;

  function allItems() {
    var c = window.BG_CATALOG || { puzzles: [], articles: [] };
    return c.puzzles.map(function (p) { return { kind: 'Puzzle', title: p.title, cat: CAT_NAMES[p.category], url: p.url, text: (p.title + ' ' + CAT_NAMES[p.category] + ' ' + p.category + ' ' + p.desc).toLowerCase(), titleLc: p.title.toLowerCase() }; })
      .concat(c.articles.map(function (a) { return { kind: 'Article', title: a.title, cat: 'Article', url: a.url, text: (a.title + ' ' + a.desc).toLowerCase(), titleLc: a.title.toLowerCase() }; }));
  }
  /* Titles starting with the query rank first, then titles containing it, then category or description matches. */
  BG.search = function (query) {
    var q = String(query || '').trim().toLowerCase();
    if (!q) return [];
    var words = q.split(/\s+/);
    return allItems().map(function (it) {
      if (!words.every(function (w) { return it.text.indexOf(w) > -1; })) return null;
      var score = it.titleLc.indexOf(q) === 0 ? 0 : it.titleLc.indexOf(q) > -1 ? 1 : words.every(function (w) { return it.titleLc.indexOf(w) > -1; }) ? 2 : 3;
      return { item: it, score: score };
    }).filter(Boolean).sort(function (a, b) { return a.score - b.score || a.item.title.localeCompare(b.item.title); }).map(function (r) { return r.item; });
  };

  function initSearchBox() {
    var input = document.getElementById('search-input'), list = document.getElementById('search-suggestions');
    if (!input || !list) return;
    var results = [], active = -1;
    function close() { list.hidden = true; input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant'); active = -1; }
    function setActive(i) {
      active = i;
      Array.prototype.forEach.call(list.querySelectorAll('li[role="option"]'), function (li, n) { li.setAttribute('aria-selected', n === i ? 'true' : 'false'); });
      if (i >= 0) input.setAttribute('aria-activedescendant', 'sugg-' + i); else input.removeAttribute('aria-activedescendant');
    }
    function open(item) { BG.go(U.root() + item.url); }
    function render() {
      var q = input.value.trim();
      list.innerHTML = '';
      if (!q) { close(); return; }
      results = BG.search(q).slice(0, 8);
      if (!results.length) {
        list.appendChild(el('li', { class: 'none', role: 'presentation', text: 'No puzzles or articles match "' + q + '". Try a category such as logic or word.' }));
      } else {
        results.forEach(function (r, i) {
          var li = el('li', { id: 'sugg-' + i, role: 'option', 'aria-selected': 'false' }, [el('span', { text: r.title }), el('span', { class: 'kind', text: r.cat })]);
          li.addEventListener('mousedown', function (e) { e.preventDefault(); open(r); });
          list.appendChild(li);
        });
      }
      list.hidden = false; input.setAttribute('aria-expanded', 'true'); setActive(-1);
    }
    input.addEventListener('input', render);
    input.addEventListener('focus', function () { if (input.value.trim()) render(); });
    input.addEventListener('blur', function () { setTimeout(close, 120); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowDown' && results.length) { e.preventDefault(); if (list.hidden) render(); setActive((active + 1) % results.length); }
      else if (e.key === 'ArrowUp' && results.length) { e.preventDefault(); setActive(active <= 0 ? results.length - 1 : active - 1); }
      else if (e.key === 'Escape') { if (!list.hidden) { e.preventDefault(); close(); } }
      else if (e.key === 'Enter') {
        e.preventDefault();
        var q = input.value.trim();
        if (!q) { input.setAttribute('aria-invalid', 'true'); announce('Type a puzzle name or category to search.'); return; }
        input.removeAttribute('aria-invalid');
        var found = active >= 0 ? results[active] : BG.search(q)[0];
        if (found) open(found); else { render(); announce('No results for ' + q + '.'); }
      }
    });
    function announce(msg) { var s = document.getElementById('search-status'); if (s) s.textContent = msg; }
  }

  /* ---- play.html: filterable puzzle grid ---- */
  var TIME_NAME = { quick: 'Quick', medium: 'Medium', long: 'Deep' };
  function puzzleCard(p) {
    var root = U.root(), icons = (window.BG_CATALOG && window.BG_CATALOG.icons) || {};
    return el('article', { class: 'card', 'data-cat': p.category }, [
      el('div', { class: 'card-art', html: icons[p.id] || '' }),
      el('div', { class: 'card-body' }, [
        el('ul', { class: 'tags' }, [el('li', { class: 'tag tag-cat', text: CAT_NAMES[p.category] }), el('li', { class: 'tag tag-time', text: TIME_NAME[p.time] || '' })]),
        el('h3', { text: p.title }),
        el('p', { text: p.desc }),
        el('div', { class: 'card-foot' }, [
          el('a', { class: 'btn btn-primary', href: root + p.url, 'aria-label': 'Play ' + p.title, text: 'Play' }),
          el('button', { type: 'button', class: 'btn btn-quiet fav-btn', 'data-fav': p.id, 'aria-pressed': 'false', 'aria-label': 'Save ' + p.title + ' to favourites', text: 'Save' })
        ])
      ])
    ]);
  }
  function initFilters() {
    var grid = document.getElementById('puzzle-grid');
    if (!grid || !window.BG_CATALOG) return;
    var cat = document.getElementById('filter-category'), diff = document.getElementById('filter-difficulty'), time = document.getElementById('filter-time');
    var count = document.getElementById('result-count'), reset = document.getElementById('filter-reset'), empty = document.getElementById('no-results');
    function apply() {
      var list = window.BG_CATALOG.puzzles.filter(function (p) {
        return (!cat.value || p.category === cat.value) && (!diff.value || p.levels.map(function (l) { return l.toLowerCase(); }).indexOf(diff.value) > -1) && (!time.value || p.time === time.value);
      });
      grid.innerHTML = '';
      list.forEach(function (p) { grid.appendChild(puzzleCard(p)); });
      empty.hidden = list.length > 0;
      count.textContent = list.length + (list.length === 1 ? ' puzzle' : ' puzzles') + ' shown';
      BG.refreshFavs(grid);
    }
    cat.addEventListener('change', apply); diff.addEventListener('change', apply); time.addEventListener('change', apply);
    reset.addEventListener('click', function () { cat.value = ''; diff.value = ''; time.value = ''; apply(); });
    var wanted = (window.location.hash || '').replace('#', '');
    if (wanted && CAT_NAMES[wanted]) cat.value = wanted;
    if (wanted === 'quick' || wanted === 'medium' || wanted === 'long') time.value = wanted;
    apply();
  }

  function init() { initSearchBox(); initFilters(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
