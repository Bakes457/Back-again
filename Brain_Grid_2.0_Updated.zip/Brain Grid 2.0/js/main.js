/* BrainGrid shared behaviour: utilities, navigation, favourites, reset dialog and small UI helpers for games. */
(function () {
  'use strict';
  var BG = window.BG = window.BG || {};
  BG.games = BG.games || {};
  var U = BG.util = {};

  U.el = function (tag, attrs, kids) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      var v = attrs[k];
      if (v === false || v === null || v === undefined) return;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'html') node.innerHTML = v;
      else if (k.slice(0, 2) === 'on') node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    });
    (kids || []).forEach(function (c) { if (c !== null && c !== undefined) node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return node;
  };
  U.hash = function (str) { var h = 2166136261; for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };
  /* Seeded random generator (mulberry32). The same seed always produces the same sequence. */
  U.rng = function (seed) {
    var a = seed >>> 0;
    return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  };
  U.shuffle = function (arr, rnd) {
    rnd = rnd || Math.random;
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(rnd() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  };
  U.pick = function (arr, rnd) { return arr[Math.floor((rnd || Math.random)() * arr.length)]; };
  U.fmtTime = function (s) { s = Math.max(0, Math.round(s)); var m = Math.floor(s / 60), x = s % 60; return m + ':' + (x < 10 ? '0' : '') + x; };
  U.root = function () { return document.body.getAttribute('data-root') || ''; };
  U.cap = function (s) { return s.charAt(0).toUpperCase() + s.slice(1); };
  BG.go = function (url) { window.location.assign(url); };

  /* ---------- Game UI helpers ---------- */
  var el = U.el;
  BG.ui = {
    /* Difficulty select + Start/New + Restart. Remembers the last difficulty per game. */
    controls: function (o) {
      var sel = el('select', { id: 'level-select' }, o.levels.map(function (l) { return el('option', { value: l.v, text: l.label }); }));
      var saved = BG.getPref(o.id, 'level');
      if (saved && o.levels.some(function (l) { return l.v === saved; })) sel.value = saved;
      var start = el('button', { type: 'button', class: 'btn btn-primary', id: 'start-btn', text: o.startLabel || 'Start' });
      var restart = el('button', { type: 'button', class: 'btn', id: 'restart-btn', text: o.restartLabel || 'Restart', disabled: true });
      var wrap = el('div', { class: 'controls' }, [el('label', { for: 'level-select', text: o.levelLabel || 'Difficulty' }), sel, start].concat(o.extra || [], [restart]));
      start.addEventListener('click', function () {
        BG.setPref(o.id, 'level', sel.value);
        start.textContent = o.newLabel || 'New puzzle';
        restart.disabled = false;
        o.onStart(sel.value);
      });
      restart.addEventListener('click', function () { if (o.onRestart) o.onRestart(sel.value); });
      return { el: wrap, level: function () { return sel.value; }, select: sel, startBtn: start, restartBtn: restart };
    },
    status: function () {
      var node = el('div', { class: 'status', role: 'status', 'aria-live': 'polite' });
      return {
        el: node,
        say: function (msg, kind) {
          node.className = 'status' + (kind === 'ok' ? ' status-ok' : kind === 'bad' ? ' status-bad' : '');
          node.textContent = '';
          var lead = kind === 'ok' ? 'Correct.' : kind === 'bad' ? 'Not quite.' : '';
          if (lead) node.appendChild(el('strong', { text: lead }));
          node.appendChild(document.createTextNode(msg));
        },
        clear: function () { node.className = 'status'; node.textContent = ''; }
      };
    },
    /* Completion panel. Focus moves to it so screen reader users hear the result. */
    result: function (host, title, lines, actions, noFocus) {
      host.innerHTML = '';
      var panel = el('section', { class: 'result', tabindex: '-1', 'aria-labelledby': 'result-title' }, [el('h2', { id: 'result-title', text: title })]);
      lines.forEach(function (l) { panel.appendChild(el('p', { text: l })); });
      if (actions && actions.length) panel.appendChild(el('div', { class: 'btn-row' }, actions));
      host.appendChild(panel);
      if (!noFocus) panel.focus();
      return panel;
    },
    clearResult: function (host) { host.innerHTML = ''; },
    meter: function (value, max) { var pct = max ? Math.round(100 * value / max) : 0; return el('div', { class: 'meter meter-light', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': String(max), 'aria-valuenow': String(value) }, [el('span', { style: 'width:' + pct + '%' })]); },
    normalise: function (s) { return String(s).toLowerCase().replace(/[^a-z0-9\-]/g, ''); }
  };

  /* ---------- Reset progress ---------- */
  BG.confirmReset = function (done) {
    function finish() {
      BG.resetAll();
      if (done) done();
      var ev = document.createEvent('Event'); ev.initEvent('braingrid:reset', true, false); document.dispatchEvent(ev);
    }
    var dlg = document.getElementById('reset-dialog');
    if (!dlg) {
      dlg = el('dialog', { id: 'reset-dialog', 'aria-labelledby': 'reset-title' }, [
        el('h2', { id: 'reset-title', text: 'Delete all saved data?' }),
        el('p', { text: 'This permanently deletes the daily history, streak, personal bests, favourites, preferences and your cookie choice saved in this browser. It cannot be undone.' }),
        el('div', { class: 'btn-row' }, [
          el('button', { type: 'button', class: 'btn btn-danger', 'data-confirm': '1', text: 'Yes, delete everything' }),
          el('button', { type: 'button', class: 'btn', 'data-cancel': '1', text: 'Cancel' })
        ])
      ]);
      document.body.appendChild(dlg);
      dlg.addEventListener('click', function (e) {
        if (e.target.closest('[data-cancel]')) dlg.close();
        if (e.target.closest('[data-confirm]')) { dlg.close(); if (dlg._finish) dlg._finish(); }
      });
    }
    dlg._finish = finish;
    if (typeof dlg.showModal === 'function') dlg.showModal();
    else if (window.confirm('Delete all BrainGrid data saved in this browser? This cannot be undone.')) finish();
  };

  /* ---------- Favourites ---------- */
  BG.refreshFavs = function (scope) {
    var favs = BG.getFavs();
    (scope || document).querySelectorAll('[data-fav]').forEach(function (b) {
      var on = favs.indexOf(b.getAttribute('data-fav')) > -1;
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
      b.textContent = on ? 'Saved' : 'Save';
    });
  };

  function initNav() {
    var btn = document.getElementById('nav-toggle'), nav = document.getElementById('site-nav');
    var catBtn = document.getElementById('cat-toggle'), catMenu = document.getElementById('cat-menu');
    function setCat(open) { if (!catBtn) return; catBtn.setAttribute('aria-expanded', open ? 'true' : 'false'); catMenu.hidden = !open; }
    function setNav(open) { if (!btn) return; btn.setAttribute('aria-expanded', open ? 'true' : 'false'); nav.classList.toggle('is-open', open); }
    if (catBtn) { setCat(false); catBtn.addEventListener('click', function () { setCat(catBtn.getAttribute('aria-expanded') !== 'true'); }); }
    if (btn) btn.addEventListener('click', function () { setNav(btn.getAttribute('aria-expanded') !== 'true'); });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (catBtn && catBtn.getAttribute('aria-expanded') === 'true') { setCat(false); catBtn.focus(); return; }
      if (btn && btn.getAttribute('aria-expanded') === 'true') { setNav(false); btn.focus(); }
    });
    document.addEventListener('click', function (e) {
      if (catBtn && !e.target.closest('.has-sub')) setCat(false);
      if (btn && nav.classList.contains('is-open') && !e.target.closest('.site-header')) setNav(false);
    });
  }

  /* Theme: follows the device by default; the header button saves an explicit light or dark choice. */
  function effectiveTheme() {
    var t = document.documentElement.getAttribute('data-theme');
    if (t === 'dark' || t === 'light') return t;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  function initTheme() {
    var btn = document.getElementById('theme-toggle'); if (!btn) return;
    var saved = BG.getPref('site', 'theme'); if (saved === 'dark' || saved === 'light') document.documentElement.setAttribute('data-theme', saved);
    function label() { btn.setAttribute('aria-label', effectiveTheme() === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'); }
    btn.addEventListener('click', function () {
      var next = effectiveTheme() === 'dark' ? 'light' : 'dark';
      document.documentElement.setAttribute('data-theme', next); BG.setPref('site', 'theme', next); label();
    });
    label();
  }

  function init() {
    document.documentElement.classList.add('js');
    initTheme();
    initNav();
    BG.refreshFavs();
    document.addEventListener('click', function (e) {
      var fav = e.target.closest('[data-fav]');
      if (fav) { BG.toggleFav(fav.getAttribute('data-fav')); BG.refreshFavs(); return; }
      var rnd = e.target.closest('[data-random-puzzle]');
      if (rnd && window.BG_CATALOG) {
        e.preventDefault();
        var cat = rnd.getAttribute('data-random-puzzle');
        var pool = window.BG_CATALOG.puzzles.filter(function (p) { return !cat || cat === 'all' || p.category === cat; });
        BG.go(U.root() + U.pick(pool).url);
        return;
      }
      if (e.target.closest('[data-reset-progress]')) BG.confirmReset();
    });
    /* Keep the instructions out of the way on small screens; the summary stays one tap away. */
    if (window.innerWidth < 700) document.querySelectorAll('details.how-to[open]').forEach(function (n) { n.removeAttribute('open'); });
    var game = document.body.getAttribute('data-game');
    if (game) BG.addRecent(game);
    var warn = document.getElementById('storage-warning');
    if (warn && !BG.available) warn.hidden = false;
    document.querySelectorAll('[data-today]').forEach(function (n) {
      n.textContent = new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
