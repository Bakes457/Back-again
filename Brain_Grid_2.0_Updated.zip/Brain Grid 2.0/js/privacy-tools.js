/* Data deletion page: shows what BrainGrid holds in this browser, lets the visitor download or delete it,
   withdraw ad consent, and prepare an email request. BrainGrid keeps nothing on a server. */
(function () {
  'use strict';
  var BG = window.BG = window.BG || {};
  var U = BG.util, el = U.el;
  BG.privacy = {};
  var WHAT = {
    braingrid_daily: 'Which daily puzzles you completed, by date', braingrid_streak: 'Your daily streak',
    braingrid_best: 'Your best score for each game', braingrid_recent: 'Games you played recently',
    braingrid_favs: 'Games you saved as favourites', braingrid_prefs: 'Settings such as last difficulty',
    braingrid_consent: 'Your cookie and advertising choice'
  };
  BG.privacy.buildExport = function () {
    return JSON.stringify({ site: 'BrainGrid', note: 'Everything BrainGrid has saved in this browser. Nothing here is stored on a server.', exported: new Date().toISOString(), data: BG.exportData() }, null, 2);
  };
  /* Contact form: opens the visitor's own email app with a draft. */
  var cf = document.getElementById('contact-form');
  if (cf) {
    var cstatus = document.getElementById('contact-status');
    cf.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!BG.contactEmail) { cstatus.className = 'status status-bad'; cstatus.textContent = 'No contact address has been published for this site yet, so an email cannot be prepared.'; return; }
      var topic = document.getElementById('contact-topic').value, msg = document.getElementById('contact-message').value.trim();
      BG.go('mailto:' + BG.contactEmail + '?subject=' + encodeURIComponent('BrainGrid: ' + topic) + '&body=' + encodeURIComponent(msg + '\n'));
      cstatus.className = 'status'; cstatus.textContent = 'Your email app should open with a draft. Nothing has been sent yet.';
    });
  }
  var root = document.getElementById('data-tool');
  if (!root) return;
  var status = BG.ui.status(), inventory = document.getElementById('inventory');
  function drawInventory() {
    var data = BG.exportData(), keys = Object.keys(data);
    inventory.innerHTML = '';
    if (!keys.length) { inventory.appendChild(el('p', { class: 'placeholder-box', text: 'BrainGrid has nothing saved in this browser right now.' })); return; }
    inventory.appendChild(el('div', { class: 'table-wrap' }, [el('table', { class: 'data' }, [
      el('thead', {}, [el('tr', {}, ['Saved item', 'What it is', 'Size'].map(function (h) { return el('th', { scope: 'col', text: h }); }))]),
      el('tbody', {}, keys.map(function (k) { return el('tr', {}, [el('td', {}, [el('code', { text: k })]), el('td', { text: WHAT[k] || 'BrainGrid data' }), el('td', { text: JSON.stringify(data[k]).length + ' characters' })]); }))])]));
  }
  drawInventory();
  document.getElementById('download-data').addEventListener('click', function () {
    try {
      var blob = new Blob([BG.privacy.buildExport()], { type: 'application/json' });
      var a = el('a', { href: URL.createObjectURL(blob), download: 'braingrid-data.json' });
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      status.say('A copy of your data was downloaded as braingrid-data.json. It was created in your browser and was not uploaded anywhere.', 'info');
    } catch (e) { status.say('Your browser could not create the download. The table above shows everything that is saved.', 'bad'); }
  });
  document.getElementById('delete-data').addEventListener('click', function () {
    BG.confirmReset(function () { drawInventory(); status.say('Everything BrainGrid had saved in this browser has been deleted.', 'ok'); });
  });
  var withdraw = document.getElementById('withdraw-consent');
  if (BG.ads.enabled) withdraw.hidden = false;
  withdraw.addEventListener('click', function () { BG.ads.choose('none'); drawInventory(); status.say('Ad consent withdrawn. No ad script will load on this site from now on.', 'ok'); });
  /* Email request: opens the visitor's own email app. Nothing is sent by BrainGrid. */
  var form = document.getElementById('request-form');
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!BG.contactEmail) { status.say('No contact address has been published for this site yet, so an email cannot be prepared. You can still delete or download your data with the buttons above.', 'bad'); return; }
    var type = form.querySelector('input[name="req"]:checked').value, note = form.querySelector('#req-note').value.trim();
    var body = 'Request: ' + type + '\n\n' + (note ? 'Details: ' + note + '\n\n' : '') + 'Please do not send passwords or payment details.\n';
    BG.go('mailto:' + BG.contactEmail + '?subject=' + encodeURIComponent('BrainGrid data request: ' + type) + '&body=' + encodeURIComponent(body));
    status.say('Your email app should open with a draft addressed to the site owner. Nothing has been sent yet.', 'info');
  });
  root.appendChild(status.el);
  document.addEventListener('braingrid:reset', drawInventory);
})();
