/* BrainGrid storage layer. Everything is saved in this browser only, under the "braingrid_" prefix.
   Stored data is validated on every read, so missing or corrupted values fall back to safe defaults.
   If LocalStorage is blocked, data lives in memory for the current page only. */
(function () {
  'use strict';
  var BG = window.BG = window.BG || {};
  var NS = 'braingrid_';
  var memory = {};
  var KEYS = ['daily', 'streak', 'best', 'recent', 'favs', 'prefs', 'consent'];

  BG.available = (function () {
    try {
      var k = NS + 'probe';
      window.localStorage.setItem(k, '1');
      window.localStorage.removeItem(k);
      return true;
    } catch (e) { return false; }
  })();

  function rawGet(key) {
    if (BG.available) { try { return window.localStorage.getItem(NS + key); } catch (e) { /* fall through */ } }
    return Object.prototype.hasOwnProperty.call(memory, key) ? memory[key] : null;
  }
  function rawSet(key, text) {
    if (BG.available) { try { window.localStorage.setItem(NS + key, text); return; } catch (e) { /* use memory */ } }
    memory[key] = text;
  }
  function isPlainObject(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
  function load(key, validate, fallback) {
    var raw = rawGet(key);
    if (raw === null) return fallback();
    try {
      var value = JSON.parse(raw);
      return validate(value) ? value : fallback();
    } catch (e) { return fallback(); }
  }
  function save(key, value) { rawSet(key, JSON.stringify(value)); }

  var CATS = ['logic', 'word', 'number', 'visual', 'memory'];
  BG.dailyCategories = CATS;

  /* Local calendar date as YYYY-MM-DD. Not UTC, so "today" follows the visitor's own clock. */
  BG.dateKey = function (d) {
    d = d || new Date();
    var m = d.getMonth() + 1, day = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (day < 10 ? '0' : '') + day;
  };
  function yesterdayKey() { var d = new Date(); return BG.dateKey(new Date(d.getFullYear(), d.getMonth(), d.getDate() - 1)); }

  /* Daily progress: { "2025-01-31": { logic: true, word: true } } (only the last 45 days are kept) */
  function validDaily(v) {
    if (!isPlainObject(v)) return false;
    return Object.keys(v).every(function (k) {
      return /^\d{4}-\d{2}-\d{2}$/.test(k) && isPlainObject(v[k]) && Object.keys(v[k]).every(function (c) { return CATS.indexOf(c) > -1 && typeof v[k][c] === 'boolean'; });
    });
  }
  BG.getDaily = function (key) {
    var all = load('daily', validDaily, function () { return {}; });
    var day = all[key || BG.dateKey()] || {};
    var out = {}; CATS.forEach(function (c) { out[c] = day[c] === true; });
    return out;
  };
  BG.dailyCount = function (key) { var d = BG.getDaily(key); return CATS.filter(function (c) { return d[c]; }).length; };

  function validStreak(v) { return isPlainObject(v) && Number.isInteger(v.count) && v.count >= 0 && typeof v.last === 'string' && (v.last === '' || /^\d{4}-\d{2}-\d{2}$/.test(v.last)); }
  function readStreak() { return load('streak', validStreak, function () { return { count: 0, last: '' }; }); }
  /* The streak counts consecutive local days on which all five daily puzzles were completed. */
  BG.getStreak = function () {
    var s = readStreak();
    return (s.last === BG.dateKey() || s.last === yesterdayKey()) ? s.count : 0;
  };

  BG.markDaily = function (cat) {
    if (CATS.indexOf(cat) < 0) return false;
    var all = load('daily', validDaily, function () { return {}; });
    var key = BG.dateKey();
    all[key] = all[key] || {};
    all[key][cat] = true;
    var keys = Object.keys(all).sort();
    while (keys.length > 45) delete all[keys.shift()];
    save('daily', all);
    if (BG.dailyCount(key) === CATS.length) {
      var s = readStreak();
      if (s.last !== key) { save('streak', { count: s.last === yesterdayKey() ? s.count + 1 : 1, last: key }); }
    }
    return true;
  };

  /* Personal bests: { "sudoku:easy": { score: 312, label: "5:12", dir: "low", date: "2025-01-31" } } */
  function validBest(v) {
    return isPlainObject(v) && Object.keys(v).every(function (k) {
      var e = v[k];
      return isPlainObject(e) && typeof e.score === 'number' && isFinite(e.score) && typeof e.label === 'string' && (e.dir === 'low' || e.dir === 'high') && typeof e.date === 'string';
    });
  }
  BG.getBest = function () { return load('best', validBest, function () { return {}; }); };
  /* dir "low" means a smaller score is better (time, moves); "high" means bigger is better. Returns true on a new best. */
  BG.recordBest = function (id, score, label, dir) {
    if (typeof id !== 'string' || typeof score !== 'number' || !isFinite(score)) return false;
    var all = BG.getBest(), old = all[id];
    var better = !old || (dir === 'low' ? score < old.score : score > old.score);
    if (better) {
      all[id] = { score: score, label: String(label), dir: dir === 'low' ? 'low' : 'high', date: BG.dateKey() };
      save('best', all);
    }
    return better;
  };

  function validIdList(v) { return Array.isArray(v) && v.every(function (x) { return typeof x === 'string' && x.length < 60; }); }
  BG.getRecent = function () { return load('recent', validIdList, function () { return []; }); };
  BG.addRecent = function (id) {
    var list = BG.getRecent().filter(function (x) { return x !== id; });
    list.unshift(id);
    save('recent', list.slice(0, 8));
  };
  BG.getFavs = function () { return load('favs', validIdList, function () { return []; }); };
  BG.toggleFav = function (id) {
    var list = BG.getFavs(), i = list.indexOf(id);
    if (i > -1) list.splice(i, 1); else list.push(id);
    save('favs', list);
    return i < 0;
  };

  /* Small preferences such as the last difficulty chosen for each game. */
  function validPrefs(v) { return isPlainObject(v) && Object.keys(v).every(function (k) { return isPlainObject(v[k]); }); }
  BG.getPref = function (game, name) {
    var p = load('prefs', validPrefs, function () { return {}; });
    var v = p[game] && p[game][name];
    return (typeof v === 'string' || typeof v === 'boolean') ? v : null;
  };
  BG.setPref = function (game, name, value) {
    var p = load('prefs', validPrefs, function () { return {}; });
    p[game] = p[game] || {};
    p[game][name] = value;
    save('prefs', p);
  };

  /* Cookie / advertising choice: { ads: "all" | "nonpersonal" | "none", date }. null means the visitor has not chosen yet. */
  var CONSENT_MODES = ['all', 'nonpersonal', 'none'];
  BG.consentModes = CONSENT_MODES;
  BG.getConsent = function () {
    return load('consent', function (v) { return isPlainObject(v) && CONSENT_MODES.indexOf(v.ads) > -1 && typeof v.date === 'string'; }, function () { return null; });
  };
  BG.setConsent = function (mode) {
    if (CONSENT_MODES.indexOf(mode) < 0) return false;
    save('consent', { ads: mode, date: BG.dateKey() });
    return true;
  };
  /* A copy of everything BrainGrid has saved in this browser (used by the "download my data" button). */
  BG.exportData = function () {
    var out = {};
    KEYS.forEach(function (k) {
      var raw = rawGet(k);
      if (raw === null) return;
      try { out[NS + k] = JSON.parse(raw); } catch (e) { out[NS + k] = '[unreadable value]'; }
    });
    return out;
  };

  BG.resetAll = function () {
    KEYS.forEach(function (k) {
      delete memory[k];
      if (BG.available) { try { window.localStorage.removeItem(NS + k); } catch (e) { /* ignore */ } }
    });
  };
})();
