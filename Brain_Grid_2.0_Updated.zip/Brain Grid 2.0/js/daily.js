/* Daily Challenge: five puzzles chosen from the visitor's LOCAL calendar date, with progress saved in this browser.
   Same date + same puzzle banks = same puzzles, so a refresh never changes today's set. */
(function () {
  'use strict';
  var BG = window.BG = window.BG || {};
  var U = BG.util, el = U.el, P = BG.pools;
  var TITLES = { logic: 'Logic', word: 'Word', number: 'Number', visual: 'Visual', memory: 'Memory' };
  var MORE = { logic: ['games/logic-grid.html', 'Play the Logic Grid'], word: ['games/anagram.html', 'Play Anagram Challenge'], number: ['games/number-sequence.html', 'Play Number Sequence'], visual: ['games/pattern-completion.html', 'Play Pattern Completion'], memory: ['games/memory-match.html', 'Play Memory Match'] };

  /* ----- Homepage preview: progress ring, one dot per category, streak ----- */
  function initPreview() {
    var host = document.getElementById('daily-preview');
    if (!host) return;
    var d = BG.getDaily(), n = BG.dailyCount();
    Array.prototype.forEach.call(host.querySelectorAll('[data-cat]'), function (li) {
      var done = d[li.getAttribute('data-cat')];
      li.classList.toggle('done', !!done);
      li.setAttribute('aria-label', li.textContent.replace(/ \(.*\)$/, '') + (done ? ' puzzle: done' : ' puzzle: not started'));
      li.textContent = li.textContent.replace(/ \(.*\)$/, '') + (done ? ' (done)' : '');
    });
    var fg = document.querySelector('#today-ring .fg'), cnt = document.getElementById('ring-count');
    if (fg) fg.style.strokeDashoffset = String(289 - 289 * n / 5);
    if (cnt) cnt.textContent = n + '/5';
    var ring = document.getElementById('today-ring');
    if (ring) { ring.setAttribute('role', 'img'); ring.setAttribute('aria-label', n + ' of 5 daily puzzles completed today'); }
    var s = BG.getStreak(), line = document.getElementById('streak-line');
    if (line) line.textContent = s > 0 ? 'Daily streak: ' + s + (s === 1 ? ' day' : ' days') + '. Finish today to keep it going.' : 'Finish all five to start a daily streak. Progress is saved on this device only.';
  }

  /* ----- Shared answer widgets ----- */
  function revealBtn(onClick) { return el('button', { type: 'button', class: 'btn btn-quiet btn-small', text: 'Show the answer', onclick: onClick }); }

  /* Multiple-choice question. Clicking an option answers it. */
  function mcq(spec, onSolved) {
    var status = BG.ui.status(), wrong = 0, finished = false;
    var wrap = el('div', {});
    var group = el('div', { class: 'options', role: 'group', 'aria-label': 'Answer choices' });
    var buttons = spec.options.map(function (o, i) {
      var b = el('button', { type: 'button', class: 'option' });
      if (o.svg) { b.innerHTML = o.svg + '<span>' + o.label + '</span>'; } else { b.textContent = o.label; }
      b.addEventListener('click', function () {
        if (finished) return;
        if (i === spec.answerIndex) {
          finished = true; buttons.forEach(function (x) { x.disabled = true; }); b.classList.add('is-right');
          status.say(spec.why, 'ok'); extra.innerHTML = ''; onSolved();
        } else {
          wrong++; b.classList.add('is-wrong'); b.disabled = true;
          status.say('That is not the answer. Pick another option.', 'bad');
          if (wrong >= 2 && !extra.firstChild) extra.appendChild(revealBtn(reveal));
        }
      });
      group.appendChild(b); return b;
    });
    var extra = el('div', { class: 'btn-row' });
    function reveal() {
      finished = true; buttons.forEach(function (x, i) { x.disabled = true; if (i === spec.answerIndex) x.classList.add('is-right'); });
      status.say('Answer shown. ' + spec.why + ' A revealed answer does not count toward today\'s total.', 'info'); extra.innerHTML = '';
    }
    wrap.appendChild(group); wrap.appendChild(extra); wrap.appendChild(status.el);
    return wrap;
  }

  /* Typed answer with check, optional hint and reveal. */
  function textQuestion(spec, onSolved) {
    var status = BG.ui.status(), wrong = 0, finished = false, uniq = 'ans-' + Math.random().toString(36).slice(2, 7);
    var input = el('input', { type: 'text', id: uniq, autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', inputmode: spec.inputmode || 'text' });
    var extra = el('div', { class: 'btn-row' });
    var checkBtn = el('button', { type: 'submit', class: 'btn btn-primary', text: 'Check answer' });
    var hintBtn = spec.hint ? el('button', { type: 'button', class: 'btn btn-quiet', text: 'Hint', onclick: function () { status.say('Hint: ' + spec.hint, 'info'); } }) : null;
    var form = el('form', { class: 'answer-row', novalidate: 'novalidate' }, [el('div', { class: 'field' }, [el('label', { for: uniq, text: spec.label }), input]), checkBtn, hintBtn]);
    function lock() { finished = true; input.disabled = true; checkBtn.disabled = true; if (hintBtn) hintBtn.disabled = true; extra.innerHTML = ''; }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (finished) return;
      var raw = input.value.trim();
      if (!raw) { status.say('Type your answer first.', 'bad'); input.focus(); return; }
      if (spec.check(raw)) { lock(); status.say(spec.why, 'ok'); onSolved(); }
      else { wrong++; status.say('That is not it. Try again.', 'bad'); input.select(); if (wrong >= 2 && !extra.firstChild) extra.appendChild(revealBtn(function () { lock(); status.say('The answer is ' + spec.answerText + '. ' + spec.why + ' A revealed answer does not count toward today\'s total.', 'info'); })); }
    });
    var wrap = el('div', {}, [form, extra, status.el]);
    return wrap;
  }

  /* ----- Builders for each of the five categories ----- */
  function buildLogic(d) {
    return [el('p', { class: 'big-prompt', text: d.q })].concat([function (done) {
      return mcq({ options: d.o.map(function (t) { return { label: t }; }), answerIndex: d.a, why: d.why }, done);
    }]);
  }
  function buildWord(d) {
    var letters = el('div', { class: 'tiles', role: 'img', 'aria-label': 'Scrambled letters: ' + d.scrambled.toUpperCase().split('').join(' ') }, d.scrambled.toUpperCase().split('').map(function (ch) { return el('span', { class: 'tile', 'aria-hidden': 'true', text: ch }); }));
    return [el('p', { text: 'Unscramble these ' + d.word.length + ' letters to make a word.' }), letters, function (done) {
      return textQuestion({ label: 'Your word', hint: d.hint, answerText: d.word.toUpperCase(), check: function (r) { return BG.ui.normalise(r) === d.word; }, why: 'The word is ' + d.word.toUpperCase() + '.' }, done);
    }];
  }
  function buildNumber(d) {
    return [el('p', { text: 'Pattern type hidden. What number comes next?' }), el('p', { class: 'big-prompt', text: d.shown.join(',  ') + ',  ?' }), function (done) {
      return textQuestion({ label: 'Next number', inputmode: 'numeric', hint: 'Look at the gaps between neighbouring numbers, or at what each number is multiplied by.', answerText: String(d.answer), check: function (r) { return /^-?\d+$/.test(r.replace(/\s/g, '')) && parseInt(r, 10) === d.answer; }, why: d.why }, done);
    }];
  }
  function buildVisual(d) {
    var seq = el('ol', { class: 'pattern-seq', 'aria-label': 'Pattern sequence' }, d.seq.map(function (it, i) {
      if (i === d.hidden) return el('li', { class: 'is-gap', 'aria-label': 'missing item', text: '?' });
      return el('li', { 'aria-label': P.describeItem(it), html: P.itemSvg(it) });
    }));
    return [el('p', { text: 'Which option fills the gap marked with a question mark?' }), seq, function (done) {
      return mcq({ options: d.options.map(function (it) { return { svg: P.itemSvg(it), label: P.describeItem(it) }; }), answerIndex: d.answerIndex, why: d.why }, done);
    }];
  }
  function buildMemory(d) {
    var host = el('div', {});
    var more = el('input', { type: 'checkbox', id: 'extra-time' });
    var startBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Show the symbols' });
    var intro = el('div', {}, [el('p', { text: 'Five symbols will appear in a row. Memorise their order, then answer one question about them.' }), el('p', {}, [more, ' ', el('label', { for: 'extra-time', text: 'Give me extra time (20 seconds instead of 10)' })]), startBtn]);
    host.appendChild(intro);
    function showQuestion(done) {
      host.innerHTML = '';
      host.appendChild(el('p', { class: 'big-prompt', text: 'Which symbol was in the ' + P.ordinal(d.askIdx) + ' position?' }));
      host.appendChild(mcq({ options: d.options.map(function (s) { return { label: s.g + ' ' + s.n }; }), answerIndex: d.answerIndex, why: 'The ' + P.ordinal(d.askIdx) + ' symbol was the ' + d.seq[d.askIdx].n.toLowerCase() + '. The full order was ' + d.seq.map(function (s) { return s.n.toLowerCase(); }).join(', ') + '.' }, done));
    }
    return [host, function (done) {
      startBtn.addEventListener('click', function () {
        var secs = more.checked ? 20 : 10;
        host.innerHTML = '';
        var tiles = el('div', { class: 'recall-symbols', role: 'list', 'aria-label': 'Symbols to memorise' }, d.seq.map(function (s, i) { return el('div', { class: 'tile', role: 'listitem' }, [el('span', { 'aria-hidden': 'true', text: s.g }), el('small', { text: (i + 1) + '. ' + s.n })]); }));
        var timer = el('p', { text: 'Memorise the order. The symbols hide in ' + secs + ' seconds.' });
        host.appendChild(tiles); host.appendChild(timer);
        var left = secs, iv = setInterval(function () {
          left--; timer.textContent = left > 0 ? 'The symbols hide in ' + left + ' seconds.' : '';
          if (left <= 0) { clearInterval(iv); showQuestion(done); }
        }, 1000);
      });
      return document.createDocumentFragment();
    }];
  }

  /* ----- Full page ----- */
  function initFull() {
    var host = document.getElementById('daily-app');
    if (!host) return;
    var today = BG.dateKey(), daily = P.dailyFor(today);
    var builders = { logic: buildLogic, word: buildWord, number: buildNumber, visual: buildVisual, memory: buildMemory };
    var badges = {}, sections = {};
    var meterWrap = el('div', { class: 'progress-line' });
    var countText = el('span', { 'aria-live': 'polite' });
    var streakEl = el('p', { class: 'muted small' });
    var completion = el('div', { id: 'daily-complete' });
    host.appendChild(el('p', { class: 'muted' }, ['Puzzles for ', el('strong', { 'data-today': '' }), '. They follow the date on this device\'s clock.']));
    host.appendChild(meterWrap); host.appendChild(streakEl); host.appendChild(completion);

    function refresh(announceDone) {
      var d = BG.getDaily(today), n = BG.dailyCount(today);
      meterWrap.innerHTML = '';
      meterWrap.appendChild(el('span', { text: 'Progress' }));
      meterWrap.appendChild(BG.ui.meter(n, 5));
      meterWrap.appendChild(countText);
      countText.textContent = n + ' of 5 done';
      var s = BG.getStreak();
      streakEl.textContent = s > 0 ? 'Daily streak: ' + s + (s === 1 ? ' day' : ' days') + ' in a row with all five puzzles completed.' : 'Complete all five puzzles to start a daily streak.';
      BG.dailyCategories.forEach(function (c) {
        badges[c].textContent = d[c] ? 'Completed' : 'To do';
        badges[c].className = 'badge' + (d[c] ? ' badge-done' : '');
        sections[c].classList.toggle('is-done', d[c]);
      });
      completion.innerHTML = '';
      if (n === 5) {
        BG.ui.result(completion, 'All five puzzles complete', ['Nice work. You finished today\'s challenge' + (s > 1 ? ' and your streak is now ' + s + ' days.' : '.'), 'A new set appears when your local date changes. Your progress is saved on this browser and device only.'], [el('a', { class: 'btn btn-primary', href: 'play.html', text: 'Play more puzzles' }), el('a', { class: 'btn', href: 'leaderboard.html', text: 'View my progress' })], !announceDone);
      }
    }

    BG.dailyCategories.forEach(function (cat) {
      var parts = builders[cat](daily[cat]);
      var badge = el('span', { class: 'badge', text: 'To do' }); badges[cat] = badge;
      var body = el('div', {});
      var section = el('section', { class: 'daily-item', 'aria-labelledby': 'daily-h-' + cat }, [el('h2', { id: 'daily-h-' + cat }, [TITLES[cat] + ' puzzle', badge]), body]);
      sections[cat] = section;
      var wasDone = BG.getDaily(today)[cat];
      parts.forEach(function (p) {
        if (typeof p === 'function') body.appendChild(p(function () { BG.markDaily(cat); refresh(true); }));
        else body.appendChild(p);
      });
      if (wasDone) {
        body.appendChild(el('p', { class: 'explain', text: 'You already completed this puzzle today. You can still play it again below, but it will not change your total.' }));
      }
      var link = MORE[cat];
      body.appendChild(el('p', { class: 'small', style: 'margin-top:1rem' }, [el('a', { href: link[0], text: link[1] + ' for more' })]));
      host.appendChild(section);
    });
    refresh(false);
    document.querySelectorAll('[data-today]').forEach(function (n) { n.textContent = new Date().toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }); });
    document.addEventListener('visibilitychange', function () { if (!document.hidden && BG.dateKey() !== today) window.location.reload(); });
    document.addEventListener('braingrid:reset', function () { window.location.reload(); });
  }

  function init() { initPreview(); initFull(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
