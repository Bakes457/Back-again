/* Cookie and advertising choices, and the Google AdSense loader.
   - Ads are OFF unless js/config.js holds a valid publisher ID.
   - When ads are on, NOTHING is requested from Google until the visitor chooses "Accept all" or
     "Non-personalized ads only". "Reject" loads no ad script at all.
   - The choice is saved as braingrid_consent and can be changed any time from "Cookie settings" in the footer. */
(function () {
  'use strict';
  var BG = window.BG = window.BG || {};
  var U = BG.util, el = U.el;
  var cfg = window.BG_CONFIG || {};
  var ID_RE = /^ca-pub-\d{10,20}$/, SLOT_RE = /^\d{6,20}$/;
  var hasSlot = ['content', 'article'].some(function (n) { return SLOT_RE.test(String((cfg.adSlots || {})[n] || '')); });
  /* Ads switch on only with a valid publisher ID AND either an ad unit ID or auto ads. Until then the site shows no banner and loads nothing. */
  BG.ads = { enabled: ID_RE.test(String(cfg.adsensePublisherId || '')) && (hasSlot || cfg.autoAds === true), loaded: false, publisherId: String(cfg.adsensePublisherId || '') };
  BG.contactEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(cfg.contactEmail || '')) ? String(cfg.contactEmail) : '';
  BG.ownerName = String(cfg.ownerName || '').trim().slice(0, 80);
  BG.reloadPage = function () { window.location.reload(); };

  function fillSlot(slot) {
    var id = String((cfg.adSlots || {})[slot.getAttribute('data-ad')] || '');
    if (!SLOT_RE.test(id) || slot.getAttribute('data-filled')) return;
    slot.setAttribute('data-filled', '1');
    slot.appendChild(el('p', { class: 'ad-label', text: 'Advertisement' }));
    slot.appendChild(el('ins', { class: 'adsbygoogle', style: 'display:block', 'data-ad-client': BG.ads.publisherId, 'data-ad-slot': id, 'data-ad-format': 'auto', 'data-full-width-responsive': 'true' }));
    slot.classList.add('is-live');
    try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) { /* ad blockers can throw here; the page keeps working */ }
  }
  function loadAds(mode) {
    if (!BG.ads.enabled || BG.ads.loaded || mode === 'none') return;
    BG.ads.loaded = true;
    window.adsbygoogle = window.adsbygoogle || [];
    if (mode === 'nonpersonal') window.adsbygoogle.requestNonPersonalizedAds = 1;
    var s = document.createElement('script');
    s.async = true; s.crossOrigin = 'anonymous';
    s.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(BG.ads.publisherId);
    document.head.appendChild(s);
    document.querySelectorAll('.ad-slot[data-ad]').forEach(fillSlot);
  }

  var LABELS = { all: 'Accept all', nonpersonal: 'Non-personalized ads only', none: 'Reject' };
  function closeBanner() {
    var b = document.getElementById('consent-banner');
    if (b && b.parentNode) b.parentNode.removeChild(b);
    document.body.style.paddingBottom = '';
  }
  function choose(mode) {
    var wasLoaded = BG.ads.loaded;
    BG.setConsent(mode);
    closeBanner();
    if (mode === 'none') { if (wasLoaded) BG.reloadPage(); return; }
    if (wasLoaded) { BG.reloadPage(); return; } /* switching modes after the ad script ran needs a clean page */
    loadAds(mode);
  }
  BG.ads.choose = choose;
  function showBanner() {
    if (!BG.ads.enabled || document.getElementById('consent-banner')) return;
    var root = U.root(), current = BG.getConsent();
    var buttons = BG.consentModes.map(function (m) {
      return el('button', { type: 'button', class: 'btn', 'data-consent': m, 'aria-pressed': current && current.ads === m ? 'true' : 'false', text: LABELS[m], onclick: function () { choose(m); } });
    });
    var text = el('div', { class: 'consent-text' }, [
      el('p', { class: 'consent-title', text: 'Cookies and ads' }),
      el('p', {}, ['BrainGrid is free and can show ads from Google AdSense, which use cookies. The puzzles work whichever option you pick. Nothing is sent to Google until you choose. ',
        el('a', { href: root + 'cookie-policy.html', text: 'Cookie policy' }), ' and ', el('a', { href: root + 'privacy.html', text: 'privacy policy' }), '.']),
      current ? el('p', { class: 'small muted', text: 'Your current choice: ' + LABELS[current.ads] + '.' }) : null
    ]);
    var banner = el('section', { id: 'consent-banner', class: 'consent-banner', role: 'region', 'aria-label': 'Cookie and advertising choices' }, [text, el('div', { class: 'btn-row' }, buttons)]);
    document.body.appendChild(banner);
    document.body.style.paddingBottom = banner.offsetHeight + 'px';
  }

  function init() {
    document.querySelectorAll('[data-ads-status]').forEach(function (n) {
      n.textContent = BG.ads.enabled ? 'Advertising is switched on for this site. Ads load only after you give permission.' : 'Advertising is currently switched off for this site, so no ad cookies are set and no requests are made to ad servers.';
    });
    if (BG.ownerName) document.querySelectorAll('[data-owner]').forEach(function (n) { n.textContent = BG.ownerName; });
    document.querySelectorAll('[data-contact]').forEach(function (n) {
      n.textContent = '';
      if (BG.contactEmail) n.appendChild(el('a', { href: 'mailto:' + BG.contactEmail, text: BG.contactEmail }));
      else n.appendChild(document.createTextNode('(the site owner has not published a contact address yet)'));
    });
    document.querySelectorAll('[data-cookie-settings]').forEach(function (b) { b.hidden = !BG.ads.enabled; b.addEventListener('click', showBanner); });
    if (!BG.ads.enabled) return;
    var meta = document.querySelector('meta[name="google-adsense-account"]');
    if (!meta) { meta = document.createElement('meta'); meta.name = 'google-adsense-account'; document.head.appendChild(meta); }
    meta.content = BG.ads.publisherId;
    var c = BG.getConsent();
    if (c) loadAds(c.ads); else showBanner();
    document.addEventListener('braingrid:reset', function () { if (BG.ads.loaded) BG.reloadPage(); else showBanner(); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
