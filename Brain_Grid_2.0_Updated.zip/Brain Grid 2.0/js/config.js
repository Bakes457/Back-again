/* BrainGrid site settings. This is the ONLY file you need to edit to switch advertising on.

   adsensePublisherId  Your AdSense publisher ID, in the form ca-pub-XXXXXXXXXXXXXXXX.
                       Ads only switch on when this is valid AND at least one ad unit ID below is set
                       (or autoAds is true). Until then: no ad script, no consent banner, no request to Google.
   autoAds             Set to true ONLY if you turned on "Auto ads" in AdSense and want Google to choose
                       placements itself. Default false: ads then appear only in the slots below.
   adSlots             The numeric "data-ad-slot" IDs of two ad units you create in AdSense:
                       content  = used below games, play and category pages
                       article  = used inside articles
                       A placement with an empty ID simply shows nothing.
   ownerName           Your name or organisation, shown in the footer, About and Terms pages.
                       Leave empty to show "BrainGrid".
   contactEmail        An address for privacy and data-deletion requests. If empty, the email
                       request form explains that no address is published yet.

   Fill in the empty values below when you are ready. */
window.BG_CONFIG = window.BG_CONFIG || {
  adsensePublisherId: 'ca-pub-5264717241062710',
  autoAds: false,
  adSlots: { content: '', article: '' },
  ownerName: '',
  contactEmail: ''
};
