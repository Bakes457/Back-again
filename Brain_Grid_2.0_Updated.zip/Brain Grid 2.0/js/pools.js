/* Puzzle banks and generators shared by the game pages and the Daily Challenge.
   Number sequences and patterns are produced from rules, so the shown terms and the answer can never disagree. */
(function () {
  'use strict';
  var BG = window.BG = window.BG || {};
  var U = BG.util;
  var P = BG.pools = {};

  /* ---------- Anagrams (every word has no common alternative anagram) ---------- */
  P.anagrams = {
    easy: [
      { w: 'puzzle', hint: 'You are solving one right now.' }, { w: 'rocket', hint: 'It travels to space.' },
      { w: 'bridge', hint: 'It crosses a river or road.' }, { w: 'window', hint: 'Glass in a wall that lets light in.' },
      { w: 'monkey', hint: 'A playful animal that climbs trees.' }, { w: 'basket', hint: 'A woven container for carrying things.' },
      { w: 'pencil', hint: 'You write or draw with it.' }, { w: 'button', hint: 'It fastens a shirt, or you press it.' },
      { w: 'jungle', hint: 'A dense tropical forest.' }, { w: 'bottle', hint: 'It holds a drink.' }
    ],
    medium: [
      { w: 'dolphin', hint: 'A clever sea mammal.' }, { w: 'penguin', hint: 'A bird that swims but cannot fly.' },
      { w: 'volcano', hint: 'A mountain that can erupt.' }, { w: 'rainbow', hint: 'Appears when sun meets rain.' },
      { w: 'compass', hint: 'Its needle points north.' }, { w: 'lantern', hint: 'A portable light you carry by a handle.' },
      { w: 'harvest', hint: 'Gathering crops when they are ripe.' }, { w: 'thunder', hint: 'The sound that follows lightning.' },
      { w: 'whisper', hint: 'To speak very quietly.' }, { w: 'cricket', hint: 'An insect that chirps, and also a sport.' },
      { w: 'journey', hint: 'A long trip from one place to another.' }, { w: 'library', hint: 'A building full of books to borrow.' },
      { w: 'blanket', hint: 'Keeps you warm in bed.' }
    ],
    hard: [
      { w: 'elephant', hint: 'The largest land animal.' }, { w: 'umbrella', hint: 'Keeps the rain off you.' },
      { w: 'mountain', hint: 'A very tall natural landform.' }, { w: 'notebook', hint: 'Blank pages for writing things down.' },
      { w: 'keyboard', hint: 'You type on it.' }, { w: 'football', hint: 'A team sport played with a round ball.' },
      { w: 'sandwich', hint: 'Filling between two slices of bread.' }, { w: 'adventure', hint: 'An exciting, unusual experience.' },
      { w: 'telescope', hint: 'Used to look at distant stars.' }, { w: 'chocolate', hint: 'A sweet treat made from cacao.' }
    ]
  };
  P.scramble = function (word, rnd) {
    var out = word, tries = 0;
    while (out === word && tries++ < 50) out = U.shuffle(word.split(''), rnd).join('');
    return out;
  };

  /* ---------- Number sequences. build() returns the shown terms plus the answer as the last item. ---------- */
  function run(first, count, fn) { var a = [first]; while (a.length < count) a.push(fn(a[a.length - 1], a.length)); return a; }
  function byIndex(count, fn) { var a = []; for (var i = 0; i < count; i++) a.push(fn(i)); return a; }
  P.sequences = [
    { level: 1, kind: 'Add a constant', build: function () { return run(2, 6, function (p) { return p + 2; }); }, why: 'Each term is 2 more than the one before: 2, 4, 6, 8, 10, so the next term is 12.' },
    { level: 1, kind: 'Add a constant', build: function () { return run(5, 6, function (p) { return p + 5; }); }, why: 'Each term is 5 more than the one before, so the next term is 25 + 5 = 30.' },
    { level: 1, kind: 'Subtract a constant', build: function () { return run(30, 5, function (p) { return p - 3; }); }, why: 'Each term is 3 less than the one before, so 21 - 3 = 18 comes next.' },
    { level: 1, kind: 'Subtract a constant', build: function () { return run(100, 5, function (p) { return p - 10; }); }, why: 'The sequence counts down in tens, so 70 - 10 = 60 comes next.' },
    { level: 1, kind: 'Multiply', build: function () { return run(1, 6, function (p) { return p * 2; }); }, why: 'Each term is double the one before: 1, 2, 4, 8, 16, so the next term is 32.' },
    { level: 1, kind: 'Multiply', build: function () { return run(3, 5, function (p) { return p * 2; }); }, why: 'Each term doubles: 3, 6, 12, 24, so the next term is 48.' },
    { level: 2, kind: 'Square numbers', build: function () { return byIndex(6, function (i) { return (i + 1) * (i + 1); }); }, why: 'These are the square numbers 1x1, 2x2, 3x3, 4x4, 5x5, so the next is 6x6 = 36.' },
    { level: 2, kind: 'Double and add one', build: function () { return run(2, 5, function (p) { return p * 2 + 1; }); }, why: 'Each term is the previous term doubled, plus 1: 2, 5, 11, 23, so the next is 23 x 2 + 1 = 47.' },
    { level: 2, kind: 'Growing differences', build: function () { return run(1, 6, function (p, i) { return p + i + 1; }); }, why: 'The gaps grow by one each time: +2, +3, +4, +5, so the next gap is +6 and 15 + 6 = 21 (the triangular numbers).' },
    { level: 2, kind: 'Growing differences', build: function () { return run(5, 6, function (p, i) { return p + i + 1; }); }, why: 'The gaps are +2, +3, +4, +5, so the next gap is +6 and 19 + 6 = 25.' },
    { level: 2, kind: 'Growing differences', build: function () { return run(1, 6, function (p, i) { return p + i; }); }, why: 'The gaps go +1, +2, +3, +4, so the next gap is +5 and 11 + 5 = 16.' },
    { level: 2, kind: 'Fibonacci', build: function () { var a = [1, 1]; while (a.length < 7) a.push(a[a.length - 1] + a[a.length - 2]); return a; }, why: 'Each term is the sum of the two before it: 5 + 8 = 13.' },
    { level: 2, kind: 'Divide', build: function () { return run(81, 5, function (p) { return p / 3; }); }, why: 'Each term is one third of the one before: 81, 27, 9, 3, so the next term is 1.' },
    { level: 2, kind: 'Divide', build: function () { return run(64, 5, function (p) { return p / 2; }); }, why: 'Each term is half of the one before: 64, 32, 16, 8, so the next term is 4.' },
    { level: 3, kind: 'Cube numbers', build: function () { return byIndex(5, function (i) { return Math.pow(i + 1, 3); }); }, why: 'These are the cubes 1, 2, 3, 4 multiplied by themselves three times. 5 x 5 x 5 = 125.' },
    { level: 3, kind: 'Growing differences', build: function () { return byIndex(6, function (i) { return (i + 1) * (i + 2); }); }, why: 'The gaps are +4, +6, +8, +10 (they rise by 2), so the next gap is +12 and 30 + 12 = 42.' },
    { level: 3, kind: 'Growing differences', build: function () { return run(3, 7, function (p, i) { return p + i; }); }, why: 'The gaps are +1, +2, +3, +4, +5, so the next gap is +6 and 18 + 6 = 24.' },
    { level: 3, kind: 'Alternating rules', build: function () { return run(1, 8, function (p, i) { return i % 2 === 1 ? p * 3 : p - 1; }); }, why: 'The rule alternates: multiply by 3, then subtract 1. After 15 comes 14, and then 14 x 3 = 42.' },
    { level: 3, kind: 'Alternating rules', build: function () { return run(2, 7, function (p, i) { return i % 2 === 1 ? p * 2 : p - 1; }); }, why: 'The rule alternates: double, then subtract 1 (2, 4, 3, 6, 5, 10), so the next term is 10 - 1 = 9.' },
    { level: 3, kind: 'Prime numbers', build: function () { return [2, 3, 5, 7, 11, 13, 17]; }, why: 'These are the prime numbers in order. The next prime after 13 is 17.' },
    { level: 3, kind: 'Factorials', build: function () { return run(1, 6, function (p, i) { return p * (i + 1); }); }, why: 'Multiply by 2, then 3, then 4, then 5, then 6: 120 x 6 = 720.' },
    { level: 3, kind: 'Double and add one', build: function () { return run(0, 7, function (p) { return p * 2 + 1; }); }, why: 'Each term is double the previous one plus 1: 0, 1, 3, 7, 15, 31, so the next is 63.' },
    { level: 3, kind: 'Growing differences', build: function () { return run(10, 6, function (p, i) { return p - i; }); }, why: 'The gaps are -1, -2, -3, -4, so the next gap is -5 and 0 - 5 = -5.' }
  ];

  /* ---------- Riddles (original wording) ---------- */
  P.riddles = [
    { level: 'easy', q: 'Many keys sit on me, yet none will open a lock. I have a long bar for space, but no rooms inside. What am I?', a: ['keyboard', 'a keyboard', 'computer keyboard'], hint: 'You are probably touching one right now.', why: 'A keyboard has keys, a space bar, and no doors or rooms.' },
    { level: 'easy', q: 'I follow you in sunshine and vanish in the dark. I copy every move you make but never say a word. What am I?', a: ['shadow', 'a shadow', 'your shadow'], hint: 'You cannot make one without a light.', why: 'A shadow is made by blocking light, so it needs light to exist and copies your movement.' },
    { level: 'easy', q: 'I am full of holes, yet I can still hold water. What am I?', a: ['sponge', 'a sponge'], hint: 'Found near a kitchen sink.', why: 'A sponge is full of holes, and soaks up and holds water in them.' },
    { level: 'easy', q: 'I have a face and two hands, yet I cannot wave or smile. I am always moving but never leave my place on the wall. What am I?', a: ['clock', 'a clock', 'wall clock'], hint: 'You check me to know what time it is.', why: 'A clock has a face and hands. They move in circles, but the clock itself stays put.' },
    { level: 'easy', q: 'I wear a cap but have no head, and I have a neck but no face. What am I?', a: ['bottle', 'a bottle'], hint: 'You drink from it, and you twist the cap off.', why: 'A bottle has a neck and a cap, but no head or face.' },
    { level: 'medium', q: 'People pick me up when I ring, though I have no hands to reach out. Hold me to your ear and I carry voices from far away. What am I?', a: ['phone', 'a phone', 'telephone', 'a telephone', 'mobile phone', 'cell phone'], hint: 'It is probably in your pocket or bag.', why: 'A phone rings, and it carries voices from far away to your ear.' },
    { level: 'hard', q: 'I am always in front of you, yet you can never see me. What am I?', a: ['future', 'the future'], hint: 'It is not a place. It is a time.', why: 'The future is always ahead of you, but it has not happened yet, so it cannot be seen.' },
    { level: 'medium', q: 'The more of me you take, the more you leave behind. What am I?', a: ['footsteps', 'steps', 'footprints', 'steps you take', 'step'], hint: 'Think about walking along a sandy beach.', why: 'Every step you take leaves another footprint behind you.' },
    { level: 'medium', q: 'What gets wetter the more it dries?', a: ['towel', 'a towel'], hint: 'You use it after a shower.', why: 'A towel dries you, so the towel itself gets wetter.' },
    { level: 'medium', q: 'I speak only when spoken to, yet I have no mouth. Shout into a canyon and I answer back. What am I?', a: ['echo', 'an echo', 'the echo'], hint: 'It is sound bouncing off a surface.', why: 'An echo repeats the sound you made, so it only answers when you speak first.' },
    { level: 'medium', q: 'I am tall when I am new and short when I am old. I give light until I am gone. What am I?', a: ['candle', 'a candle'], hint: 'Often found on a birthday cake.', why: 'A candle burns down as it gives light, so it gets shorter with age.' },
    { level: 'hard', q: 'What can you hold in your right hand but never in your left?', a: ['your left hand', 'left hand', 'my left hand', 'the left hand', 'left elbow', 'your left elbow'], hint: 'The answer is part of you.', why: 'Your right hand can grip your left hand, but your left hand cannot be held by itself.' },
    { level: 'hard', q: 'I am lighter than a feather, yet even a strong person cannot hold me for more than a few minutes. What am I?', a: ['breath', 'your breath', 'a breath', 'my breath'], hint: 'You do it all day without thinking.', why: 'Breath weighs almost nothing, but nobody can hold their breath for long.' },
    { level: 'hard', q: 'I have cities, but no people live in me. I have rivers, but no water. I have forests, but no trees. What am I?', a: ['map', 'a map', 'atlas', 'an atlas'], hint: 'You unfold it or open it on a screen when you are lost.', why: 'A map draws cities, rivers and forests as symbols, not the real things.' },
    { level: 'hard', q: 'What begins with the letter T, ends with the letter T, and is usually full of T?', a: ['teapot', 'a teapot', 'tea pot'], hint: 'Look at the first and last letters of the answer, and what it holds.', why: 'Teapot starts and ends with T, and holds tea.' }
  ];

  /* ---------- Quick logic questions for the Daily Challenge ---------- */
  P.logicQuick = [
    { q: 'Mia is older than Noah. Noah is older than Owen. Who is the youngest?', o: ['Mia', 'Noah', 'Owen'], a: 2, why: 'Mia > Noah > Owen, so Owen is the youngest.' },
    { q: 'Every box on the shelf is red. This box is on the shelf. What colour is it?', o: ['Red', 'Blue', 'It could be any colour'], a: 0, why: 'All boxes on the shelf are red and this box is on the shelf, so it must be red.' },
    { q: 'Three friends sit in a row. Ravi sits left of Sam, and Tess sits right of Sam. Who sits in the middle?', o: ['Ravi', 'Sam', 'Tess'], a: 1, why: 'Ravi is left of Sam and Tess is right of Sam, so the order is Ravi, Sam, Tess.' },
    { q: 'If it rains, the match is cancelled. The match was not cancelled. What can we be sure of?', o: ['It rained', 'It did not rain', 'The match was played at night'], a: 1, why: 'Rain would have cancelled the match. It was not cancelled, so there was no rain.' },
    { q: 'Alex has more marbles than Bea. Bea has more than Cal. Dee has fewer than Cal. Who has the second most?', o: ['Alex', 'Bea', 'Cal', 'Dee'], a: 1, why: 'The order is Alex, Bea, Cal, Dee, so Bea is second.' },
    { q: 'Sara always tells the truth. She says, "The key is under the mat." Where is the key?', o: ['Under the mat', 'In her pocket', 'We cannot tell'], a: 0, why: 'Sara always tells the truth, so her statement must be true.' },
    { q: 'Pens cost more than pencils. Pencils cost more than erasers. Which must be true?', o: ['Pens cost more than erasers', 'Erasers cost more than pens', 'Pencils are the cheapest'], a: 0, why: 'Pens > pencils > erasers, so pens cost more than erasers.' },
    { q: 'Today is Wednesday. What day was it two days before yesterday?', o: ['Sunday', 'Monday', 'Tuesday'], a: 0, why: 'Yesterday was Tuesday. Two days before Tuesday is Sunday.' },
    { q: 'In a race you overtake the runner in second place. What position are you in now?', o: ['First', 'Second', 'Third'], a: 1, why: 'You take the place of the runner you passed, which is second.' },
    { q: 'Five people each shake hands once with every other person. How many handshakes happen?', o: ['5', '10', '20'], a: 1, why: 'Each of the 5 people shakes 4 hands, which counts every handshake twice: 5 x 4 / 2 = 10.' },
    { q: 'A basket holds 6 apples. You take 4 of them. How many apples do you have?', o: ['2', '4', '6'], a: 1, why: 'You took 4 apples, so you have 4. The basket has 2 left.' },
    { q: 'A train is faster than a bike. A bike is faster than a walker. Which is the slowest?', o: ['Train', 'Bike', 'Walker'], a: 2, why: 'Train > bike > walker for speed, so the walker is slowest.' }
  ];

  /* ---------- Visual patterns ---------- */
  var SHAPES = ['circle', 'square', 'triangle', 'diamond', 'cross'];
  var FILLS = ['solid', 'outline', 'hatch'];
  var ROTS = [0, 90, 180, 270];
  var DIRS = { 0: 'up', 90: 'right', 180: 'down', 270: 'left' };
  function mk(s, f, r, n) { return { s: s, f: f || 'solid', r: r || 0, n: n || 1 }; }
  P.itemKey = function (it) { return [it.s, it.f, it.r, it.n].join('|'); };
  P.describeItem = function (it) {
    if (it.s === 'dots') return it.n + (it.n === 1 ? ' dot' : ' dots');
    return (it.f === 'hatch' ? 'striped' : it.f) + ' ' + it.s + (it.s === 'triangle' ? ' pointing ' + DIRS[it.r] : '');
  };
  var uid = 0;
  P.itemSvg = function (it) {
    var id = 'hatch' + (++uid), ink = 'var(--ink)';
    var fill = it.f === 'solid' ? ink : it.f === 'hatch' ? 'url(#' + id + ')' : 'var(--surface)';
    var common = ' style="fill:' + fill + ';stroke:' + ink + ';stroke-width:2.5;stroke-linejoin:round"';
    var shape = '';
    if (it.s === 'circle') shape = '<circle cx="30" cy="30" r="19"' + common + '/>';
    else if (it.s === 'square') shape = '<rect x="12" y="12" width="36" height="36"' + common + '/>';
    else if (it.s === 'triangle') shape = '<polygon points="30,9 51,48 9,48" transform="rotate(' + it.r + ' 30 30)"' + common + '/>';
    else if (it.s === 'diamond') shape = '<polygon points="30,7 53,30 30,53 7,30"' + common + '/>';
    else if (it.s === 'cross') shape = '<path d="M23 8h14v15h15v14H37v15H23V37H8V23h15z"' + common + '/>';
    else if (it.s === 'dots') {
      for (var i = 0; i < it.n; i++) shape += '<circle cx="' + (14 + (i % 3) * 16) + '" cy="' + (i < 3 ? 20 : 42) + '" r="6" style="fill:' + ink + '"/>';
    }
    var defs = '<defs><pattern id="' + id + '" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="7" height="7" style="fill:var(--surface)"/><line x1="0" y1="0" x2="0" y2="7" style="stroke:' + ink + ';stroke-width:3"/></pattern></defs>';
    return '<svg viewBox="0 0 60 60" aria-hidden="true" focusable="false">' + defs + shape + '</svg>';
  };

  function range(n) { var a = []; for (var i = 0; i < n; i++) a.push(i); return a; }
  /* Builds a pattern puzzle: a sequence, one hidden item, four options and an explanation. */
  P.makePattern = function (rnd, level) {
    var pool = level === 'easy' ? ['cycle', 'rotate'] : level === 'medium' ? ['rotate', 'count', 'fillcycle'] : ['dual', 'rotshape'];
    var type = U.pick(pool, rnd), len = 8, seq, why, minHide, vary;
    if (type === 'cycle') {
      var p = 2 + Math.floor(rnd() * 2), shapes = U.shuffle(SHAPES, rnd).slice(0, p), f = U.pick(FILLS, rnd);
      seq = range(len).map(function (i) { return mk(shapes[i % p], f); });
      why = 'The shapes repeat in a cycle of ' + p + ': ' + shapes.join(', ') + '. The pattern then starts over.';
      minHide = p; vary = ['s'];
    } else if (type === 'rotate') {
      var f2 = U.pick(FILLS, rnd);
      seq = range(len).map(function (i) { return mk('triangle', f2, ROTS[i % 4]); });
      why = 'The triangle turns a quarter turn clockwise each step (up, right, down, left), then repeats.';
      minHide = 4; vary = ['r'];
    } else if (type === 'count') {
      len = 6; seq = range(len).map(function (i) { return mk('dots', 'solid', 0, i + 1); });
      why = 'One more dot is added at every step: 1, 2, 3, 4, 5, 6.';
      minHide = 3; vary = ['n'];
    } else if (type === 'fillcycle') {
      var sh = U.pick(SHAPES, rnd), order = U.shuffle(FILLS, rnd);
      seq = range(len).map(function (i) { return mk(sh, order[i % 3]); });
      why = 'The ' + sh + ' stays the same, but its style cycles through ' + order.map(function (x) { return x === 'hatch' ? 'striped' : x; }).join(', ') + '.';
      minHide = 3; vary = ['f', 's'];
    } else if (type === 'dual') {
      len = 9;
      var two = U.shuffle(SHAPES, rnd).slice(0, 2), order2 = U.shuffle(FILLS, rnd);
      seq = range(len).map(function (i) { return mk(two[i % 2], order2[i % 3]); });
      why = 'Two patterns run at once. The shape alternates between ' + two.join(' and ') + ', while the style cycles through ' + order2.map(function (x) { return x === 'hatch' ? 'striped' : x; }).join(', ') + '.';
      minHide = 6; vary = ['s', 'f'];
    } else {
      seq = range(len).map(function (i) { return mk('triangle', i % 2 ? 'outline' : 'solid', ROTS[i % 4]); });
      why = 'Two patterns run at once. The triangle turns a quarter turn clockwise each step, while its style alternates between solid and outline.';
      minHide = 4; vary = ['r', 'f'];
    }
    var hidden = minHide + Math.floor(rnd() * (len - minHide));
    var answer = seq[hidden], domain = { s: SHAPES, f: FILLS, r: ROTS, n: [1, 2, 3, 4, 5, 6] }, seen = {}, cands = [];
    seen[P.itemKey(answer)] = true;
    vary.forEach(function (attr) {
      domain[attr].forEach(function (val) {
        var c = { s: answer.s, f: answer.f, r: answer.r, n: answer.n }; c[attr] = val;
        if (answer.s === 'dots' && attr !== 'n') return;
        var k = P.itemKey(c);
        if (!seen[k]) { seen[k] = true; cands.push(c); }
      });
    });
    var options = U.shuffle(U.shuffle(cands, rnd).slice(0, 3).concat([answer]), rnd);
    return { type: type, seq: seq, hidden: hidden, options: options, answerIndex: options.indexOf(answer), why: why };
  };

  /* ---------- Memory recall (Daily Challenge) ---------- */
  P.symbols = [
    { g: '\u25B2', n: 'Triangle' }, { g: '\u25CF', n: 'Circle' }, { g: '\u25A0', n: 'Square' }, { g: '\u25C6', n: 'Diamond' },
    { g: '\u2605', n: 'Star' }, { g: '\u2665', n: 'Heart' }, { g: '\u263E', n: 'Moon' }, { g: '\u271A', n: 'Plus' }, { g: '\u2660', n: 'Spade' }
  ];
  P.makeRecall = function (rnd) {
    var chosen = U.shuffle(P.symbols, rnd), seq = chosen.slice(0, 5), askIdx = Math.floor(rnd() * 5);
    var answer = seq[askIdx];
    var others = U.shuffle(seq.filter(function (s) { return s !== answer; }).concat(chosen.slice(5)), rnd).slice(0, 3);
    var options = U.shuffle(others.concat([answer]), rnd);
    return { seq: seq, askIdx: askIdx, options: options, answerIndex: options.indexOf(answer) };
  };

  /* ---------- Deterministic daily selection ---------- */
  var ORD = ['first', 'second', 'third', 'fourth', 'fifth'];
  P.ordinal = function (i) { return ORD[i]; };
  P.dailyFor = function (dateKey) {
    function r(cat) { return U.rng(U.hash('braingrid|' + dateKey + '|' + cat)); }
    var rl = r('logic'), rw = r('word'), rn = r('number'), rv = r('visual'), rm = r('memory');
    var allWords = P.anagrams.easy.concat(P.anagrams.medium, P.anagrams.hard);
    var word = U.pick(allWords, rw), seqDef = U.pick(P.sequences.filter(function (s) { return s.level < 3; }), rn);
    var terms = seqDef.build();
    return {
      logic: U.pick(P.logicQuick, rl),
      word: { word: word.w, hint: word.hint, scrambled: P.scramble(word.w, rw) },
      number: { shown: terms.slice(0, -1), answer: terms[terms.length - 1], kind: seqDef.kind, why: seqDef.why },
      visual: P.makePattern(rv, 'medium'),
      memory: P.makeRecall(rm)
    };
  };
})();
