/* My Best Scores: reads only this browser's saved data. There is no server and no shared leaderboard. */
(function () {
  'use strict';
  var BG = window.BG = window.BG || {};
  var U = BG.util, el = U.el;
  var LEVEL_NAMES = { easy: 'Easy', medium: 'Medium', hard: 'Hard', standard: 'Standard', mixed: 'Mixed / rising', '1': 'Easy', '2': 'Medium', '3': 'Hard' };

  function puzzleById(id) { return (window.BG_CATALOG ? window.BG_CATALOG.puzzles : []).filter(function (p) { return p.id === id; })[0]; }
  function describeKey(key) {
    var parts = key.split(':'), p = puzzleById(parts[0]);
    var level = LEVEL_NAMES[parts[1]] || U.cap(parts[1] || '');
    if (parts[2]) level += ', ' + parts[2];
    return { title: p ? p.title : parts[0], url: p ? p.url : null, level: level };
  }
  function linkList(ids, emptyText) {
    var list = ids.map(puzzleById).filter(Boolean);
    if (!list.length) return el('p', { class: 'muted', text: emptyText });
    return el('ul', {}, list.map(function (p) { return el('li', {}, [el('a', { href: U.root() + p.url, text: p.title })]); }));
  }
  /* Badges are computed only from data saved on this device. */
  function badgeList(best, keys) {
    var games = {}, cats = {}, cat = function (id) { var p = puzzleById(id); return p ? p.category : null; };
    keys.forEach(function (k) { var g = k.split(':')[0]; games[g] = true; if (cat(g)) cats[cat(g)] = true; });
    var streak = BG.getStreak(), favs = BG.getFavs().length, gCount = Object.keys(games).length, cCount = Object.keys(cats).length;
    return [
      { name: 'First finish', desc: 'Finish any puzzle', ok: keys.length > 0 },
      { name: 'Variety pack', desc: 'Finish 5 different puzzles', ok: gCount >= 5 },
      { name: 'All-rounder', desc: 'Finish a puzzle in every category', ok: cCount >= 5 },
      { name: 'Word wizard', desc: 'Solve a WordGrid', ok: !!games.wordgrid },
      { name: 'Daily starter', desc: 'Complete a full daily challenge', ok: streak >= 1 || BG.dailyCount() === 5 },
      { name: 'Three in a row', desc: 'Reach a 3-day streak', ok: streak >= 3 },
      { name: 'Week warrior', desc: 'Reach a 7-day streak', ok: streak >= 7 },
      { name: 'Collector', desc: 'Save 3 favourite puzzles', ok: favs >= 3 }
    ];
  }
  function render() {
    var best = BG.getBest(), keys = Object.keys(best).sort();
    var stats = document.getElementById('stats'), table = document.getElementById('best-table');
    stats.innerHTML = '';
    [['Daily streak', BG.getStreak() + (BG.getStreak() === 1 ? ' day' : ' days')], ['Daily puzzles done today', BG.dailyCount() + ' of 5'], ['Personal bests saved', String(keys.length)]].forEach(function (s) {
      stats.appendChild(el('div', {}, [el('b', { text: s[1] }), s[0]]));
    });
    table.innerHTML = '';
    if (!keys.length) {
      table.appendChild(el('div', { class: 'placeholder-box' }, [el('p', { text: 'No scores yet. Finish a puzzle and your best result will appear here.' }), el('a', { class: 'btn btn-primary', href: U.root() + 'play.html', text: 'Pick a puzzle' })]));
    } else {
      var rows = keys.map(function (k) {
        var d = describeKey(k), e = best[k];
        return el('tr', {}, [el('td', {}, [d.url ? el('a', { href: U.root() + d.url, text: d.title }) : d.title]), el('td', { text: d.level }), el('td', { text: e.label }), el('td', { text: e.date })]);
      });
      table.appendChild(el('div', { class: 'table-wrap' }, [el('table', { class: 'data' }, [
        el('thead', {}, [el('tr', {}, ['Puzzle', 'Setting', 'Best result', 'Date set'].map(function (h) { return el('th', { scope: 'col', text: h }); }))]),
        el('tbody', {}, rows)])]));
    }
    var shelf = document.getElementById('badges');
    if (shelf) { shelf.innerHTML = ''; badgeList(best, keys).forEach(function (b) { shelf.appendChild(el('li', { class: b.ok ? 'earned' : '' }, [el('strong', { text: b.name }), el('small', { text: b.desc + (b.ok ? ' (earned)' : ' (not yet)') })])); }); }
    var recent = document.getElementById('recent-list'), favs = document.getElementById('fav-list');
    recent.innerHTML = ''; favs.innerHTML = '';
    recent.appendChild(linkList(BG.getRecent(), 'Nothing played yet.'));
    favs.appendChild(linkList(BG.getFavs(), 'No favourites yet. Use the Save button on any puzzle card.'));
  }
  function init() { if (document.getElementById('best-table')) { render(); document.addEventListener('braingrid:reset', render); } }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
