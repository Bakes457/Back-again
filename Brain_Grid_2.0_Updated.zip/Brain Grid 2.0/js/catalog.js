/* Generated from data/puzzles.json and data/articles.json so search works when the site is opened straight from disk.
   `icons` holds the small SVG picture for each game card. If you edit the JSON files, update this file to match (see README). */
window.BG_CATALOG = {
 "puzzles": [
  {
   "id": "sudoku",
   "title": "Sudoku",
   "category": "logic",
   "url": "games/sudoku.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "long",
   "desc": "Fill the 9x9 grid so every row, column and 3x3 box holds the digits 1 to 9. Every board has exactly one solution."
  },
  {
   "id": "word-search",
   "title": "Word Search",
   "category": "word",
   "url": "games/word-search.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "medium",
   "desc": "Find the hidden words in a freshly generated letter grid. Words run in straight lines, and hard mode adds backwards and diagonal words."
  },
  {
   "id": "anagram",
   "title": "Anagram Challenge",
   "category": "word",
   "url": "games/anagram.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Unscramble five jumbled words per round. Hints are available when you are stuck."
  },
  {
   "id": "number-sequence",
   "title": "Number Sequence",
   "category": "number",
   "url": "games/number-sequence.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Work out the next number in each sequence, from simple counting patterns to alternating and growing rules. Every answer is explained."
  },
  {
   "id": "logic-grid",
   "title": "Logic Grid",
   "category": "logic",
   "url": "games/logic-grid.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "long",
   "desc": "Use the clues to match people with their pets, hobbies and more. Rule possibilities out and place matches until everything fits."
  },
  {
   "id": "memory-match",
   "title": "Memory Match",
   "category": "memory",
   "url": "games/memory-match.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Flip pairs of cards and match them all in as few moves as you can. Moves and time are tracked."
  },
  {
   "id": "pattern-completion",
   "title": "Pattern Completion",
   "category": "visual",
   "url": "games/pattern-completion.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "One shape is missing from a sequence. Choose the option that continues the rule, then see why it works."
  },
  {
   "id": "spot-the-difference",
   "title": "Spot the Difference",
   "category": "visual",
   "url": "games/spot-the-difference.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "medium",
   "desc": "Compare two illustrations and find every difference. Hints and a text-based area checker are included."
  },
  {
   "id": "math-sprint",
   "title": "Math Sprint",
   "category": "number",
   "url": "games/math-sprint.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Answer quick arithmetic questions in a timed or untimed round. Accuracy and score are tracked."
  },
  {
   "id": "riddles",
   "title": "Riddle Challenge",
   "category": "logic",
   "url": "games/riddles.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Original riddles to solve in your own words, with hints, reveal and a short explanation of each answer."
  },
  {
   "id": "wordgrid",
   "title": "WordGrid",
   "category": "word",
   "url": "games/wordgrid.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Guess the hidden five-letter word in six tries. Every guess is marked tile by tile, with a new daily word and unlimited practice."
  },
  {
   "id": "tile-merge",
   "title": "Tile Merge",
   "category": "number",
   "url": "games/tile-merge.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "medium",
   "desc": "Slide numbered tiles so equal ones merge and double. Build the biggest number you can before the board fills up."
  },
  {
   "id": "safe-sweep",
   "title": "Safe Sweep",
   "category": "logic",
   "url": "games/safe-sweep.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "medium",
   "desc": "Uncover every safe square without touching a hidden mine. Use the numbers to deduce where the mines are."
  },
  {
   "id": "slide-tiles",
   "title": "Slide Tiles",
   "category": "visual",
   "url": "games/slide-tiles.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "medium",
   "desc": "Slide numbered tiles into the empty gap until they run in order. Every board is guaranteed solvable."
  },
  {
   "id": "grid-lights",
   "title": "Grid Lights",
   "category": "logic",
   "url": "games/grid-lights.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Pressing a square flips it and its neighbours. Find the presses that switch every light off."
  },
  {
   "id": "echo-sequence",
   "title": "Echo Sequence",
   "category": "memory",
   "url": "games/echo-sequence.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Watch a growing sequence of pads and repeat it from memory. See how many steps you can hold."
  },
  {
   "id": "cipher-quest",
   "title": "Cipher Quest",
   "category": "word",
   "url": "games/cipher-quest.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "medium",
   "desc": "Every letter of a sentence has been swapped for another. Decode it with logic and a little letter sense."
  },
  {
   "id": "drop-four",
   "title": "Drop Four",
   "category": "logic",
   "url": "games/drop-four.html",
   "levels": [
    "Easy",
    "Medium",
    "Hard"
   ],
   "time": "quick",
   "desc": "Take turns dropping discs against the computer. Line up four in a row before it does."
  }
 ],
 "articles": [
  {
   "id": "beginner-sudoku-strategies",
   "title": "Beginner Sudoku Strategies",
   "url": "articles/beginner-sudoku-strategies.html",
   "desc": "Learn the first four Sudoku techniques: scanning, single candidates, hidden singles and pencil-style elimination."
  },
  {
   "id": "solving-logic-puzzles",
   "title": "How to Solve Logic Puzzles",
   "url": "articles/solving-logic-puzzles.html",
   "desc": "A practical method for logic grid puzzles: organise the clues, rule things out first and combine facts one step at a time."
  },
  {
   "id": "number-sequence-strategies",
   "title": "How to Solve Number Sequences",
   "url": "articles/number-sequence-strategies.html",
   "desc": "A checklist for finding the next number: differences, multiplication, alternating rules and well-known sequences."
  },
  {
   "id": "word-search-tips",
   "title": "Word Search Strategies",
   "url": "articles/word-search-tips.html",
   "desc": "Faster word searching: scan for first letters and rare letters, work in a system and use the word list wisely."
  },
  {
   "id": "memory-match-guide",
   "title": "How Memory Match Games Work",
   "url": "articles/memory-match-guide.html",
   "desc": "How a matching-card game works, how scoring is counted, and simple habits for finding pairs in fewer moves."
  },
  {
   "id": "recognizing-visual-patterns",
   "title": "How to Recognize Visual Patterns",
   "url": "articles/recognizing-visual-patterns.html",
   "desc": "Break a visual pattern into features such as shape, style, direction and count, then test each one separately."
  },
  {
   "id": "riddle-solving-tips",
   "title": "Practical Riddle-Solving Tips",
   "url": "articles/riddle-solving-tips.html",
   "desc": "Why riddles work, and how to find the trick: read literally, find double meanings and picture the object."
  },
  {
   "id": "wordgrid-strategy",
   "title": "WordGrid Strategy: Better Guesses, Fewer Tries",
   "url": "articles/wordgrid-strategy.html",
   "desc": "How to choose opening words, use feedback marks and handle repeated letters in WordGrid."
  },
  {
   "id": "tile-merge-strategy",
   "title": "Tile Merge Strategy: Keep a Corner and Build a Chain",
   "url": "articles/tile-merge-strategy.html",
   "desc": "A calm approach to Tile Merge: corner your biggest tile, use only two or three directions and keep rows tidy."
  },
  {
   "id": "safe-sweep-logic",
   "title": "Safe Sweep: Deducing Where the Mines Are",
   "url": "articles/safe-sweep-logic.html",
   "desc": "The reasoning patterns behind Safe Sweep: counting neighbours, using flags and comparing two clues."
  },
  {
   "id": "sliding-tile-puzzles",
   "title": "How to Solve Sliding Tile Puzzles",
   "url": "articles/sliding-tile-puzzles.html",
   "desc": "A row-by-row method for sliding tile puzzles, and why you should not undo finished work."
  },
  {
   "id": "cipher-solving-tips",
   "title": "Cipher Solving Tips: Cracking Letter-Swap Puzzles",
   "url": "articles/cipher-solving-tips.html",
   "desc": "Practical tips for substitution ciphers: letter frequency, short words, double letters and testing guesses."
  }
 ],
 "icons": {
  "sudoku": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"6\" y=\"6\" width=\"36\" height=\"36\" rx=\"3\"/><path d=\"M18 6v36M30 6v36M6 18h36M6 30h36\" stroke-width=\"2\"/><path d=\"M10 12h4M22 24h4M34 36h4M22 12v3M34 24v3M10 36h4\"/></svg>",
  "word-search": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"6\" y=\"6\" width=\"36\" height=\"36\" rx=\"3\"/><path d=\"M13 13l22 22\" stroke-width=\"4\"/><circle cx=\"13\" cy=\"13\" r=\"3\"/><circle cx=\"35\" cy=\"35\" r=\"3\"/><path d=\"M13 35h6M29 13h6\" stroke-width=\"2\"/></svg>",
  "anagram": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"4\" y=\"18\" width=\"11\" height=\"16\" rx=\"2\"/><rect x=\"18.5\" y=\"18\" width=\"11\" height=\"16\" rx=\"2\"/><rect x=\"33\" y=\"18\" width=\"11\" height=\"16\" rx=\"2\"/><path d=\"M10 13c6-8 22-8 28 0M34 9l4 4-5 2\"/></svg>",
  "number-sequence": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><text x=\"24\" y=\"31\" text-anchor=\"middle\" font-size=\"18\" font-weight=\"700\" font-family=\"Georgia,serif\" fill=\"currentColor\" stroke=\"none\">2 4 ?</text></svg>",
  "logic-grid": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"6\" y=\"6\" width=\"36\" height=\"36\" rx=\"3\"/><path d=\"M18 6v36M30 6v36M6 18h36M6 30h36\" stroke-width=\"2\"/><path d=\"M9 12l3 3 5-6M33 21l6 6M39 21l-6 6\" stroke-width=\"3\"/></svg>",
  "memory-match": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"5\" y=\"9\" width=\"20\" height=\"28\" rx=\"3\"/><rect x=\"23\" y=\"13\" width=\"20\" height=\"28\" rx=\"3\" style=\"fill:var(--cat-soft)\"/><circle cx=\"33\" cy=\"27\" r=\"5\"/></svg>",
  "pattern-completion": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M5 20l7-12 7 12z\"/><circle cx=\"29\" cy=\"13\" r=\"6\"/><rect x=\"35\" y=\"22\" width=\"9\" height=\"9\"/><text x=\"13\" y=\"42\" text-anchor=\"middle\" font-size=\"16\" font-weight=\"700\" fill=\"currentColor\" stroke=\"none\">?</text></svg>",
  "spot-the-difference": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"4\" y=\"10\" width=\"17\" height=\"22\" rx=\"2\"/><rect x=\"27\" y=\"10\" width=\"17\" height=\"22\" rx=\"2\"/><path d=\"M8 26l4-6 4 6z\"/><circle cx=\"35\" cy=\"21\" r=\"5\"/><path d=\"M39 25l5 6\" stroke-width=\"3.5\"/></svg>",
  "math-sprint": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><text x=\"24\" y=\"31\" text-anchor=\"middle\" font-size=\"26\" font-weight=\"700\" font-family=\"Georgia,serif\" fill=\"currentColor\" stroke=\"none\">+ \u00d7</text></svg>",
  "riddles": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M7 9h34v22H26l-8 8v-8H7z\"/><text x=\"24\" y=\"28\" text-anchor=\"middle\" font-size=\"18\" font-weight=\"700\" fill=\"currentColor\" stroke=\"none\">?</text></svg>",
  "wordgrid": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"3.0\" y=\"17\" width=\"7.6\" height=\"14\" rx=\"1.5\" fill=\"currentColor\"/><rect x=\"11.9\" y=\"17\" width=\"7.6\" height=\"14\" rx=\"1.5\"/><rect x=\"20.8\" y=\"17\" width=\"7.6\" height=\"14\" rx=\"1.5\"/><rect x=\"29.700000000000003\" y=\"17\" width=\"7.6\" height=\"14\" rx=\"1.5\" fill=\"currentColor\"/><rect x=\"38.6\" y=\"17\" width=\"7.6\" height=\"14\" rx=\"1.5\"/><path d=\"M5 37h4M14 37h4M23 37h4M32 37h4M41 37h3\" stroke-width=\"2\"/></svg>",
  "tile-merge": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"5\" y=\"5\" width=\"16\" height=\"16\" rx=\"3\"/><rect x=\"27\" y=\"5\" width=\"16\" height=\"16\" rx=\"3\" fill=\"currentColor\"/><rect x=\"5\" y=\"27\" width=\"16\" height=\"16\" rx=\"3\" fill=\"currentColor\"/><rect x=\"27\" y=\"27\" width=\"16\" height=\"16\" rx=\"3\"/></svg>",
  "safe-sweep": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"6\" y=\"6\" width=\"36\" height=\"36\" rx=\"3\"/><path d=\"M18 6v36M30 6v36M6 18h36M6 30h36\" stroke-width=\"1.5\"/><path d=\"M20 35V15M20 15l10 4-10 4\" stroke-width=\"3\"/></svg>",
  "slide-tiles": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"5\" y=\"5\" width=\"12\" height=\"12\" rx=\"2\"/><rect x=\"18\" y=\"5\" width=\"12\" height=\"12\" rx=\"2\"/><rect x=\"31\" y=\"5\" width=\"12\" height=\"12\" rx=\"2\"/><rect x=\"5\" y=\"18\" width=\"12\" height=\"12\" rx=\"2\"/><rect x=\"31\" y=\"18\" width=\"12\" height=\"12\" rx=\"2\"/><rect x=\"5\" y=\"31\" width=\"12\" height=\"12\" rx=\"2\"/><rect x=\"18\" y=\"31\" width=\"12\" height=\"12\" rx=\"2\"/><rect x=\"31\" y=\"31\" width=\"12\" height=\"12\" rx=\"2\"/><path d=\"M21 26l3-3 3 3\" stroke-width=\"2\"/></svg>",
  "grid-lights": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><circle cx=\"12\" cy=\"12\" r=\"6\"/><circle cx=\"36\" cy=\"12\" r=\"6\" fill=\"currentColor\"/><circle cx=\"12\" cy=\"36\" r=\"6\" fill=\"currentColor\"/><circle cx=\"36\" cy=\"36\" r=\"6\"/><circle cx=\"24\" cy=\"24\" r=\"6\" fill=\"currentColor\"/></svg>",
  "echo-sequence": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><path d=\"M12 5l8 14H4z\"/><circle cx=\"36\" cy=\"13\" r=\"7\"/><rect x=\"5\" y=\"28\" width=\"14\" height=\"14\" rx=\"1\"/><path d=\"M36 28l8 8-8 8-8-8z\" fill=\"currentColor\"/></svg>",
  "cipher-quest": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><text x=\"24\" y=\"31\" text-anchor=\"middle\" font-size=\"19\" font-weight=\"700\" font-family=\"Georgia,serif\" fill=\"currentColor\" stroke=\"none\">A=Q</text></svg>",
  "drop-four": "<svg class=\"glyph\" viewBox=\"0 0 48 48\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\"><rect x=\"4\" y=\"6\" width=\"40\" height=\"36\" rx=\"4\"/><circle cx=\"14\" cy=\"16\" r=\"4\"/><circle cx=\"14\" cy=\"32\" r=\"4\" fill=\"currentColor\"/><circle cx=\"24\" cy=\"16\" r=\"4\"/><circle cx=\"24\" cy=\"32\" r=\"4\" fill=\"currentColor\"/><circle cx=\"34\" cy=\"16\" r=\"4\"/><circle cx=\"34\" cy=\"32\" r=\"4\" fill=\"currentColor\"/></svg>"
 }
};
