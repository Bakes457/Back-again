/* Echo Sequence: watch the pads light up one at a time, then repeat the order. Each round adds one step.
   Each step is shown for at least 450 ms with a gap between, so nothing flashes quickly. Pads have shapes and names, not just colours. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var SPEEDS = { easy: { on: 900, gap: 350 }, medium: { on: 650, gap: 280 }, hard: { on: 450, gap: 220 } };
  var PADS = [{ n: 'Triangle', g: '\u25B2' }, { n: 'Circle', g: '\u25CF' }, { n: 'Square', g: '\u25A0' }, { n: 'Diamond', g: '\u25C6' }];
  /* Add one random step to the sequence. */
  function extend(seq, rnd) { return seq.concat([Math.floor((rnd || Math.random)() * PADS.length)]); }
  BG.games.echo = { extend: extend, SPEEDS: SPEEDS, PADS: PADS };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { seq: [], pos: 0, phase: 'idle', level: 'easy', timers: [], best: 0 };
  var status = BG.ui.status(), resultHost = el('div', {}), roundEl = el('span', { text: 'Round 0' });
  var announce = el('input', { type: 'checkbox', id: 'echo-announce' }); announce.checked = BG.getPref('echo-sequence', 'announce') === true;
  var extra = el('span', { class: 'controls', style: 'margin:0' }, [announce, el('label', { for: 'echo-announce', text: 'Also write out each sequence in words' })]);
  var controls = BG.ui.controls({ id: 'echo-sequence', levels: [{ v: 'easy', label: 'Easy (slow)' }, { v: 'medium', label: 'Medium' }, { v: 'hard', label: 'Hard (quick)' }], extra: [extra], newLabel: 'New game', onStart: start, onRestart: function () { start(st.level); } });
  var meta = el('div', { class: 'game-meta', hidden: true }, [roundEl]);
  var pads = PADS.map(function (p, i) { return el('button', { type: 'button', class: 'ec-pad ec-p' + i, 'data-p': String(i), 'aria-label': p.n + ' pad (key ' + (i + 1) + ')', disabled: true }, [el('span', { 'aria-hidden': 'true', text: p.g }), el('small', { text: p.n })]); });
  var text = el('p', { class: 'small', 'aria-live': 'polite' });
  var play = el('div', { hidden: true }, [el('div', { class: 'ec-board', role: 'group', 'aria-label': 'Pads' }, pads), text, el('p', { class: 'small muted', text: 'Watch the order, then press the pads in the same order (or press keys 1 to 4).' })]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a speed and press Start. Watch the sequence, then repeat it. It grows by one each round.' });
  [controls.el, intro, meta, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function clearTimers() { st.timers.forEach(clearTimeout); st.timers = []; }
  function setPads(on) { pads.forEach(function (b) { b.disabled = !on; }); }
  function light(i, on) { pads[i].classList.toggle('is-lit', on); }
  function start(level) {
    BG.setPref('echo-sequence', 'announce', announce.checked);
    clearTimers(); st.level = level; st.seq = extend([]); st.pos = 0; st.best = 0;
    intro.hidden = true; play.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost); playback();
  }
  function playback() {
    st.phase = 'show'; setPads(false); roundEl.textContent = 'Round ' + st.seq.length; text.textContent = '';
    var sp = SPEEDS[st.level], t = 700;
    status.say(announce.checked ? 'Watch: ' + st.seq.map(function (i) { return PADS[i].n; }).join(', ') + '.' : 'Watch the ' + st.seq.length + (st.seq.length === 1 ? ' step.' : ' steps.'), 'info');
    st.seq.forEach(function (p, k) {
      st.timers.push(setTimeout(function () { light(p, true); if (announce.checked) text.textContent = 'Step ' + (k + 1) + ': ' + PADS[p].n; }, t));
      st.timers.push(setTimeout(function () { light(p, false); }, t + sp.on));
      t += sp.on + sp.gap;
    });
    st.timers.push(setTimeout(function () { st.phase = 'input'; st.pos = 0; setPads(true); text.textContent = ''; status.say('Your turn. Repeat the ' + st.seq.length + (st.seq.length === 1 ? ' step.' : ' steps.'), 'info'); }, t));
  }
  function choose(i) {
    if (st.phase !== 'input') return;
    light(i, true); st.timers.push(setTimeout(function () { light(i, false); }, 220));
    if (st.seq[st.pos] !== i) return fail();
    st.pos++;
    if (st.pos === st.seq.length) { st.best = st.seq.length; st.phase = 'wait'; setPads(false); status.say('Correct. Round ' + st.seq.length + ' complete.', 'ok'); st.seq = extend(st.seq); st.timers.push(setTimeout(playback, 1100)); }
  }
  function fail() {
    st.phase = 'over'; setPads(false); clearTimers();
    var score = st.best, best = score > 0 ? BG.recordBest('echo-sequence:' + st.level, score, score + (score === 1 ? ' step' : ' steps') + ' remembered', 'high') : false;
    var answer = st.seq.map(function (i) { return PADS[i].n; }).join(', ');
    status.say('That was not the next step.', 'bad');
    BG.ui.result(resultHost, 'You remembered ' + score + (score === 1 ? ' step' : ' steps'), [(best ? 'New personal best for this speed. ' : '') + 'The sequence was: ' + answer + '.', 'Tip: chunk the steps into groups of two or three and say the names quietly to yourself.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { start(controls.level()); } })]);
  }
  pads.forEach(function (b, i) { b.addEventListener('click', function () { choose(i); }); });
  document.addEventListener('keydown', function (e) {
    if (st.phase !== 'input' || e.ctrlKey || e.metaKey || e.altKey) return;
    var tag = e.target && e.target.tagName; if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
    if (/^[1-4]$/.test(e.key)) { e.preventDefault(); choose(parseInt(e.key, 10) - 1); }
  });
  BG.games.echo.state = function () { return st; };
  BG.games.echo.choose = choose;
})();
