/* Grid Lights: pressing a square flips it and its up/down/left/right neighbours. Turn every light off.
   Boards are made by pressing random squares on a cleared board, so a solution always exists. "On" is shown with a filled dot and "off" with an empty ring. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var LEVELS = { easy: { n: 4, presses: 4 }, medium: { n: 5, presses: 8 }, hard: { n: 5, presses: 14 } };

  function press(grid, n, i) {
    var r = (i / n) | 0, c = i % n, out = grid.slice();
    [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]].forEach(function (d) { var rr = r + d[0], cc = c + d[1]; if (rr >= 0 && rr < n && cc >= 0 && cc < n) out[rr * n + cc] = out[rr * n + cc] ? 0 : 1; });
    return out;
  }
  /* Returns { grid, solution } where solution is the set of squares that, pressed once each, clear the board. */
  function generate(level, rnd) {
    rnd = rnd || Math.random;
    var cfg = LEVELS[level], n = cfg.n, grid = []; for (var i = 0; i < n * n; i++) grid.push(0);
    var parity = {}, tries = 0;
    do {
      grid = grid.map(function () { return 0; }); parity = {};
      var picks = U.shuffle(Array.apply(null, { length: n * n }).map(function (_, k) { return k; }), rnd).slice(0, cfg.presses);
      picks.forEach(function (p) { grid = press(grid, n, p); parity[p] = true; });
    } while (grid.every(function (v) { return !v; }) && tries++ < 20);
    return { grid: grid, solution: Object.keys(parity).map(Number), n: n };
  }
  BG.games.gridLights = { press: press, generate: generate, LEVELS: LEVELS };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { n: 4, grid: [], start: [], solution: [], user: {}, moves: 0, over: true, level: 'easy', hints: 0 };
  var status = BG.ui.status(), resultHost = el('div', {}), movesEl = el('span', { text: 'Moves 0' }), onEl = el('span', { text: '' });
  var controls = BG.ui.controls({ id: 'grid-lights', levels: [{ v: 'easy', label: 'Easy (4x4)' }, { v: 'medium', label: 'Medium (5x5)' }, { v: 'hard', label: 'Hard (5x5, tougher)' }], newLabel: 'New puzzle', onStart: start, onRestart: function () { if (st.start.length) begin(st.start.slice(), st.solution); } });
  var hintBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Hint' });
  var meta = el('div', { class: 'game-meta', hidden: true }, [movesEl, onEl]);
  var board = el('div', { class: 'gl-board', role: 'group', 'aria-label': 'Light grid' });
  var play = el('div', { hidden: true }, [board, el('div', { class: 'btn-row', style: 'margin-top:1rem' }, [hintBtn])]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. Switch off every light.' });
  [controls.el, intro, meta, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function start(level) { st.level = level; var g = generate(level); st.start = g.grid.slice(); begin(g.grid, g.solution); }
  function begin(grid, solution) {
    st.n = Math.sqrt(grid.length); st.grid = grid; st.solution = solution; st.user = {}; st.moves = 0; st.over = false; st.hints = 0;
    intro.hidden = true; play.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost);
    board.style.gridTemplateColumns = 'repeat(' + st.n + ', minmax(0, 1fr))'; board.innerHTML = '';
    for (var i = 0; i < st.n * st.n; i++) (function (idx) { board.appendChild(el('button', { type: 'button', class: 'gl-cell', 'data-i': String(idx), onclick: function () { tap(idx); } })); })(i);
    paint(); status.say('Press a square to flip it and its neighbours.', 'info');
  }
  function paint(hintIdx) {
    var on = 0;
    Array.prototype.forEach.call(board.children, function (b, i) {
      var v = st.grid[i]; if (v) on++;
      b.className = 'gl-cell' + (v ? ' is-on' : '') + (i === hintIdx ? ' is-hint' : '');
      b.textContent = v ? '\u25CF' : '\u25CB';
      b.setAttribute('aria-label', 'Row ' + ((i / st.n | 0) + 1) + ', column ' + (i % st.n + 1) + ', light ' + (v ? 'on' : 'off') + (i === hintIdx ? ', hint: press this one' : ''));
    });
    movesEl.textContent = 'Moves ' + st.moves; onEl.textContent = on + (on === 1 ? ' light' : ' lights') + ' on';
  }
  function tap(i) {
    if (st.over) return;
    st.grid = press(st.grid, st.n, i); st.moves++; st.user[i] = !st.user[i]; paint();
    if (st.grid.every(function (v) { return !v; })) finish(); else status.say(onEl.textContent + '.', 'info');
  }
  hintBtn.addEventListener('click', function () {
    if (st.over) return;
    var need = []; for (var i = 0; i < st.n * st.n; i++) { var inSol = st.solution.indexOf(i) > -1; if (inSol !== !!st.user[i]) need.push(i); }
    if (!need.length) return;
    st.hints++; var h = U.pick(need); paint(h); status.say('Hint: press row ' + ((h / st.n | 0) + 1) + ', column ' + (h % st.n + 1) + '. It is part of a known solution.', 'info');
  });
  function finish() {
    st.over = true;
    var best = BG.recordBest('grid-lights:' + st.level, st.moves, st.moves + ' moves', 'low');
    status.say('All lights are off.', 'ok');
    BG.ui.result(resultHost, 'All lights off in ' + st.moves + ' moves', [(best ? 'New personal best (fewest moves) for ' + st.level + '. ' : '') + 'Hints used: ' + st.hints + '.', 'Tip: pressing the same square twice cancels out, so the order of presses never matters. Work row by row from the top.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'New puzzle', onclick: function () { start(controls.level()); } })]);
  }
  BG.games.gridLights.state = function () { return st; };
  BG.games.gridLights.tap = tap;
})();
