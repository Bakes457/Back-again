/* Memory Match: flip two cards at a time and find every pair. Cards carry a symbol AND a name, so colour is never the only clue. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var SYMBOLS = [
    ['\u25B2', 'Triangle'], ['\u25CF', 'Circle'], ['\u25A0', 'Square'], ['\u25C6', 'Diamond'], ['\u2605', 'Star'], ['\u2665', 'Heart'],
    ['\u263E', 'Moon'], ['\u271A', 'Plus'], ['\u2660', 'Spade'], ['\u2663', 'Club'], ['\u266A', 'Note'], ['\u2602', 'Umbrella']
  ];
  var LEVELS = { easy: { pairs: 6, cols: 4 }, medium: { pairs: 8, cols: 4 }, hard: { pairs: 12, cols: 6 } };
  var MISMATCH_MS = 900;
  function deal(level, rnd) {
    var cfg = LEVELS[level], chosen = U.shuffle(SYMBOLS, rnd).slice(0, cfg.pairs), deck = [];
    chosen.forEach(function (s, i) { deck.push({ id: i, g: s[0], n: s[1] }); deck.push({ id: i, g: s[0], n: s[1] }); });
    return U.shuffle(deck, rnd);
  }
  BG.games.memoryMatch = { deal: deal, LEVELS: LEVELS, MISMATCH_MS: MISMATCH_MS };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { deck: [], open: [], matched: {}, moves: 0, level: 'easy', t0: 0, iv: null, lock: false, over: true, started: false, pending: null };
  var btns = [], status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'memory-match', levels: [{ v: 'easy', label: 'Easy (6 pairs)' }, { v: 'medium', label: 'Medium (8 pairs)' }, { v: 'hard', label: 'Hard (12 pairs)' }], newLabel: 'New game', onStart: function (l) { begin(l, deal(l)); }, onRestart: function () { begin(st.level, deal(st.level)); } });
  var timeEl = el('span', { text: 'Time 0:00' }), movesEl = el('span', { text: 'Moves 0' }), pairsEl = el('span', { text: '' });
  var meta = el('div', { class: 'game-meta', hidden: true }, [timeEl, movesEl, pairsEl]);
  var grid = el('div', { class: 'mm-grid', role: 'group', 'aria-label': 'Memory cards', hidden: true });
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. Flip two cards per turn and find all the matching pairs.' });
  [controls.el, intro, meta, grid, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function begin(level, deck) {
    clearInterval(st.iv); clearTimeout(st.pending);
    st.level = level; st.deck = deck; st.open = []; st.matched = {}; st.moves = 0; st.lock = false; st.over = false; st.started = false;
    intro.hidden = true; grid.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost);
    grid.style.gridTemplateColumns = 'repeat(' + LEVELS[level].cols + ', minmax(0, 1fr))';
    grid.innerHTML = ''; btns = [];
    deck.forEach(function (card, i) {
      var b = el('button', { type: 'button', class: 'mm-card', 'data-i': String(i) }, [el('span', { class: 'back', 'aria-hidden': 'true', text: '?' }), el('span', { class: 'face' }, [el('span', { 'aria-hidden': 'true', text: card.g }), el('small', { text: card.n })])]);
      b.addEventListener('click', function () { flip(i); });
      btns.push(b); grid.appendChild(b); paintCard(i);
    });
    timeEl.textContent = 'Time 0:00'; paintStats();
    status.say('Game ready. Select any card to begin.', 'info');
  }
  function paintCard(i) {
    var b = btns[i], card = st.deck[i], isOpen = st.open.indexOf(i) > -1, isMatched = !!st.matched[card.id];
    b.className = 'mm-card' + (isOpen ? ' is-open' : '') + (isMatched ? ' is-matched' : '');
    b.setAttribute('aria-label', 'Card ' + (i + 1) + ', ' + (isMatched ? card.n + ', matched' : isOpen ? card.n + ', face up' : 'face down'));
    b.setAttribute('aria-pressed', isOpen || isMatched ? 'true' : 'false');
    b.disabled = isMatched;
  }
  function paintStats() { movesEl.textContent = 'Moves ' + st.moves; pairsEl.textContent = Object.keys(st.matched).length + ' of ' + (st.deck.length / 2) + ' pairs found'; }
  function flip(i) {
    if (st.over || st.lock) return;
    if (st.open.indexOf(i) > -1 || st.matched[st.deck[i].id]) return;
    if (!st.started) { st.started = true; st.t0 = Date.now(); st.iv = setInterval(function () { timeEl.textContent = 'Time ' + U.fmtTime((Date.now() - st.t0) / 1000); }, 1000); }
    st.open.push(i); paintCard(i);
    if (st.open.length < 2) { status.say(st.deck[i].n + ' is face up. Pick a second card.', 'info'); return; }
    st.moves++; paintStats();
    var a = st.deck[st.open[0]], b = st.deck[st.open[1]];
    if (a.id === b.id) {
      st.matched[a.id] = true; var pair = st.open.slice(); st.open = []; pair.forEach(paintCard); paintStats();
      if (Object.keys(st.matched).length === st.deck.length / 2) { finish(); } else { status.say('Match: two ' + a.n.toLowerCase() + 's.', 'ok'); }
    } else {
      st.lock = true; status.say('No match: ' + a.n + ' and ' + b.n + '. They will flip back.', 'bad');
      st.pending = setTimeout(function () { var old = st.open.slice(); st.open = []; st.lock = false; old.forEach(paintCard); }, MISMATCH_MS);
    }
  }
  function finish() {
    st.over = true; clearInterval(st.iv);
    var secs = Math.round((Date.now() - st.t0) / 1000);
    var bestMoves = BG.recordBest('memory-match:' + st.level, st.moves, st.moves + ' moves, ' + U.fmtTime(secs), 'low');
    status.say('All pairs found.', 'ok');
    BG.ui.result(resultHost, 'All pairs found in ' + st.moves + ' moves', [(bestMoves ? 'New personal best (fewest moves) for ' + st.level + '. ' : '') + 'Time: ' + U.fmtTime(secs) + '.', 'Perfect play on this board is ' + (st.deck.length / 2) + ' moves, but only with luck. A good habit is to remember where each unmatched card was the first time you saw it.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { begin(st.level, deal(st.level)); } })]);
  }
  BG.games.memoryMatch.state = function () { return st; };
})();
