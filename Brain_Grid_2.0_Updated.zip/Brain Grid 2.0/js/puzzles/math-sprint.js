/* Math Sprint: arithmetic practice. Timed (60 seconds) or untimed (10 questions). Not an intelligence assessment. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var TIMED_SECONDS = 60, UNTIMED_COUNT = 10;
  function ri(rnd, a, b) { return a + Math.floor(rnd() * (b - a + 1)); }
  /* Every generated question has a whole-number answer. */
  function makeQuestion(level, rnd) {
    rnd = rnd || Math.random;
    var a, b, c, t;
    if (level === 'easy') {
      t = ri(rnd, 0, 1); a = ri(rnd, 2, 20); b = ri(rnd, 1, 20);
      if (t === 0) return { text: a + ' + ' + b, answer: a + b };
      if (b > a) { var x = a; a = b; b = x; }
      return { text: a + ' \u2212 ' + b, answer: a - b };
    }
    if (level === 'medium') {
      t = ri(rnd, 0, 3);
      if (t === 0) { a = ri(rnd, 20, 99); b = ri(rnd, 11, 60); return { text: a + ' + ' + b, answer: a + b }; }
      if (t === 1) { a = ri(rnd, 40, 150); b = ri(rnd, 11, 39); return { text: a + ' \u2212 ' + b, answer: a - b }; }
      if (t === 2) { a = ri(rnd, 3, 12); b = ri(rnd, 3, 12); return { text: a + ' \u00D7 ' + b, answer: a * b }; }
      b = ri(rnd, 2, 12); c = ri(rnd, 2, 12); return { text: (b * c) + ' \u00F7 ' + b, answer: c };
    }
    t = ri(rnd, 0, 4);
    if (t === 0) { a = ri(rnd, 12, 25); b = ri(rnd, 6, 19); return { text: a + ' \u00D7 ' + b, answer: a * b }; }
    if (t === 1) { b = ri(rnd, 6, 19); c = ri(rnd, 6, 25); return { text: (b * c) + ' \u00F7 ' + b, answer: c }; }
    if (t === 2) { a = ri(rnd, 3, 12); b = ri(rnd, 3, 12); c = ri(rnd, 10, 60); return { text: '(' + a + ' \u00D7 ' + b + ') + ' + c, answer: a * b + c }; }
    if (t === 3) { a = ri(rnd, 100, 400); b = ri(rnd, 50, 99); c = ri(rnd, 10, 49); return { text: a + ' + ' + b + ' \u2212 ' + c, answer: a + b - c }; }
    a = ri(rnd, 3, 9); b = ri(rnd, 3, 9); c = ri(rnd, 2, 9); return { text: a + ' \u00D7 ' + b + ' \u2212 ' + c, answer: a * b - c };
  }
  BG.games.mathSprint = { makeQuestion: makeQuestion, TIMED_SECONDS: TIMED_SECONDS, UNTIMED_COUNT: UNTIMED_COUNT };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { level: 'easy', timed: true, q: null, asked: 0, correct: 0, left: 0, iv: null, over: true, streak: 0 };
  var status = BG.ui.status(), resultHost = el('div', {});
  var timedBox = el('input', { type: 'checkbox', id: 'timed-toggle' }); timedBox.checked = BG.getPref('math-sprint', 'timed') !== false;
  var timedLabel = el('label', { for: 'timed-toggle', text: 'Timed round (60 seconds)' });
  var extra = el('span', { class: 'controls', style: 'margin:0' }, [timedBox, timedLabel]);
  var controls = BG.ui.controls({ id: 'math-sprint', levels: [{ v: 'easy', label: 'Easy' }, { v: 'medium', label: 'Medium' }, { v: 'hard', label: 'Hard' }], extra: [extra], newLabel: 'New round', onStart: start, onRestart: function () { start(controls.level()); } });
  var clock = el('span', { text: '' }), scoreEl = el('span', { text: '' });
  var meta = el('div', { class: 'game-meta', hidden: true }, [clock, scoreEl]);
  var prompt = el('p', { class: 'big-prompt', 'aria-live': 'off' });
  var input = el('input', { type: 'text', id: 'math-input', inputmode: 'numeric', autocomplete: 'off' });
  var checkBtn = el('button', { type: 'submit', class: 'btn btn-primary', text: 'Answer' });
  var form = el('form', { class: 'answer-row', novalidate: 'novalidate' }, [el('div', { class: 'field' }, [el('label', { for: 'math-input', text: 'Your answer' }), input]), checkBtn]);
  var play = el('div', { hidden: true }, [prompt, form]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty, decide whether you want a timed round, and press Start.' });
  [controls.el, intro, meta, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function start(level) {
    BG.setPref('math-sprint', 'timed', timedBox.checked);
    st.level = level; st.timed = timedBox.checked; st.asked = 0; st.correct = 0; st.over = false; st.streak = 0;
    clearInterval(st.iv); intro.hidden = true; play.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost);
    input.disabled = false; checkBtn.disabled = false;
    if (st.timed) { st.left = TIMED_SECONDS; st.iv = setInterval(function () { st.left--; paint(); if (st.left <= 0) finish(); }, 1000); }
    status.say(st.timed ? 'Go. You have 60 seconds.' : 'Answer ' + UNTIMED_COUNT + ' questions at your own pace.', 'info');
    next(); paint();
  }
  function paint() {
    clock.textContent = st.timed ? 'Time left ' + Math.max(0, st.left) + 's' : 'Question ' + Math.min(st.asked, UNTIMED_COUNT) + ' of ' + UNTIMED_COUNT;
    scoreEl.textContent = 'Correct ' + st.correct + ' of ' + (st.over ? st.asked : Math.max(0, st.asked - 1));
  }
  function next() { st.q = makeQuestion(st.level); st.asked++; prompt.textContent = st.q.text + ' = ?'; input.value = ''; input.focus(); paint(); }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (st.over) return;
    var raw = input.value.replace(/\s/g, '').replace(/\u2212/g, '-');
    if (!/^-?\d+$/.test(raw)) { status.say('Enter a whole number.', 'bad'); return; }
    var right = parseInt(raw, 10) === st.q.answer;
    if (right) { st.correct++; st.streak++; status.say(st.q.text + ' = ' + st.q.answer + '.' + (st.streak >= 3 ? ' ' + st.streak + ' in a row.' : ''), 'ok'); }
    else { st.streak = 0; status.say(st.q.text + ' = ' + st.q.answer + ', not ' + parseInt(raw, 10) + '.', 'bad'); }
    if (!st.timed && st.asked >= UNTIMED_COUNT) { finish(); return; }
    next();
  });
  function finish() {
    if (st.over) return;
    st.over = true; clearInterval(st.iv);
    var answered = st.timed ? st.asked - 1 : st.asked; // in timed mode the last question was shown but not answered
    var accuracy = answered > 0 ? Math.round(100 * st.correct / answered) : 0;
    input.disabled = true; checkBtn.disabled = true; play.hidden = true; paint();
    var id = 'math-sprint:' + st.level + (st.timed ? ':timed' : ':untimed');
    var best = BG.recordBest(id, st.correct, st.correct + ' correct, ' + accuracy + '% accuracy', 'high');
    status.say('Round finished.', 'info');
    var panel = BG.ui.result(resultHost, 'Round complete: ' + st.correct + ' correct', [(best ? 'New personal best for this setting. ' : '') + 'You answered ' + answered + ' questions with ' + accuracy + '% accuracy.', 'This is arithmetic practice. It says nothing about intelligence.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { start(controls.level()); } })]);
    panel.insertBefore(el('div', { class: 'score-board' }, [el('div', {}, [el('b', { text: String(st.correct) }), 'Correct']), el('div', {}, [el('b', { text: answered + '' }), 'Answered']), el('div', {}, [el('b', { text: accuracy + '%' }), 'Accuracy'])]), panel.children[1]);
  }
  BG.games.mathSprint.state = function () { return st; };
})();
