/* Drop Four: take turns dropping discs into a 7-column board. First to line up four wins. You play the solid discs and go first;
   the computer plays rings. Easy blocks and wins when it can and otherwise picks randomly; medium and hard search ahead (minimax). */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var COLS = 7, ROWS = 6, DEPTH = { easy: 0, medium: 3, hard: 5 };

  function dropRow(b, c) { for (var r = ROWS - 1; r >= 0; r--) if (!b[r * COLS + c]) return r; return -1; }
  function lines() {
    var out = [], r, c, k;
    for (r = 0; r < ROWS; r++) for (c = 0; c < COLS; c++) {
      [[0, 1], [1, 0], [1, 1], [1, -1]].forEach(function (d) {
        var cells = []; for (k = 0; k < 4; k++) { var rr = r + d[0] * k, cc = c + d[1] * k; if (rr < 0 || rr >= ROWS || cc < 0 || cc >= COLS) return; cells.push(rr * COLS + cc); }
        out.push(cells);
      });
    }
    return out;
  }
  var LINES = lines();
  function winner(b) { for (var i = 0; i < LINES.length; i++) { var l = LINES[i], p = b[l[0]]; if (p && p === b[l[1]] && p === b[l[2]] && p === b[l[3]]) return { p: p, cells: l }; } return null; }
  function full(b) { for (var c = 0; c < COLS; c++) if (!b[c]) return false; return true; }
  function validCols(b) { var o = []; for (var c = 0; c < COLS; c++) if (!b[c]) o.push(c); return o; }
  function place(b, c, p) { var n = b.slice(), r = dropRow(b, c); n[r * COLS + c] = p; return n; }
  function score(b) {
    var s = 0, i, c;
    for (c = 0; c < ROWS; c++) { if (b[c * COLS + 3] === 2) s += 3; else if (b[c * COLS + 3] === 1) s -= 3; }
    LINES.forEach(function (l) {
      var a = 0, h = 0, e = 0; for (i = 0; i < 4; i++) { var v = b[l[i]]; if (v === 2) a++; else if (v === 1) h++; else e++; }
      if (a && h) return;
      if (a === 3) s += 6; else if (a === 2) s += 2; if (h === 3) s -= 7; else if (h === 2) s -= 2;
    });
    return s;
  }
  function minimax(b, depth, alpha, beta, maxing) {
    var w = winner(b); if (w) return w.p === 2 ? 100000 + depth : -100000 - depth;
    if (full(b)) return 0; if (depth === 0) return score(b);
    var cols = validCols(b).sort(function (x, y) { return Math.abs(x - 3) - Math.abs(y - 3); }), best, c, v;
    if (maxing) { best = -Infinity; for (var i = 0; i < cols.length; i++) { c = cols[i]; v = minimax(place(b, c, 2), depth - 1, alpha, beta, false); if (v > best) best = v; if (best > alpha) alpha = best; if (alpha >= beta) break; } return best; }
    best = Infinity; for (var j = 0; j < cols.length; j++) { c = cols[j]; v = minimax(place(b, c, 1), depth - 1, alpha, beta, true); if (v < best) best = v; if (best < beta) beta = best; if (alpha >= beta) break; } return best;
  }
  /* Choose the computer's column (the computer is player 2). */
  function chooseMove(b, level, rnd) {
    rnd = rnd || Math.random; var cols = validCols(b), c;
    for (var i = 0; i < cols.length; i++) if (winner(place(b, cols[i], 2))) return cols[i];
    for (var j = 0; j < cols.length; j++) if (winner(place(b, cols[j], 1))) return cols[j];
    if (DEPTH[level] === 0) return cols[Math.floor(rnd() * cols.length)];
    var best = -Infinity, pick = [];
    cols.forEach(function (col) { var v = minimax(place(b, col, 2), DEPTH[level] - 1, -Infinity, Infinity, false); if (v > best) { best = v; pick = [col]; } else if (v === best) pick.push(col); });
    c = pick[Math.floor(rnd() * pick.length)]; return c;
  }
  BG.games.dropFour = { dropRow: dropRow, winner: winner, chooseMove: chooseMove, place: place, validCols: validCols, COLS: COLS, ROWS: ROWS };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { b: [], level: 'easy', over: true, turn: 1, moves: 0, timer: null };
  var status = BG.ui.status(), resultHost = el('div', {}), movesEl = el('span', { text: 'Your moves 0' });
  var controls = BG.ui.controls({ id: 'drop-four', levels: [{ v: 'easy', label: 'Easy' }, { v: 'medium', label: 'Medium' }, { v: 'hard', label: 'Hard' }], startLabel: 'Start', newLabel: 'New game', restartLabel: 'Restart', onStart: start, onRestart: function () { start(st.level); } });
  var drops = [], cells = [];
  var dropRowEl = el('div', { class: 'df-drops', role: 'group', 'aria-label': 'Drop a disc into a column' });
  for (var c = 0; c < COLS; c++) (function (col) { var b = el('button', { type: 'button', class: 'btn df-drop', 'aria-label': 'Drop in column ' + (col + 1), text: String(col + 1) }); b.addEventListener('click', function () { human(col); }); drops.push(b); dropRowEl.appendChild(b); })(c);
  var board = el('div', { class: 'df-board', role: 'img', 'aria-label': 'Game board' });
  for (var i = 0; i < ROWS * COLS; i++) { var cell = el('div', { class: 'df-cell' }); cells.push(cell); board.appendChild(cell); }
  var boardText = el('p', { class: 'sr-only', 'aria-live': 'off' });
  var meta = el('div', { class: 'game-meta', hidden: true }, [movesEl]);
  var play = el('div', { hidden: true }, [dropRowEl, board, boardText, el('p', { class: 'small muted', text: 'You are the solid discs and move first. Press a column number button, or keys 1 to 7.' })]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose how strong the computer is and press Start. Line up four discs in any direction.' });
  [controls.el, intro, meta, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function start(level) {
    clearTimeout(st.timer); st.level = level; st.b = []; for (var i = 0; i < ROWS * COLS; i++) st.b.push(0);
    st.over = false; st.turn = 1; st.moves = 0; intro.hidden = true; play.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost);
    paint(); status.say('Your turn. Drop a disc.', 'info');
  }
  function paint(win) {
    st.b.forEach(function (v, i) {
      var r = (i / COLS | 0), c = i % COLS;
      cells[i].className = 'df-cell' + (v === 1 ? ' df-me' : v === 2 ? ' df-cpu' : '') + (win && win.cells.indexOf(i) > -1 ? ' df-win' : '');
      cells[i].textContent = v === 1 ? '\u25CF' : v === 2 ? '\u25EF' : '';
    });
    drops.forEach(function (b, c) { b.disabled = st.over || st.turn !== 1 || !!st.b[c]; });
    movesEl.textContent = 'Your moves ' + st.moves;
    var rowsTxt = []; for (var r = 0; r < ROWS; r++) rowsTxt.push('Row ' + (r + 1) + ': ' + st.b.slice(r * COLS, r * COLS + COLS).map(function (v) { return v === 1 ? 'you' : v === 2 ? 'computer' : 'empty'; }).join(', '));
    board.setAttribute('aria-label', 'Game board. ' + rowsTxt.join('. '));
  }
  function human(c) {
    if (st.over || st.turn !== 1 || dropRow(st.b, c) < 0) return;
    st.b = place(st.b, c, 1); st.moves++; st.turn = 2;
    var w = winner(st.b); if (w) return end(w, 1); if (full(st.b)) return end(null, 0);
    paint(); status.say('You dropped in column ' + (c + 1) + '. The computer is thinking.', 'info');
    st.timer = setTimeout(cpu, 450);
  }
  function cpu() {
    if (st.over) return;
    var c = chooseMove(st.b, st.level); st.b = place(st.b, c, 2); st.turn = 1;
    var w = winner(st.b); if (w) return end(w, 2); if (full(st.b)) return end(null, 0);
    paint(); status.say('The computer dropped in column ' + (c + 1) + '. Your turn.', 'info');
  }
  function end(w, who) {
    st.over = true; paint(w);
    if (who === 1) {
      var best = BG.recordBest('drop-four:' + st.level, st.moves, 'Won in ' + st.moves + ' moves', 'low');
      status.say('You lined up four.', 'ok');
      BG.ui.result(resultHost, 'You win in ' + st.moves + ' moves', [(best ? 'New personal best (fewest moves) for ' + st.level + '. ' : '') + 'Your four discs are outlined on the board.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { start(controls.level()); } })]);
    } else if (who === 2) {
      status.say('The computer lined up four.', 'bad');
      BG.ui.result(resultHost, 'The computer wins this one', ['Its four rings are outlined on the board.', 'Tip: build two threats at once so the computer can only block one.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Rematch', onclick: function () { start(controls.level()); } })]);
    } else {
      status.say('The board is full.', 'info');
      BG.ui.result(resultHost, 'A draw', ['Neither side lined up four.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { start(controls.level()); } })]);
    }
  }
  document.addEventListener('keydown', function (e) {
    if (st.over || st.turn !== 1 || play.hidden || e.ctrlKey || e.metaKey || e.altKey) return;
    var tag = e.target && e.target.tagName; if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
    if (/^[1-7]$/.test(e.key)) { e.preventDefault(); human(parseInt(e.key, 10) - 1); }
  });
  BG.games.dropFour.state = function () { return st; };
  BG.games.dropFour.human = human;
})();
