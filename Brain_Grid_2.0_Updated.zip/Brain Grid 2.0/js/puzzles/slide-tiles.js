/* Slide Tiles: put the numbered tiles in order by sliding them into the gap.
   Boards are made by shuffling a solved board with legal moves only, so every board is solvable. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var SIZES = { easy: 3, medium: 4, hard: 5 };

  function solved(n) { var g = []; for (var i = 1; i < n * n; i++) g.push(i); g.push(0); return g; }
  function neighboursOf(i, n) { var r = (i / n) | 0, c = i % n, o = []; if (r > 0) o.push(i - n); if (r < n - 1) o.push(i + n); if (c > 0) o.push(i - 1); if (c < n - 1) o.push(i + 1); return o; }
  function isSolved(g) { return g.every(function (v, i) { return i === g.length - 1 ? v === 0 : v === i + 1; }); }
  function shuffle(n, rnd) {
    rnd = rnd || Math.random;
    var g = solved(n), blank = n * n - 1, prev = -1, steps = n * n * 24;
    for (var s = 0; s < steps; s++) {
      var opts = neighboursOf(blank, n).filter(function (x) { return x !== prev; }), pick = opts[Math.floor(rnd() * opts.length)];
      g[blank] = g[pick]; g[pick] = 0; prev = blank; blank = pick;
    }
    if (isSolved(g)) return shuffle(n, rnd);
    return g;
  }
  BG.games.slideTiles = { solved: solved, shuffle: shuffle, isSolved: isSolved, neighboursOf: neighboursOf, SIZES: SIZES };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { n: 3, grid: [], moves: 0, t0: 0, iv: null, over: true, level: 'easy', start: [] };
  var status = BG.ui.status(), resultHost = el('div', {}), timeEl = el('span', { text: 'Time 0:00' }), movesEl = el('span', { text: 'Moves 0' });
  var controls = BG.ui.controls({ id: 'slide-tiles', levels: [{ v: 'easy', label: 'Easy (3x3)' }, { v: 'medium', label: 'Medium (4x4)' }, { v: 'hard', label: 'Hard (5x5)' }], newLabel: 'New puzzle', onStart: start, onRestart: function () { if (st.start.length) begin(st.start.slice()); } });
  var meta = el('div', { class: 'game-meta', hidden: true }, [timeEl, movesEl]);
  var board = el('div', { class: 'sl-board', role: 'group', 'aria-label': 'Sliding tile board' });
  var play = el('div', { hidden: true }, [board, el('p', { class: 'small muted', text: 'Select a tile next to the gap to slide it. Keyboard: an arrow key slides the neighbouring tile in that direction into the gap.' })]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a size and press Start. Order the tiles from 1 upward, with the gap in the last square.' });
  [controls.el, intro, meta, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function start(level) { st.level = level; st.n = SIZES[level]; st.start = shuffle(st.n); begin(st.start.slice()); }
  function begin(g) {
    st.grid = g; st.moves = 0; st.over = false; clearInterval(st.iv); st.t0 = 0; timeEl.textContent = 'Time 0:00';
    intro.hidden = true; play.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost);
    board.style.gridTemplateColumns = 'repeat(' + st.n + ', minmax(0, 1fr))'; paint(); status.say('Slide the tiles into order.', 'info');
  }
  function paint() {
    board.innerHTML = '';
    var blank = st.grid.indexOf(0), near = neighboursOf(blank, st.n);
    st.grid.forEach(function (v, i) {
      if (!v) { board.appendChild(el('div', { class: 'sl-gap', 'aria-label': 'gap, row ' + ((i / st.n | 0) + 1) + ' column ' + (i % st.n + 1), role: 'img' })); return; }
      var movable = near.indexOf(i) > -1, ok = v === i + 1;
      board.appendChild(el('button', { type: 'button', class: 'sl-tile' + (ok ? ' is-home' : ''), 'data-i': String(i), 'aria-label': 'Tile ' + v + ', row ' + ((i / st.n | 0) + 1) + ' column ' + (i % st.n + 1) + (ok ? ', in place' : '') + (movable ? ', can slide' : ''), text: String(v) }));
    });
    movesEl.textContent = 'Moves ' + st.moves;
  }
  function slide(i) {
    if (st.over) return false;
    var blank = st.grid.indexOf(0);
    if (neighboursOf(blank, st.n).indexOf(i) < 0) { status.say('That tile is not next to the gap.', 'bad'); return false; }
    if (!st.t0) { st.t0 = Date.now(); st.iv = setInterval(function () { timeEl.textContent = 'Time ' + U.fmtTime((Date.now() - st.t0) / 1000); }, 1000); }
    st.grid[blank] = st.grid[i]; st.grid[i] = 0; st.moves++; paint();
    if (isSolved(st.grid)) finish(); return true;
  }
  function finish() {
    st.over = true; clearInterval(st.iv);
    var secs = st.t0 ? Math.round((Date.now() - st.t0) / 1000) : 0;
    var best = BG.recordBest('slide-tiles:' + st.level, st.moves, st.moves + ' moves, ' + U.fmtTime(secs), 'low');
    status.say('Solved.', 'ok');
    BG.ui.result(resultHost, 'Solved in ' + st.moves + ' moves', [(best ? 'New personal best (fewest moves) for ' + st.level + '. ' : '') + 'Time: ' + U.fmtTime(secs) + '.', 'Tip: solve the top row first, then the next row, and finish the last two rows column by column.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'New puzzle', onclick: function () { start(controls.level()); } })]);
  }
  board.addEventListener('click', function (e) { var b = e.target.closest('.sl-tile'); if (b) slide(parseInt(b.getAttribute('data-i'), 10)); });
  board.addEventListener('keydown', function (e) {
    var map = { ArrowUp: n => st.n, ArrowDown: n => -st.n, ArrowLeft: () => 1, ArrowRight: () => -1 }, f = map[e.key];
    if (!f || st.over) return; e.preventDefault();
    var blank = st.grid.indexOf(0), c = blank % st.n, target = blank + f();
    if ((e.key === 'ArrowLeft' && c === st.n - 1) || (e.key === 'ArrowRight' && c === 0) || target < 0 || target >= st.n * st.n) return;
    if (slide(target)) { var t = board.querySelector('[data-i="' + blank + '"]'); if (t) t.focus(); }
  });
  BG.games.slideTiles.state = function () { return st; };
  BG.games.slideTiles.slide = slide;
})();
