/* WordGrid: guess the hidden five-letter word. Each guess is marked tile by tile. Original code, word list and design.
   Marks use a symbol as well as colour: check = right letter, right place; diamond = in the word, wrong place; cross = not in the word. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var W = window.BG_WORDS || { answers: '', valid: '' };
  var ANSWERS = W.answers.split(' ').filter(Boolean), VALID = {};
  W.valid.split(' ').forEach(function (w) { VALID[w] = true; });
  ANSWERS.forEach(function (w) { VALID[w] = true; });
  var LEN = 5, TRIES = { easy: 7, standard: 6, hard: 6 };

  /* Two passes so repeated letters are counted correctly. */
  function evaluate(guess, answer) {
    var res = [], left = {}, i;
    for (i = 0; i < LEN; i++) { res.push('absent'); if (guess[i] !== answer[i]) left[answer[i]] = (left[answer[i]] || 0) + 1; }
    for (i = 0; i < LEN; i++) { if (guess[i] === answer[i]) res[i] = 'correct'; }
    for (i = 0; i < LEN; i++) { if (res[i] !== 'correct' && left[guess[i]] > 0) { res[i] = 'present'; left[guess[i]]--; } }
    return res;
  }
  function dailyAnswer(dateKey) { return ANSWERS[U.hash('wordgrid|' + dateKey) % ANSWERS.length]; }
  /* Hard mode: revealed hints must be reused in later guesses. Returns an error message or ''. */
  function hardModeError(guess, history) {
    for (var h = 0; h < history.length; h++) {
      var g = history[h].guess, r = history[h].marks;
      for (var i = 0; i < LEN; i++) {
        if (r[i] === 'correct' && guess[i] !== g[i]) return 'Hard mode: letter ' + (i + 1) + ' must be ' + g[i].toUpperCase() + '.';
        if (r[i] === 'present' && guess.indexOf(g[i]) < 0) return 'Hard mode: your guess must include ' + g[i].toUpperCase() + '.';
      }
    }
    return '';
  }
  BG.games.wordgrid = { evaluate: evaluate, dailyAnswer: dailyAnswer, hardModeError: hardModeError, isValid: function (w) { return !!VALID[w]; }, answers: ANSWERS, TRIES: TRIES };

  var root = document.getElementById('game-root');
  if (!root) return;
  var MARK = { correct: '\u2713', present: '\u25C6', absent: '\u2715' }, NAME = { correct: 'right place', present: 'wrong place', absent: 'not in the word' };
  var st = { answer: '', guesses: [], current: '', max: 6, mode: 'daily', level: 'standard', over: true, dateKey: '' };
  var status = BG.ui.status(), resultHost = el('div', {});
  var modeSel = el('select', { id: 'mode-select' }, [el('option', { value: 'daily', text: 'Daily word' }), el('option', { value: 'practice', text: 'Practice (random word)' })]);
  var modeSaved = BG.getPref('wordgrid', 'mode'); if (modeSaved === 'daily' || modeSaved === 'practice') modeSel.value = modeSaved;
  var modeWrap = el('span', { class: 'controls', style: 'margin:0' }, [el('label', { for: 'mode-select', text: 'Mode' }), modeSel]);
  var controls = BG.ui.controls({ id: 'wordgrid', levels: [{ v: 'easy', label: 'Easy (7 guesses)' }, { v: 'standard', label: 'Standard (6 guesses)' }, { v: 'hard', label: 'Hard (6, reuse your hints)' }], extra: [modeWrap], newLabel: 'New word', restartLabel: 'Give up', onStart: start, onRestart: giveUp });
  controls.select.value = BG.getPref('wordgrid', 'level') || 'standard';
  var board = el('div', { class: 'wg-board', role: 'group', 'aria-label': 'Guess board' });
  var kbd = el('div', { class: 'wg-kbd', role: 'group', 'aria-label': 'On-screen keyboard' });
  var play = el('div', { hidden: true }, [board, kbd]);
  var intro = el('div', { class: 'placeholder-box', text: 'Pick a mode and difficulty, then press Start. In Daily mode everyone with the same local date gets the same word.' });
  [controls.el, intro, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });
  var rows = [], keys = {};
  ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'].forEach(function (row, ri) {
    var r = el('div', { class: 'wg-krow' });
    if (ri === 2) r.appendChild(el('button', { type: 'button', class: 'wg-key wg-wide', 'data-k': 'Enter', text: 'Enter' }));
    row.split('').forEach(function (ch) { var b = el('button', { type: 'button', class: 'wg-key', 'data-k': ch, 'aria-label': ch.toUpperCase(), text: ch.toUpperCase() }); keys[ch] = b; r.appendChild(b); });
    if (ri === 2) r.appendChild(el('button', { type: 'button', class: 'wg-key wg-wide', 'data-k': 'Backspace', 'aria-label': 'Backspace', text: 'Del' }));
    kbd.appendChild(r);
  });
  kbd.addEventListener('click', function (e) { var b = e.target.closest('[data-k]'); if (b) { press(b.getAttribute('data-k')); b.blur(); } });

  function dailyKey() { return BG.dateKey(); }
  function start() {
    intro.hidden = true;
    st.level = controls.level(); st.mode = modeSel.value; BG.setPref('wordgrid', 'mode', st.mode);
    st.max = TRIES[st.level]; st.dateKey = dailyKey();
    if (st.mode === 'daily') {
      var done = BG.getPref('wordgrid', 'daily');
      if (typeof done === 'string' && done.indexOf(st.dateKey + '|') === 0) {
        st.answer = dailyAnswer(st.dateKey); st.guesses = []; st.current = ''; st.over = true; build();
        var p = done.split('|');
        status.say('You already played today\u2019s daily word (' + (p[1] === 'won' ? 'solved in ' + p[2] : 'not solved') + '). Switch to Practice for more, or come back tomorrow.', 'info');
        play.hidden = true; return;
      }
      st.answer = dailyAnswer(st.dateKey);
    } else st.answer = U.pick(ANSWERS);
    st.guesses = []; st.current = ''; st.over = false;
    BG.ui.clearResult(resultHost); build();
    /* Move focus off the Start button so Enter submits a guess instead of restarting. */
    board.setAttribute('tabindex', '-1'); board.focus();
    status.say('Type a five-letter word and press Enter. ' + st.max + ' guesses.', 'info');
  }
  function build() {
    play.hidden = false; board.innerHTML = ''; rows = [];
    Object.keys(keys).forEach(function (k) { keys[k].className = 'wg-key'; keys[k].removeAttribute('data-s'); keys[k].setAttribute('aria-label', k.toUpperCase()); });
    for (var r = 0; r < st.max; r++) {
      var row = el('div', { class: 'wg-row', role: 'group', 'aria-label': 'Guess ' + (r + 1) }), tiles = [];
      for (var c = 0; c < LEN; c++) { var t = el('div', { class: 'wg-tile', 'aria-label': 'empty' }, [el('span', { class: 'wg-l' }), el('span', { class: 'wg-m', 'aria-hidden': 'true' })]); tiles.push(t); row.appendChild(t); }
      board.appendChild(row); rows.push(tiles);
    }
  }
  function paintCurrent() {
    var r = st.guesses.length; if (r >= st.max) return;
    for (var c = 0; c < LEN; c++) { var ch = st.current[c] || ''; rows[r][c].firstChild.textContent = ch.toUpperCase(); rows[r][c].setAttribute('aria-label', ch ? 'letter ' + ch.toUpperCase() : 'empty'); rows[r][c].classList.toggle('is-filled', !!ch); }
  }
  function press(k) {
    if (st.over) return;
    if (k === 'Enter') return submit();
    if (k === 'Backspace') { st.current = st.current.slice(0, -1); paintCurrent(); return; }
    if (/^[a-z]$/.test(k) && st.current.length < LEN) { st.current += k; paintCurrent(); }
  }
  function submit() {
    if (st.current.length < LEN) { status.say('Not enough letters. Words have ' + LEN + ' letters.', 'bad'); return; }
    if (!VALID[st.current]) { status.say(st.current.toUpperCase() + ' is not in the word list.', 'bad'); return; }
    if (st.level === 'hard') { var err = hardModeError(st.current, st.guesses); if (err) { status.say(err, 'bad'); return; } }
    var marks = evaluate(st.current, st.answer), r = st.guesses.length, g = st.current;
    st.guesses.push({ guess: g, marks: marks }); st.current = '';
    var summary = [];
    marks.forEach(function (m, i) {
      var t = rows[r][i]; t.firstChild.textContent = g[i].toUpperCase(); t.dataset.s = m; t.lastChild.textContent = MARK[m]; t.classList.add('is-filled');
      t.setAttribute('aria-label', 'letter ' + g[i].toUpperCase() + ', ' + NAME[m]); summary.push(g[i].toUpperCase() + ' ' + NAME[m]);
      var rank = { correct: 3, present: 2, absent: 1 }, k = keys[g[i]], cur = k.getAttribute('data-s');
      if (!cur || rank[m] > rank[cur]) { k.setAttribute('data-s', m); k.setAttribute('aria-label', g[i].toUpperCase() + ', ' + NAME[m]); }
    });
    if (g === st.answer) return finish(true);
    if (st.guesses.length >= st.max) return finish(false);
    status.say(summary.join('; ') + '. ' + (st.max - st.guesses.length) + ' guesses left.', 'info');
  }
  function shareText(won) {
    var lines = st.guesses.map(function (x) { return x.marks.map(function (m) { return m === 'correct' ? '\u2713' : m === 'present' ? '\u25C6' : '\u00B7'; }).join(' '); });
    return 'WordGrid ' + (st.mode === 'daily' ? st.dateKey : 'practice') + ' ' + (won ? st.guesses.length : 'X') + '/' + st.max + '\n' + lines.join('\n');
  }
  function finish(won) {
    st.over = true;
    var n = st.guesses.length, isBest = false;
    if (won && st.mode === 'daily') isBest = BG.recordBest('wordgrid:' + st.level, n, n + ' guesses', 'low');
    else if (won) isBest = BG.recordBest('wordgrid:' + st.level, n, n + ' guesses', 'low');
    if (st.mode === 'daily') BG.setPref('wordgrid', 'daily', st.dateKey + '|' + (won ? 'won|' + n : 'lost|0'));
    var copyBtn = el('button', { type: 'button', class: 'btn', text: 'Copy my result', onclick: function () {
      var t = shareText(won);
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function () { status.say('Result copied to your clipboard.', 'info'); }, function () { status.say('Could not copy. Select and copy this instead: ' + t.replace(/\n/g, ' / '), 'bad'); });
      else status.say('Copying is not available in this browser.', 'bad');
    } });
    status.say(won ? 'You solved it.' : 'Out of guesses.', won ? 'ok' : 'info');
    BG.ui.result(resultHost, won ? 'Solved in ' + n + (n === 1 ? ' guess' : ' guesses') : 'The word was ' + st.answer.toUpperCase(), [(isBest ? 'New personal best for ' + st.level + '. ' : '') + (won ? 'The word was ' + st.answer.toUpperCase() + '.' : 'Every guess teaches you something. Try again with a fresh word in Practice mode.'), st.mode === 'daily' ? 'Come back tomorrow for a new daily word. Your result is saved on this device only.' : 'Press New word to play again.'], [copyBtn, el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again (practice)', onclick: function () { modeSel.value = 'practice'; controls.startBtn.click(); } })]);
  }
  function giveUp() {
    if (st.over || !st.answer) return;
    finish(false);
  }
  document.addEventListener('keydown', function (e) {
    if (st.over || e.ctrlKey || e.metaKey || e.altKey || play.hidden) return;
    var t = e.target, tag = t && t.tagName;
    if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
    if (e.key === 'Enter') { if (tag === 'BUTTON') return; e.preventDefault(); press('Enter'); }
    else if (e.key === 'Backspace') { e.preventDefault(); press('Backspace'); }
    else if (/^[a-zA-Z]$/.test(e.key)) { press(e.key.toLowerCase()); }
  });
  BG.games.wordgrid.state = function () { return st; };
  BG.games.wordgrid.press = press;
})();
