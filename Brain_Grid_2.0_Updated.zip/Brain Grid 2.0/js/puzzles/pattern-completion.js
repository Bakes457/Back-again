/* Pattern Completion: one item is missing from a sequence of shapes. Choose the option that continues the rule. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el, P = BG.pools;
  var COUNT = 6;
  BG.games.patternCompletion = { COUNT: COUNT };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { level: 'easy', puzzles: [], i: 0, score: 0, answered: false };
  var status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'pattern-completion', levels: [{ v: 'easy', label: 'Easy' }, { v: 'medium', label: 'Medium' }, { v: 'hard', label: 'Hard' }], newLabel: 'New set', onStart: begin, onRestart: function () { begin(controls.level()); } });
  var progress = el('div', { class: 'progress-line' });
  var seqEl = el('ol', { class: 'pattern-seq', 'aria-label': 'Pattern sequence' });
  var optsEl = el('div', { class: 'options', role: 'group', 'aria-label': 'Answer choices' });
  var explain = el('div', { class: 'explain', hidden: true });
  var nextBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Next puzzle', hidden: true });
  var play = el('div', { hidden: true }, [progress, el('p', { text: 'Which option fills the gap marked with a question mark?' }), seqEl, optsEl, explain, el('div', { class: 'btn-row', style: 'margin-top:1rem' }, [nextBtn])]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. You will solve ' + COUNT + ' pattern puzzles.' });
  [controls.el, intro, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function begin(level) {
    st.level = level; st.i = 0; st.score = 0; st.puzzles = [];
    for (var k = 0; k < COUNT; k++) st.puzzles.push(P.makePattern(Math.random, level));
    intro.hidden = true; play.hidden = false; BG.ui.clearResult(resultHost); show();
  }
  function show() {
    var p = st.puzzles[st.i]; st.answered = false;
    progress.innerHTML = ''; progress.appendChild(el('span', { text: 'Puzzle ' + (st.i + 1) + ' of ' + st.puzzles.length })); progress.appendChild(BG.ui.meter(st.i, st.puzzles.length));
    seqEl.innerHTML = '';
    p.seq.forEach(function (it, i) {
      if (i === p.hidden) seqEl.appendChild(el('li', { class: 'is-gap', 'aria-label': 'missing item', text: '?' }));
      else seqEl.appendChild(el('li', { 'aria-label': P.describeItem(it), html: P.itemSvg(it) }));
    });
    optsEl.innerHTML = '';
    p.options.forEach(function (it, idx) {
      var b = el('button', { type: 'button', class: 'option', html: P.itemSvg(it) + '<span>' + P.describeItem(it) + '</span>' });
      b.addEventListener('click', function () { answer(idx, b); });
      optsEl.appendChild(b);
    });
    explain.hidden = true; nextBtn.hidden = true; status.say('Look for what changes from one item to the next.', 'info');
  }
  function answer(idx, btn) {
    if (st.answered) return;
    var p = st.puzzles[st.i], right = idx === p.answerIndex;
    st.answered = true; if (right) st.score++;
    Array.prototype.forEach.call(optsEl.children, function (b, n) { b.disabled = true; if (n === p.answerIndex) b.classList.add('is-right'); else if (b === btn) b.classList.add('is-wrong'); });
    status.say(right ? 'That fits the pattern.' : 'The correct choice is the ' + P.describeItem(p.options[p.answerIndex]) + '.', right ? 'ok' : 'bad');
    explain.hidden = false; explain.textContent = ''; explain.appendChild(el('strong', { text: 'Why: ' })); explain.appendChild(document.createTextNode(p.why));
    nextBtn.hidden = false; nextBtn.textContent = st.i === st.puzzles.length - 1 ? 'See results' : 'Next puzzle'; nextBtn.focus();
  }
  nextBtn.addEventListener('click', function () {
    if (st.i < st.puzzles.length - 1) { st.i++; show(); return; }
    var best = BG.recordBest('pattern-completion:' + st.level, st.score, st.score + ' of ' + st.puzzles.length + ' correct', 'high');
    play.hidden = true; status.clear();
    BG.ui.result(resultHost, 'You solved ' + st.score + ' of ' + st.puzzles.length, [(best ? 'New personal best for ' + st.level + ' patterns. ' : '') + 'Patterns here are generated fresh each time.', 'Tip: check one feature at a time (shape, style, direction, count). Hard puzzles often run two rules at once.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'New set', onclick: function () { begin(controls.level()); } })]);
  });
  BG.games.patternCompletion.state = function () { return st; };
})();
