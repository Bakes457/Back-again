/* Logic Grid: deduce who owns, eats or plays what. Each puzzle stores its clues as test functions, so a brute-force
   check (BG.games.logicGrid.countSolutions) can prove every puzzle has exactly one solution.
   In a candidate answer "a", a[c][p] is the item (in category c) that belongs to person p. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  function owner(a, c, item) { return a[c].indexOf(item); }
  function same(a, c1, i1, c2, i2) { return owner(a, c1, i1) === owner(a, c2, i2); }

  var PUZZLES = {
    easy: {
      title: 'Pets and drinks', people: ['Ana', 'Ben', 'Cy'],
      scenario: 'Ana, Ben and Cy each own one pet and each drink one different drink.',
      cats: [{ name: 'Pet', items: ['Cat', 'Dog', 'Fish'] }, { name: 'Drink', items: ['Tea', 'Juice', 'Milk'] }],
      solution: [[1, 0, 2], [0, 2, 1]],
      clues: [
        { t: 'Cy owns neither the cat nor the dog.', f: function (a) { return a[0][2] !== 0 && a[0][2] !== 1; } },
        { t: 'Ben drinks neither tea nor juice.', f: function (a) { return a[1][1] !== 0 && a[1][1] !== 1; } },
        { t: 'The dog owner drinks tea.', f: function (a) { return same(a, 0, 1, 1, 0); } }
      ],
      steps: ['Clue 1 rules out the cat and the dog for Cy, so Cy owns the fish.', 'Clue 2 rules out tea and juice for Ben, so Ben drinks milk.', 'Clue 3 says the dog owner drinks tea. Ben drinks milk and Cy owns the fish, so the dog owner is Ana, who drinks tea.', 'That leaves the cat for Ben and juice for Cy.']
    },
    medium: {
      title: 'Hobbies and lunches', people: ['Dara', 'Eli', 'Faye', 'Gus'],
      scenario: 'Four friends each have a different hobby and each ate a different lunch.',
      cats: [{ name: 'Hobby', items: ['Chess', 'Painting', 'Running', 'Baking'] }, { name: 'Lunch', items: ['Soup', 'Salad', 'Pizza', 'Curry'] }],
      solution: [[1, 0, 3, 2], [0, 2, 3, 1]],
      clues: [
        { t: 'Eli neither runs nor bakes.', f: function (a) { return a[0][1] !== 2 && a[0][1] !== 3; } },
        { t: 'The painter ate the soup.', f: function (a) { return same(a, 0, 1, 1, 0); } },
        { t: 'Faye ate neither the salad nor the pizza.', f: function (a) { return a[1][2] !== 1 && a[1][2] !== 2; } },
        { t: 'Gus neither plays chess nor paints.', f: function (a) { return a[0][3] !== 0 && a[0][3] !== 1; } },
        { t: 'Dara does not run.', f: function (a) { return a[0][0] !== 2; } },
        { t: 'The runner ate the salad.', f: function (a) { return same(a, 0, 2, 1, 1); } },
        { t: 'Eli did not eat the soup.', f: function (a) { return a[1][1] !== 0; } },
        { t: 'Faye did not eat the soup.', f: function (a) { return a[1][2] !== 0; } }
      ],
      steps: ['Eli plays chess or paints (clue 1). The painter ate soup but Eli did not (clue 7), so Eli plays chess.', 'Gus runs or bakes (clue 4). Faye cannot be the runner, because the runner ate salad and Faye ate neither salad nor pizza (clues 6 and 3). Dara does not run (clue 5), so Gus is the runner and ate salad.', 'Faye ate neither soup, salad nor pizza (clues 8 and 3), so Faye ate curry. Faye cannot be the painter, who ate soup, so Faye bakes and Dara paints.', 'Dara the painter ate soup. The only lunch left for Eli is pizza.']
    },
    hard: {
      title: 'Lessons, days and snacks', people: ['Hana', 'Ivan', 'Jade', 'Kofi'],
      scenario: 'Four students each play a different instrument, have their lesson on a different weekday (Monday to Thursday) and bring a different snack.',
      cats: [{ name: 'Instrument', items: ['Piano', 'Violin', 'Drums', 'Flute'] }, { name: 'Day', items: ['Monday', 'Tuesday', 'Wednesday', 'Thursday'] }, { name: 'Snack', items: ['Apple', 'Nuts', 'Cheese', 'Grapes'] }],
      solution: [[1, 0, 2, 3], [1, 0, 3, 2], [1, 0, 3, 2]],
      clues: [
        { t: 'Kofi does not play the violin, the piano or the drums.', f: function (a) { return a[0][3] === 3; } },
        { t: 'The violinist has a lesson on Tuesday.', f: function (a) { return same(a, 0, 1, 1, 1); } },
        { t: 'The pianist has a lesson earlier in the week than the flautist.', f: function (a) { return a[1][owner(a, 0, 0)] < a[1][owner(a, 0, 3)]; } },
        { t: 'The drummer does not have a lesson on Monday.', f: function (a) { return a[1][owner(a, 0, 2)] !== 0; } },
        { t: 'The drummer has a lesson the day after the flautist.', f: function (a) { return a[1][owner(a, 0, 2)] === a[1][owner(a, 0, 3)] + 1; } },
        { t: 'Ivan has a lesson on neither Tuesday nor Thursday.', f: function (a) { return a[1][1] !== 1 && a[1][1] !== 3; } },
        { t: 'Jade does not play the violin.', f: function (a) { return a[0][2] !== 1; } },
        { t: 'The flautist brings cheese.', f: function (a) { return same(a, 0, 3, 2, 2); } },
        { t: 'The violinist brings neither apples nor grapes.', f: function (a) { var s = a[2][owner(a, 0, 1)]; return s !== 0 && s !== 3; } },
        { t: 'Jade does not bring apples.', f: function (a) { return a[2][2] !== 0; } }
      ],
      steps: ['Clue 1: Kofi plays the flute.', 'Clues 2 to 5: the violinist has Tuesday, so piano, flute and drums share Monday, Wednesday and Thursday. The pianist is earlier than the flautist, the drummer is not on Monday, and the drummer comes the day after the flautist. That forces piano on Monday, flute on Wednesday and drums on Thursday.', 'Clue 6: Ivan cannot have Tuesday or Thursday, and Wednesday is Kofi\'s, so Ivan has Monday and plays the piano.', 'Clue 7: Jade is not the violinist, so Jade plays the drums (Thursday) and Hana plays the violin (Tuesday).', 'Clue 8: Kofi brings cheese. Clue 9: Hana, the violinist, brings nuts. Clue 10: Jade does not bring apples, so Jade brings grapes and Ivan brings apples.']
    }
  };

  function permutations(n) {
    var out = [];
    (function rec(cur, rest) { if (!rest.length) { out.push(cur); return; } rest.forEach(function (x, i) { rec(cur.concat([x]), rest.slice(0, i).concat(rest.slice(i + 1))); }); })([], Array.apply(null, { length: n }).map(function (_, i) { return i; }));
    return out;
  }
  /* Brute force: how many complete assignments satisfy every clue? A valid puzzle returns exactly 1. */
  function countSolutions(p) {
    var n = p.people.length, perms = permutations(n), count = 0, hits = [];
    (function rec(c, cur) {
      if (c === p.cats.length) { if (p.clues.every(function (cl) { return cl.f(cur); })) { count++; hits.push(cur.map(function (x) { return x.slice(); })); } return; }
      perms.forEach(function (pm) { rec(c + 1, cur.concat([pm])); });
    })(0, []);
    return { count: count, solutions: hits };
  }
  BG.games.logicGrid = { PUZZLES: PUZZLES, countSolutions: countSolutions };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { level: 'easy', puz: null, manual: null, over: false, wrongCells: {} };
  var status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'logic-grid', levels: [{ v: 'easy', label: 'Easy (3 people)' }, { v: 'medium', label: 'Medium (4 people)' }, { v: 'hard', label: 'Hard (4 people, 3 categories)' }], startLabel: 'Start', newLabel: 'Load puzzle', restartLabel: 'Clear grid', onStart: load, onRestart: function () { if (st.puz) load(st.level); } });
  var autoBox = el('input', { type: 'checkbox', id: 'auto-elim' }); autoBox.checked = BG.getPref('logic-grid', 'auto') !== false;
  var scenarioEl = el('p'), cluesEl = el('ol', { class: 'lg-clues' }), gridsEl = el('div', { class: 'lg-grids' });
  var checkBtn = el('button', { type: 'button', class: 'btn', text: 'Check my answer' });
  var solveBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Show solution and explanation' });
  var play = el('div', { hidden: true }, [scenarioEl, el('h2', { text: 'Clues' }), cluesEl,
    el('p', { class: 'lg-key' }, ['Select a square to cycle it: first \u2715 (ruled out), then \u2713 (this is the match), then blank. ']),
    el('p', {}, [autoBox, ' ', el('label', { for: 'auto-elim', text: 'When I place a \u2713, rule out the rest of that row and column automatically' })]),
    gridsEl, el('div', { class: 'btn-row', style: 'margin-top:1rem' }, [checkBtn, solveBtn])]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. Three hand-made puzzles are included, one per difficulty.' });
  [controls.el, intro, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function load(level) {
    st.level = level; st.puz = PUZZLES[level]; st.over = false; st.wrongCells = {};
    st.manual = st.puz.cats.map(function () { return st.puz.people.map(function () { return st.puz.people.map(function () { return 0; }); }); });
    intro.hidden = true; play.hidden = false; BG.ui.clearResult(resultHost);
    scenarioEl.textContent = st.puz.scenario;
    cluesEl.innerHTML = ''; st.puz.clues.forEach(function (c) { cluesEl.appendChild(el('li', { text: c.t })); });
    buildGrids(); checkBtn.disabled = false; solveBtn.disabled = false;
    status.say('Puzzle loaded. Use the clues to work out every match.', 'info');
  }
  function display(c, p, i) {
    var m = st.manual[c][p][i]; if (m) return m;
    if (!autoBox.checked) return 0;
    var n = st.puz.people.length;
    for (var k = 0; k < n; k++) { if ((k !== i && st.manual[c][p][k] === 2) || (k !== p && st.manual[c][k][i] === 2)) return 1; }
    return 0;
  }
  function stateWord(s) { return s === 2 ? 'match' : s === 1 ? 'ruled out' : 'blank'; }
  function buildGrids() {
    gridsEl.innerHTML = '';
    st.puz.cats.forEach(function (cat, c) {
      var head = el('tr', {}, [el('td', { 'aria-hidden': 'true' })].concat(cat.items.map(function (it) { return el('th', { scope: 'col', text: it }); })));
      var table = el('table', { class: 'lg-table' }, [el('caption', { text: 'Who has which ' + cat.name.toLowerCase() + '?' }), el('thead', {}, [head])]);
      var tb = el('tbody');
      st.puz.people.forEach(function (name, p) {
        var tr = el('tr', {}, [el('th', { scope: 'row', text: name })]);
        cat.items.forEach(function (it, i) {
          var b = el('button', { type: 'button', class: 'lg-cell', 'data-c': c, 'data-p': p, 'data-i': i });
          tr.appendChild(el('td', {}, [b]));
        });
        tb.appendChild(tr);
      });
      table.appendChild(tb); gridsEl.appendChild(table);
    });
    paint();
  }
  function paint() {
    Array.prototype.forEach.call(gridsEl.querySelectorAll('.lg-cell'), function (b) {
      var c = +b.getAttribute('data-c'), p = +b.getAttribute('data-p'), i = +b.getAttribute('data-i'), s = display(c, p, i);
      b.setAttribute('data-s', s); b.textContent = s === 2 ? '\u2713' : s === 1 ? '\u2715' : '';
      b.setAttribute('aria-label', st.puz.people[p] + ', ' + st.puz.cats[c].items[i] + ': ' + stateWord(s));
      b.classList.toggle('is-wrong', !!st.wrongCells[c + '-' + p + '-' + i]);
    });
  }
  gridsEl.addEventListener('click', function (e) {
    var b = e.target.closest('.lg-cell'); if (!b || st.over) return;
    var c = +b.getAttribute('data-c'), p = +b.getAttribute('data-p'), i = +b.getAttribute('data-i');
    st.manual[c][p][i] = (display(c, p, i) + 1) % 3; st.wrongCells = {};
    paint();
  });
  autoBox.addEventListener('change', function () { BG.setPref('logic-grid', 'auto', autoBox.checked); if (st.puz) paint(); });
  function placed() { /* returns {complete, wrong[]} comparing placed checkmarks to the solution */
    var wrong = [], complete = true;
    st.puz.cats.forEach(function (cat, c) {
      st.puz.people.forEach(function (_, p) {
        var ticks = [];
        cat.items.forEach(function (__, i) { if (st.manual[c][p][i] === 2) ticks.push(i); });
        if (ticks.length !== 1) complete = false;
        ticks.forEach(function (i) { if (st.puz.solution[c][p] !== i) wrong.push(c + '-' + p + '-' + i); });
      });
    });
    return { complete: complete, wrong: wrong };
  }
  checkBtn.addEventListener('click', function () {
    if (!st.puz || st.over) return;
    var r = placed(); st.wrongCells = {}; r.wrong.forEach(function (k) { st.wrongCells[k] = true; }); paint();
    if (r.wrong.length) { status.say(r.wrong.length + (r.wrong.length === 1 ? ' match is' : ' matches are') + ' wrong. They are outlined and need to change.', 'bad'); return; }
    if (!r.complete) { status.say('Nothing wrong so far, but every person still needs one \u2713 in each grid.', 'info'); return; }
    st.over = true;
    var best = BG.recordBest('logic-grid:' + st.level, 1, 'Solved', 'high');
    status.say('Every match is right.', 'ok');
    BG.ui.result(resultHost, 'Puzzle solved', [(best ? 'First solve recorded for ' + st.level + '. ' : '') + 'Here is one way to reach the answer:'].concat(st.puz.steps.map(function (s, k) { return (k + 1) + '. ' + s; })), [el('button', { type: 'button', class: 'btn btn-primary', text: 'Try another difficulty', onclick: function () { controls.select.focus(); } })]);
  });
  solveBtn.addEventListener('click', function () {
    if (!st.puz) return;
    st.puz.cats.forEach(function (cat, c) { st.puz.people.forEach(function (_, p) { cat.items.forEach(function (__, i) { st.manual[c][p][i] = st.puz.solution[c][p] === i ? 2 : 1; }); }); });
    st.over = true; st.wrongCells = {}; paint(); checkBtn.disabled = true; solveBtn.disabled = true;
    status.say('Solution shown. This attempt is not recorded.', 'info');
    BG.ui.result(resultHost, 'How to solve it', st.puz.steps.map(function (s, k) { return (k + 1) + '. ' + s; }), []);
  });
  BG.games.logicGrid.state = function () { return st; };
})();
