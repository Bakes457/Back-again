/* Cipher Quest: every letter of an original sentence has been swapped for a different letter. Work out the swaps to read it.
   Typing a guess under one letter fills in every copy of that cipher letter. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var SENTENCES = {
    easy: ['Small steps still cross rivers.', 'Curiosity opens every door.', 'Good puzzles reward patience.', 'Quiet minds find clear answers.', 'Every grid hides a pattern.'],
    medium: ['A tangled knot is just a loop waiting for patience.', 'Clues are only questions dressed as hints.', 'Each wrong guess narrows the road to the right one.', 'Hard puzzles feel impossible right until they feel obvious.'],
    hard: ['The best moment in any puzzle is the quiet second before everything clicks into place.', 'A careful reader notices what the hurried reader walks straight past.', 'Solve one small square at a time and the whole grid will eventually give way.']
  };
  var ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  /* Returns { plain, cipher, key } where key maps plain letter -> cipher letter and no letter maps to itself. */
  function makeCipher(sentence, rnd) {
    rnd = rnd || Math.random;
    var plain = sentence.toUpperCase(), used = {};
    plain.split('').forEach(function (ch) { if (ALPHA.indexOf(ch) > -1) used[ch] = true; });
    var key, ok;
    do {
      var perm = U.shuffle(ALPHA.split(''), rnd); key = {}; ALPHA.split('').forEach(function (ch, i) { key[ch] = perm[i]; });
      ok = Object.keys(used).every(function (ch) { return key[ch] !== ch; });
    } while (!ok);
    return { plain: plain, cipher: plain.split('').map(function (ch) { return key[ch] || ch; }).join(''), key: key };
  }
  BG.games.cipher = { makeCipher: makeCipher, SENTENCES: SENTENCES };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { level: 'easy', c: null, guess: {}, hinted: {}, over: true, hints: 0, t0: 0 };
  var status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'cipher-quest', levels: [{ v: 'easy', label: 'Easy (short)' }, { v: 'medium', label: 'Medium' }, { v: 'hard', label: 'Hard (long)' }], newLabel: 'New cipher', onStart: start, onRestart: function () { if (st.c) begin(st.c); } });
  var board = el('div', { class: 'cq-board', role: 'group', 'aria-label': 'Cipher text with guess boxes' });
  var freq = el('p', { class: 'small muted' });
  var hintBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Hint (reveal one letter)' }), checkBtn = el('button', { type: 'button', class: 'btn', text: 'Check my guesses' }), solveBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Show solution' });
  var play = el('div', { hidden: true }, [board, freq, el('div', { class: 'btn-row', style: 'margin-top:1rem' }, [checkBtn, hintBtn, solveBtn])]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. Each letter has been swapped for another. Decode the sentence.' });
  [controls.el, intro, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });
  var inputs = [];

  function start(level) { st.level = level; begin(makeCipher(U.pick(SENTENCES[level]))); }
  function begin(c) {
    st.c = c; st.guess = {}; st.hinted = {}; st.over = false; st.hints = 0; st.t0 = Date.now();
    intro.hidden = true; play.hidden = false; BG.ui.clearResult(resultHost); build();
    status.say('Type a guess under any letter. Common short words like THE, A and IS are good places to start.', 'info');
  }
  function build() {
    board.innerHTML = ''; inputs = [];
    var counts = {};
    st.c.cipher.split(' ').forEach(function (word) {
      var w = el('span', { class: 'cq-word' });
      word.split('').forEach(function (ch) {
        if (ALPHA.indexOf(ch) < 0) { w.appendChild(el('span', { class: 'cq-col cq-punc' }, [el('span', { class: 'cq-c', text: ch })])); return; }
        counts[ch] = (counts[ch] || 0) + 1;
        var inp = el('input', { type: 'text', class: 'cq-in', maxlength: '2', autocomplete: 'off', autocapitalize: 'characters', spellcheck: 'false', 'data-c': ch, 'aria-label': 'Cipher letter ' + ch + ', your guess' });
        inp.addEventListener('input', function () { setGuess(ch, inp.value); });
        inp.addEventListener('keydown', function (e) {
          var i = inputs.indexOf(inp);
          if (e.key === 'ArrowRight' && inputs[i + 1]) { e.preventDefault(); inputs[i + 1].focus(); }
          else if (e.key === 'ArrowLeft' && inputs[i - 1]) { e.preventDefault(); inputs[i - 1].focus(); }
          else if (e.key === 'Backspace' && !inp.value && inputs[i - 1]) { inputs[i - 1].focus(); }
        });
        inputs.push(inp);
        w.appendChild(el('span', { class: 'cq-col' }, [el('span', { class: 'cq-c', 'aria-hidden': 'true', text: ch }), inp]));
      });
      board.appendChild(w);
    });
    var order = Object.keys(counts).sort(function (a, b) { return counts[b] - counts[a] || (a < b ? -1 : 1); });
    freq.textContent = 'Most common cipher letters: ' + order.slice(0, 6).map(function (k) { return k + ' (' + counts[k] + ')'; }).join(', ') + '. In English, E, T and A are usually the most common.';
  }
  function setGuess(ch, raw) {
    if (st.over) return;
    if (st.hinted[ch]) { refresh(); return; }
    var v = String(raw).toUpperCase().replace(/[^A-Z]/g, '').slice(-1);
    if (v) st.guess[ch] = v; else delete st.guess[ch];
    refresh(); checkDone();
  }
  function refresh() {
    var seen = {}; Object.keys(st.guess).forEach(function (k) { seen[st.guess[k]] = (seen[st.guess[k]] || 0) + 1; });
    inputs.forEach(function (inp) {
      var ch = inp.getAttribute('data-c'), g = st.guess[ch] || '';
      if (inp.value !== g) inp.value = g;
      var dup = g && seen[g] > 1;
      inp.className = 'cq-in' + (dup ? ' is-dup' : '') + (st.hinted[ch] ? ' is-hint' : '');
      inp.readOnly = !!st.hinted[ch];
      inp.setAttribute('aria-label', 'Cipher letter ' + ch + ', your guess ' + (g || 'empty') + (dup ? ', conflict: used twice' : '') + (st.hinted[ch] ? ', revealed by hint' : ''));
    });
  }
  function plainFor(ch) { var k = st.c.key; return Object.keys(k).filter(function (p) { return k[p] === ch; })[0]; }
  function checkDone() {
    var letters = {}; st.c.cipher.split('').forEach(function (ch) { if (ALPHA.indexOf(ch) > -1) letters[ch] = true; });
    if (Object.keys(letters).every(function (ch) { return st.guess[ch] === plainFor(ch); })) finish(true);
  }
  checkBtn.addEventListener('click', function () {
    if (st.over) return;
    var wrong = 0, empty = 0; inputs.forEach(function (inp) { var ch = inp.getAttribute('data-c'); if (!st.guess[ch]) empty++; else if (st.guess[ch] !== plainFor(ch) && !inp.classList.contains('is-dup')) wrong++; });
    var bad = {}; Object.keys(st.guess).forEach(function (ch) { if (st.guess[ch] !== plainFor(ch)) bad[ch] = true; });
    inputs.forEach(function (inp) { inp.classList.toggle('is-wrong', !!bad[inp.getAttribute('data-c')]); });
    var n = Object.keys(bad).length;
    status.say(n ? n + (n === 1 ? ' letter is wrong' : ' letters are wrong') + ' (marked with a cross).' : (empty ? 'Everything so far is right. Keep going.' : 'All correct.'), n ? 'bad' : 'ok');
  });
  hintBtn.addEventListener('click', function () {
    if (st.over) return;
    var open = []; inputs.forEach(function (inp) { var ch = inp.getAttribute('data-c'); if (st.guess[ch] !== plainFor(ch) && open.indexOf(ch) < 0) open.push(ch); });
    if (!open.length) return;
    var ch = U.pick(open); st.guess[ch] = plainFor(ch); st.hinted[ch] = true; st.hints++; refresh();
    status.say('Hint: cipher letter ' + ch + ' stands for ' + plainFor(ch) + '.', 'info'); checkDone();
  });
  solveBtn.addEventListener('click', function () {
    if (st.over) return; st.over = true;
    inputs.forEach(function (inp) { var ch = inp.getAttribute('data-c'); st.guess[ch] = plainFor(ch); st.hinted[ch] = true; }); refresh();
    status.say('Solution shown: ' + st.c.plain + ' This attempt is not recorded.', 'info');
  });
  function finish() {
    st.over = true; var secs = Math.round((Date.now() - st.t0) / 1000);
    var best = st.hints === 0 ? BG.recordBest('cipher-quest:' + st.level, secs, U.fmtTime(secs) + ', no hints', 'low') : false;
    inputs.forEach(function (i) { i.readOnly = true; }); status.say('Decoded.', 'ok');
    BG.ui.result(resultHost, 'Decoded in ' + U.fmtTime(secs), [(best ? 'New personal best (no hints) for ' + st.level + '. ' : '') + 'The sentence: ' + st.c.plain, 'Hints used: ' + st.hints + '. Times are only saved as a best when you use no hints.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'New cipher', onclick: function () { start(controls.level()); } })]);
  }
  BG.games.cipher.state = function () { return st; };
  BG.games.cipher.setGuess = setGuess;
})();
