/* Riddle Challenge: original riddles with typed answers, hints, reveal and an explanation. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el, P = BG.pools;
  var COUNT = 5;
  function clean(s) { return String(s).toLowerCase().replace(/[^a-z ]/g, '').replace(/\s+/g, ' ').trim(); }
  function isCorrect(riddle, input) {
    var x = clean(input); if (!x) return false;
    return riddle.a.some(function (a) { return clean(a) === x; }) || riddle.a.some(function (a) { return clean(a).replace(/^(a|an|the|your|my) /, '') === x.replace(/^(a|an|the|your|my) /, ''); });
  }
  BG.games.riddles = { isCorrect: isCorrect, COUNT: COUNT };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { list: [], i: 0, solved: 0, revealed: 0, hints: 0, locked: false };
  var status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'riddles', levels: [{ v: 'easy', label: 'Easy' }, { v: 'medium', label: 'Medium' }, { v: 'hard', label: 'Hard' }, { v: 'mixed', label: 'Mixed' }], newLabel: 'New set', onStart: function (l) { begin(pick(l)); }, onRestart: function () { if (st.list.length) begin(st.list); } });
  var progress = el('div', { class: 'progress-line' });
  var text = el('p', { class: 'big-prompt' });
  var input = el('input', { type: 'text', id: 'riddle-input', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
  var checkBtn = el('button', { type: 'submit', class: 'btn btn-primary', text: 'Check answer' });
  var hintBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Hint' });
  var revealBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Reveal answer' });
  var nextBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Next riddle', hidden: true });
  var explain = el('div', { class: 'explain', hidden: true });
  var form = el('form', { class: 'answer-row', novalidate: 'novalidate' }, [el('div', { class: 'field' }, [el('label', { for: 'riddle-input', text: 'Your answer' }), input]), checkBtn]);
  var play = el('div', { hidden: true }, [progress, text, form, el('div', { class: 'btn-row' }, [hintBtn, revealBtn, nextBtn]), explain]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. You will get ' + COUNT + ' riddles.' });
  [controls.el, intro, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function pick(level) {
    var pool = level === 'mixed' ? P.riddles : P.riddles.filter(function (r) { return r.level === level; });
    return U.shuffle(pool).slice(0, COUNT);
  }
  function begin(list) { st.list = list; st.i = 0; st.solved = 0; st.revealed = 0; st.hints = 0; intro.hidden = true; play.hidden = false; BG.ui.clearResult(resultHost); show(); }
  function show() {
    var r = st.list[st.i]; st.locked = false;
    progress.innerHTML = ''; progress.appendChild(el('span', { text: 'Riddle ' + (st.i + 1) + ' of ' + st.list.length })); progress.appendChild(BG.ui.meter(st.i, st.list.length));
    text.textContent = r.q; input.value = ''; input.disabled = false; checkBtn.disabled = false; hintBtn.disabled = false; revealBtn.disabled = false; nextBtn.hidden = true; explain.hidden = true; status.clear(); input.focus();
  }
  function lock() { st.locked = true; input.disabled = true; checkBtn.disabled = true; hintBtn.disabled = true; revealBtn.disabled = true; nextBtn.hidden = false; nextBtn.textContent = st.i === st.list.length - 1 ? 'See results' : 'Next riddle'; nextBtn.focus(); }
  function explainNow(r) { explain.hidden = false; explain.textContent = ''; explain.appendChild(el('strong', { text: 'Answer: ' + r.a[0] + '. ' })); explain.appendChild(document.createTextNode(r.why)); }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (st.locked) return;
    var r = st.list[st.i];
    if (!clean(input.value)) { status.say('Type your answer first.', 'bad'); return; }
    if (isCorrect(r, input.value)) { st.solved++; lock(); status.say('Well done.', 'ok'); explainNow(r); }
    else { status.say('That is not the answer. Try again, ask for a hint, or reveal the answer.', 'bad'); input.select(); }
  });
  hintBtn.addEventListener('click', function () { if (st.locked) return; st.hints++; status.say('Hint: ' + st.list[st.i].hint, 'info'); });
  revealBtn.addEventListener('click', function () { if (st.locked) return; st.revealed++; lock(); status.say('Answer revealed.', 'info'); explainNow(st.list[st.i]); });
  nextBtn.addEventListener('click', function () {
    if (st.i < st.list.length - 1) { st.i++; show(); return; }
    var best = BG.recordBest('riddles:' + controls.level(), st.solved, st.solved + ' of ' + st.list.length + ' solved', 'high');
    play.hidden = true; status.clear();
    BG.ui.result(resultHost, 'You solved ' + st.solved + ' of ' + st.list.length, [(best ? 'New personal best for this set. ' : '') + 'Hints used: ' + st.hints + '. Answers revealed: ' + st.revealed + '.', 'Tip: riddles often use words with two meanings. Ask what else the key words could describe.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'New set', onclick: function () { begin(pick(controls.level())); } })]);
  });
  BG.games.riddles.state = function () { return st; };
})();
