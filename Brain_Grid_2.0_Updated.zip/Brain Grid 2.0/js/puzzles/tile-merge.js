/* Tile Merge: slide every tile in one direction; equal tiles that collide merge into one with double the value.
   Controls: arrow keys, WASD, swipe on the board, or the on-screen arrow buttons. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var SIZES = { easy: 5, medium: 4, hard: 3 };

  /* Slide one line toward index 0. Returns { line, gained, moved }. */
  function slideLine(line) {
    var vals = line.filter(Boolean), out = [], gained = 0, i = 0;
    while (i < vals.length) {
      if (i + 1 < vals.length && vals[i] === vals[i + 1]) { out.push(vals[i] * 2); gained += vals[i] * 2; i += 2; }
      else { out.push(vals[i]); i++; }
    }
    while (out.length < line.length) out.push(0);
    return { line: out, gained: gained, moved: out.some(function (v, k) { return v !== line[k]; }) };
  }
  /* dir: 'left' | 'right' | 'up' | 'down' on an n x n grid stored as a flat array. */
  function move(grid, n, dir) {
    var next = grid.slice(), gained = 0, moved = false;
    for (var a = 0; a < n; a++) {
      var idx = [];
      for (var b = 0; b < n; b++) idx.push(dir === 'left' ? a * n + b : dir === 'right' ? a * n + (n - 1 - b) : dir === 'up' ? b * n + a : (n - 1 - b) * n + a);
      var r = slideLine(idx.map(function (i) { return grid[i]; }));
      idx.forEach(function (i, k) { next[i] = r.line[k]; });
      gained += r.gained; moved = moved || r.moved;
    }
    return { grid: next, gained: gained, moved: moved };
  }
  function canMove(grid, n) { return ['left', 'right', 'up', 'down'].some(function (d) { return move(grid, n, d).moved; }); }
  BG.games.tileMerge = { slideLine: slideLine, move: move, canMove: canMove, SIZES: SIZES };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { n: 4, grid: [], score: 0, over: true, won: false, level: 'medium' };
  var status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'tile-merge', levels: [{ v: 'easy', label: 'Easy (5x5 board)' }, { v: 'medium', label: 'Medium (4x4 board)' }, { v: 'hard', label: 'Hard (3x3 board)' }], newLabel: 'New game', onStart: start, onRestart: function () { start(st.level); } });
  var scoreEl = el('span', { text: 'Score 0' }), bestEl = el('span', { text: '' }), topEl = el('span', { text: '' });
  var meta = el('div', { class: 'game-meta', hidden: true }, [scoreEl, topEl, bestEl]);
  var board = el('div', { class: 'tm-board', role: 'grid', 'aria-label': 'Tile board', tabindex: '0' });
  var pad = el('div', { class: 'tm-pad', role: 'group', 'aria-label': 'Move buttons' }, [['up', 'Up'], ['left', 'Left'], ['down', 'Down'], ['right', 'Right']].map(function (d) { return el('button', { type: 'button', class: 'btn', 'data-d': d[0], text: d[1], 'aria-label': 'Slide ' + d[1].toLowerCase() }); }));
  var play = el('div', { hidden: true }, [board, pad, el('p', { class: 'small muted', text: 'Arrow keys or WASD, swipe the board, or use the buttons. Tiles of the same number merge.' })]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a board size and press Start. Merge tiles to build the biggest number you can.' });
  [controls.el, intro, meta, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function spawn() {
    var empty = []; st.grid.forEach(function (v, i) { if (!v) empty.push(i); });
    if (!empty.length) return;
    st.grid[U.pick(empty)] = Math.random() < 0.9 ? 2 : 4;
  }
  function start(level) {
    st.level = level; st.n = SIZES[level]; st.grid = []; for (var i = 0; i < st.n * st.n; i++) st.grid.push(0);
    st.score = 0; st.over = false; st.won = false; spawn(); spawn();
    intro.hidden = true; play.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost);
    board.style.gridTemplateColumns = 'repeat(' + st.n + ', minmax(0, 1fr))'; board.setAttribute('data-n', st.n);
    paint(); status.say('Slide the tiles. Merge equal numbers.', 'info'); board.focus();
  }
  function paint() {
    board.innerHTML = '';
    st.grid.forEach(function (v, i) {
      board.appendChild(el('div', { class: 'tm-cell' + (v ? ' tm-v' + Math.min(v, 4096) : ''), role: 'gridcell', 'aria-label': 'Row ' + ((i / st.n | 0) + 1) + ', column ' + (i % st.n + 1) + ', ' + (v ? v : 'empty'), text: v ? String(v) : '' }));
    });
    var top = Math.max.apply(null, st.grid);
    scoreEl.textContent = 'Score ' + st.score; topEl.textContent = 'Biggest tile ' + top;
    var b = BG.getBest()['tile-merge:' + st.level]; bestEl.textContent = b ? 'Best ' + b.score : '';
  }
  function act(dir) {
    if (st.over) return;
    var r = move(st.grid, st.n, dir);
    if (!r.moved) { status.say('Nothing moves that way. Try another direction.', 'info'); return; }
    st.grid = r.grid; st.score += r.gained; spawn(); paint();
    var top = Math.max.apply(null, st.grid);
    if (!st.won && top >= 2048) { st.won = true; status.say('You made 2048. You can keep playing for a higher score.', 'ok'); }
    else if (r.gained) status.say('Merged. Score ' + st.score + '.', 'info');
    if (!canMove(st.grid, st.n)) end();
  }
  function end() {
    st.over = true;
    var best = BG.recordBest('tile-merge:' + st.level, st.score, st.score + ' points, biggest tile ' + Math.max.apply(null, st.grid), 'high');
    paint(); status.say('No moves left.', 'info');
    BG.ui.result(resultHost, 'No moves left: ' + st.score + ' points', [(best ? 'New personal best for this board size. ' : '') + 'Biggest tile: ' + Math.max.apply(null, st.grid) + '.', 'Tip: keep your biggest tile in a corner and build a descending chain next to it.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { start(controls.level()); } })]);
  }
  var KEY = { ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'up', ArrowDown: 'down', a: 'left', d: 'right', w: 'up', s: 'down' };
  document.addEventListener('keydown', function (e) {
    if (st.over || play.hidden || e.ctrlKey || e.metaKey || e.altKey) return;
    var tag = e.target && e.target.tagName; if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
    var d = KEY[e.key]; if (d) { e.preventDefault(); act(d); }
  });
  pad.addEventListener('click', function (e) { var b = e.target.closest('[data-d]'); if (b) act(b.getAttribute('data-d')); });
  var sx = 0, sy = 0, swiping = false;
  board.addEventListener('pointerdown', function (e) { swiping = true; sx = e.clientX; sy = e.clientY; });
  board.addEventListener('pointerup', function (e) {
    if (!swiping) return; swiping = false;
    var dx = e.clientX - sx, dy = e.clientY - sy;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 24) return;
    act(Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up'));
  });
  board.addEventListener('pointercancel', function () { swiping = false; });
  BG.games.tileMerge.state = function () { return st; };
  BG.games.tileMerge.act = act;
})();
