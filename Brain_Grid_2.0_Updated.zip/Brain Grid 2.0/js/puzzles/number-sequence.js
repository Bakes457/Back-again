/* Number Sequence: find the next number. Terms and answers come from rules in pools.js, so they always agree. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el, P = BG.pools;
  var COUNT = 6;
  function pickQuestions(mode) {
    var by = function (l) { return U.shuffle(P.sequences.filter(function (s) { return s.level === l; })); };
    var picked = mode === 'mixed' ? by(1).slice(0, 2).concat(by(2).slice(0, 2), by(3).slice(0, 2)) : by(parseInt(mode, 10)).slice(0, COUNT);
    return picked.map(function (s) { var t = s.build(); return { shown: t.slice(0, -1), answer: t[t.length - 1], kind: s.kind, why: s.why, level: s.level }; });
  }
  BG.games.numberSequence = { pickQuestions: pickQuestions, COUNT: COUNT };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { qs: [], i: 0, score: 0, answered: false, mode: 'mixed' };
  var status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'number-sequence', levelLabel: 'Difficulty', levels: [{ v: 'mixed', label: 'Rising (easy to hard)' }, { v: '1', label: 'Easy' }, { v: '2', label: 'Medium' }, { v: '3', label: 'Hard' }], newLabel: 'New game', onStart: function (m) { st.mode = m; begin(pickQuestions(m)); }, onRestart: function () { if (st.qs.length) begin(st.qs); } });
  var progress = el('div', { class: 'progress-line' });
  var prompt = el('p', { class: 'big-prompt', 'aria-live': 'off' });
  var kind = el('p', { class: 'muted small' });
  var input = el('input', { type: 'text', id: 'seq-input', inputmode: 'numeric', autocomplete: 'off' });
  var checkBtn = el('button', { type: 'submit', class: 'btn btn-primary', text: 'Check answer' });
  var nextBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Next question', hidden: true });
  var explain = el('div', { class: 'explain', hidden: true });
  var form = el('form', { class: 'answer-row', novalidate: 'novalidate' }, [el('div', { class: 'field' }, [el('label', { for: 'seq-input', text: 'The next number is' }), input]), checkBtn]);
  var play = el('div', { hidden: true }, [progress, el('p', { text: 'What number comes next in the sequence?' }), prompt, kind, form, explain, el('div', { class: 'btn-row', style: 'margin-top:1rem' }, [nextBtn])]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. You will answer ' + COUNT + ' questions.' });
  [controls.el, intro, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function begin(qs) { st.qs = qs; st.i = 0; st.score = 0; intro.hidden = true; play.hidden = false; BG.ui.clearResult(resultHost); show(); }
  function show() {
    var q = st.qs[st.i]; st.answered = false;
    progress.innerHTML = ''; progress.appendChild(el('span', { text: 'Question ' + (st.i + 1) + ' of ' + st.qs.length })); progress.appendChild(BG.ui.meter(st.i, st.qs.length));
    prompt.textContent = q.shown.join(',  ') + ',  ?';
    kind.textContent = 'Difficulty: ' + (q.level === 1 ? 'Easy' : q.level === 2 ? 'Medium' : 'Hard');
    input.value = ''; input.disabled = false; checkBtn.disabled = false; nextBtn.hidden = true; explain.hidden = true; status.clear(); input.focus();
  }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (st.answered) return;
    var raw = input.value.replace(/\s/g, '').replace(/\u2212/g, '-'), q = st.qs[st.i];
    if (!/^-?\d+$/.test(raw)) { status.say('Enter a whole number, for example 12 or -5.', 'bad'); input.focus(); return; }
    st.answered = true; input.disabled = true; checkBtn.disabled = true;
    var right = parseInt(raw, 10) === q.answer;
    if (right) st.score++;
    status.say(right ? 'The next number is ' + q.answer + '.' : 'The correct number was ' + q.answer + ', not ' + parseInt(raw, 10) + '.', right ? 'ok' : 'bad');
    explain.hidden = false; explain.textContent = '';
    explain.appendChild(el('strong', { text: 'Pattern: ' + q.kind + '. ' })); explain.appendChild(document.createTextNode(q.why));
    nextBtn.hidden = false; nextBtn.textContent = st.i === st.qs.length - 1 ? 'See results' : 'Next question'; nextBtn.focus();
  });
  nextBtn.addEventListener('click', function () {
    if (st.i < st.qs.length - 1) { st.i++; show(); return; }
    var best = BG.recordBest('number-sequence:' + st.mode, st.score, st.score + ' of ' + st.qs.length + ' correct', 'high');
    play.hidden = true; status.clear();
    BG.ui.result(resultHost, 'You answered ' + st.score + ' of ' + st.qs.length + ' correctly', [(best ? 'New personal best for this difficulty. ' : '') + 'This is a practice game, not a test of intelligence.', 'Tip: write the gaps between neighbouring numbers. If the gaps are not constant, look at the gaps between the gaps, or try multiplying.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { begin(pickQuestions(controls.level())); st.mode = controls.level(); } })]);
  });
  BG.games.numberSequence.state = function () { return st; };
})();
