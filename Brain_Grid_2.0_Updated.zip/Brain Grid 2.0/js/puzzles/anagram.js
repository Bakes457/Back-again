/* Anagram Challenge: five rounds of scrambled words. Answers ignore capitalisation and spaces. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el, P = BG.pools;
  var ROUNDS = 5;
  BG.games.anagram = { ROUNDS: ROUNDS };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { words: [], i: 0, correct: 0, hints: 0, hintStep: 0, locked: false, level: 'easy', skipped: 0 };
  var status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'anagram', levels: [{ v: 'easy', label: 'Easy (6 letters)' }, { v: 'medium', label: 'Medium (7 letters)' }, { v: 'hard', label: 'Hard (8 to 9 letters)' }], startLabel: 'Start', newLabel: 'New game', restartLabel: 'Restart round set', onStart: newGame, onRestart: function () { if (st.words.length) begin(st.words); } });
  var progress = el('div', { class: 'progress-line' });
  var tiles = el('div', { class: 'tiles' });
  var input = el('input', { type: 'text', id: 'anagram-input', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
  var checkBtn = el('button', { type: 'submit', class: 'btn btn-primary', text: 'Check' });
  var hintBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Hint' });
  var giveUpBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Give up on this word' });
  var nextBtn = el('button', { type: 'button', class: 'btn btn-primary', text: 'Next word', hidden: true });
  var form = el('form', { class: 'answer-row', novalidate: 'novalidate' }, [el('div', { class: 'field' }, [el('label', { for: 'anagram-input', text: 'Your answer' }), input]), checkBtn]);
  var play = el('div', { hidden: true }, [progress, el('p', { text: 'Rearrange the letters to spell a real word.' }), tiles, form, el('div', { class: 'btn-row' }, [hintBtn, giveUpBtn, nextBtn])]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. You will unscramble ' + ROUNDS + ' words.' });
  [controls.el, intro, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function newGame(level) {
    st.level = level;
    var bank = U.shuffle(P.anagrams[level]).slice(0, ROUNDS).map(function (w) { return { w: w.w, hint: w.hint, s: P.scramble(w.w) }; });
    begin(bank);
  }
  function begin(words) {
    st.words = words; st.i = 0; st.correct = 0; st.hints = 0; st.skipped = 0;
    intro.hidden = true; play.hidden = false; BG.ui.clearResult(resultHost);
    showRound();
  }
  function showRound() {
    var w = st.words[st.i];
    st.locked = false; st.hintStep = 0;
    tiles.innerHTML = '';
    tiles.setAttribute('role', 'img'); tiles.setAttribute('aria-label', 'Scrambled letters: ' + w.s.toUpperCase().split('').join(' '));
    w.s.toUpperCase().split('').forEach(function (ch) { tiles.appendChild(el('span', { class: 'tile', 'aria-hidden': 'true', text: ch })); });
    progress.innerHTML = '';
    progress.appendChild(el('span', { text: 'Word ' + (st.i + 1) + ' of ' + st.words.length }));
    progress.appendChild(BG.ui.meter(st.i, st.words.length));
    input.value = ''; input.disabled = false; checkBtn.disabled = false; hintBtn.disabled = false; giveUpBtn.disabled = false; nextBtn.hidden = true;
    status.clear(); input.focus();
  }
  function lock() { st.locked = true; input.disabled = true; checkBtn.disabled = true; hintBtn.disabled = true; giveUpBtn.disabled = true; nextBtn.hidden = false; nextBtn.textContent = st.i === st.words.length - 1 ? 'See results' : 'Next word'; nextBtn.focus(); }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (st.locked) return;
    var answer = BG.ui.normalise(input.value), w = st.words[st.i];
    if (!answer) { status.say('Type a word first.', 'bad'); return; }
    if (answer === w.w) { st.correct++; lock(); status.say('The word is ' + w.w.toUpperCase() + '. Its letters were rearranged from ' + w.s.toUpperCase() + '.', 'ok'); }
    else { status.say('"' + input.value.trim() + '" is not the word. ' + (answer.length !== w.w.length ? 'The answer has ' + w.w.length + ' letters.' : 'Check each letter against the tiles.'), 'bad'); input.select(); }
  });
  hintBtn.addEventListener('click', function () {
    if (st.locked) return;
    var w = st.words[st.i]; st.hints++;
    if (st.hintStep === 0) { st.hintStep = 1; status.say('Hint: ' + w.hint, 'info'); }
    else { status.say('Hint: the word starts with ' + w.w.charAt(0).toUpperCase() + ' and has ' + w.w.length + ' letters.', 'info'); }
  });
  giveUpBtn.addEventListener('click', function () {
    if (st.locked) return;
    var w = st.words[st.i]; st.skipped++; lock();
    status.say('The word was ' + w.w.toUpperCase() + '. ' + w.hint, 'info');
  });
  nextBtn.addEventListener('click', function () {
    if (st.i < st.words.length - 1) { st.i++; showRound(); return; }
    var score = st.correct;
    var best = BG.recordBest('anagram:' + st.level, score, score + ' of ' + st.words.length + ' correct', 'high');
    play.hidden = true;
    status.say('Game finished.', 'info');
    BG.ui.result(resultHost, 'You solved ' + score + ' of ' + st.words.length, [(best ? 'New personal best for ' + st.level + ' anagrams. ' : '') + 'Hints used: ' + st.hints + '. Words skipped: ' + st.skipped + '.', 'Tip: look for common endings such as -ING, -ER and -ED, and pairs such as TH or CH, then build the word around them.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { newGame(controls.level()); } })]);
  });
  BG.games.anagram.state = function () { return st; };
})();
