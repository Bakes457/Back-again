/* Spot the Difference: an original SVG cottage scene drawn twice. Some features are changed in the right-hand picture.
   Tap or click a difference in either picture. Keyboard and screen reader users can use the "Check an area" buttons,
   which compare both pictures in words. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var W = 400, H = 300;
  var DIFFS = [
    { id: 'cloud', area: 'Sky clouds', x: 262, y: 62, r: 34, a: 'two clouds', b: 'one cloud' },
    { id: 'window', area: 'Window', x: 170, y: 193, r: 30, a: 'cross bars dividing the glass', b: 'plain glass' },
    { id: 'smoke', area: 'Chimney', x: 206, y: 78, r: 30, a: 'smoke rising', b: 'no smoke' },
    { id: 'apples', area: 'Apple tree', x: 326, y: 160, r: 26, a: 'three apples', b: 'two apples' },
    { id: 'bird', area: 'Bird in the sky', x: 166, y: 50, r: 28, a: 'a bird flying', b: 'no bird' },
    { id: 'flowers', area: 'Flower bed', x: 85, y: 262, r: 28, a: 'three flowers', b: 'two flowers' },
    { id: 'door', area: 'Front door', x: 115, y: 225, r: 30, a: 'a brown door', b: 'a blue door' }
  ];
  var COUNTS = { easy: 4, medium: 5, hard: 7 };

  function scene(changed) {
    var c = function (id) { return !!changed[id]; };
    var s = '<rect width="400" height="300" fill="#cfe4f5"/>';
    s += '<circle cx="350" cy="48" r="22" fill="#f2c94c" stroke="#b8860b" stroke-width="2"/>';
    s += '<g fill="#fff" stroke="#8fa6bb" stroke-width="2"><ellipse cx="80" cy="52" rx="34" ry="14"/><ellipse cx="102" cy="44" rx="22" ry="12"/>';
    if (!c('cloud')) s += '<ellipse cx="258" cy="66" rx="30" ry="12"/><ellipse cx="274" cy="58" rx="18" ry="10"/>';
    s += '</g>';
    if (!c('bird')) s += '<path d="M150 52 q8 -9 16 0 q8 -9 16 0" fill="none" stroke="#18213a" stroke-width="3" stroke-linecap="round"/>';
    s += '<path d="M0 250 Q80 200 170 240 T400 235 V300 H0Z" fill="#a7cf9f"/><rect y="250" width="400" height="50" fill="#8fbf8f"/>';
    s += '<rect x="190" y="100" width="18" height="44" fill="#9a5b43" stroke="#18213a" stroke-width="2"/>';
    if (!c('smoke')) s += '<g fill="#e7e7e7" stroke="#9aa3b2" stroke-width="2"><circle cx="199" cy="90" r="7"/><circle cx="206" cy="76" r="9"/><circle cx="215" cy="60" r="11"/></g>';
    s += '<rect x="90" y="150" width="130" height="100" fill="#f1e2c4" stroke="#18213a" stroke-width="3"/>';
    s += '<polygon points="78,152 155,104 232,152" fill="#b5533c" stroke="#18213a" stroke-width="3" stroke-linejoin="round"/>';
    s += '<rect x="100" y="200" width="30" height="50" fill="' + (c('door') ? '#2f5d8a' : '#7a4524') + '" stroke="#18213a" stroke-width="3"/><circle cx="124" cy="226" r="2.5" fill="#f2c94c"/>';
    s += '<rect x="150" y="175" width="40" height="36" fill="#bfe0f2" stroke="#18213a" stroke-width="3"/>';
    if (!c('window')) s += '<path d="M170 175v36M150 193h40" stroke="#18213a" stroke-width="3"/>';
    s += '<rect x="305" y="200" width="16" height="50" fill="#7a5233" stroke="#18213a" stroke-width="2"/><circle cx="313" cy="175" r="40" fill="#5e9c5a" stroke="#18213a" stroke-width="3"/>';
    s += '<g fill="#c0392b" stroke="#18213a" stroke-width="2"><circle cx="294" cy="172" r="6"/><circle cx="318" cy="192" r="6"/>';
    if (!c('apples')) s += '<circle cx="326" cy="160" r="6"/>';
    s += '</g>';
    [[50, 'f1'], [85, 'f2'], [120, 'f3']].forEach(function (f) {
      if (f[1] === 'f2' && c('flowers')) return;
      s += '<path d="M' + f[0] + ' 285 V262" stroke="#2e6b3a" stroke-width="3"/><circle cx="' + f[0] + '" cy="259" r="8" fill="' + (f[1] === 'f2' ? '#e86a8a' : '#f2c94c') + '" stroke="#18213a" stroke-width="2"/><circle cx="' + f[0] + '" cy="259" r="2.5" fill="#18213a"/>';
    });
    return s;
  }
  function pickDiffs(level, rnd) { return U.shuffle(DIFFS, rnd).slice(0, COUNTS[level]).map(function (d) { return d.id; }); }
  function hit(active, x, y) {
    var found = null, best = 1e9;
    DIFFS.forEach(function (d) {
      if (active.indexOf(d.id) < 0) return;
      var dist = Math.sqrt((d.x - x) * (d.x - x) + (d.y - y) * (d.y - y));
      if (dist <= d.r + 6 && dist < best) { best = dist; found = d.id; }
    });
    return found;
  }
  BG.games.spot = { DIFFS: DIFFS, COUNTS: COUNTS, scene: scene, pickDiffs: pickDiffs, hit: hit };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { level: 'easy', active: [], found: {}, misses: 0, hints: 0, t0: 0, iv: null, over: true, hintTimer: null, hintId: null };
  var status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'spot', levels: [{ v: 'easy', label: 'Easy (4 differences)' }, { v: 'medium', label: 'Medium (5 differences)' }, { v: 'hard', label: 'Hard (7 differences)' }], newLabel: 'New puzzle', onStart: begin, onRestart: function () { begin(st.level, st.active); } });
  var timeEl = el('span', { text: 'Time 0:00' }), foundEl = el('span'), missEl = el('span'), hintEl = el('span');
  var meta = el('div', { class: 'game-meta', hidden: true }, [timeEl, foundEl, missEl, hintEl]);
  var svgA = svg('a', 'Picture A, the original: a cottage with a chimney, a window, a door, an apple tree, clouds and a flower bed'), svgB = svg('b', 'Picture B, the changed picture: the same cottage with some features altered');
  function svg(id, label) { var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); s.setAttribute('viewBox', '0 0 ' + W + ' ' + H); s.setAttribute('role', 'img'); s.setAttribute('aria-label', label); s.setAttribute('data-pic', id); return s; }
  var pair = el('div', { class: 'spot-pair' }, [el('figure', { class: 'spot-pic' }, [svgA, el('figcaption', { text: 'Picture A' })]), el('figure', { class: 'spot-pic' }, [svgB, el('figcaption', { text: 'Picture B' })])]);
  var hintBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Hint (3 available)' });
  var areaList = el('ul', { class: 'area-list' });
  var describe = el('details', { class: 'how-to' }, [el('summary', { text: 'Text description of both pictures' }), el('div', { id: 'spot-text' })]);
  var area = el('div', { hidden: true }, [pair, el('div', { class: 'btn-row', style: 'margin-top:1rem' }, [hintBtn]),
    el('h2', { style: 'margin-top:1.5rem;font-size:1.2rem', text: 'Check an area (keyboard and screen reader alternative)' }),
    el('p', { class: 'small muted', text: 'Each button compares one area of the two pictures in words and tells you if it is a difference. Differences are also marked on both pictures when you find them.' }), areaList, describe]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. Find every difference between Picture A and Picture B.' });
  [controls.el, intro, meta, area, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function begin(level, active) {
    clearInterval(st.iv); clearTimeout(st.hintTimer);
    st.level = level; st.active = active || pickDiffs(level); st.found = {}; st.misses = 0; st.hints = 0; st.over = false; st.hintId = null;
    intro.hidden = true; area.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost);
    hintBtn.disabled = false; hintBtn.textContent = 'Hint (3 available)';
    var changed = {}; st.active.forEach(function (id) { changed[id] = true; });
    st.base = { a: scene({}), b: scene(changed) };
    areaList.innerHTML = '';
    DIFFS.forEach(function (d) { areaList.appendChild(el('li', {}, [el('button', { type: 'button', class: 'btn btn-quiet btn-small', 'data-area': d.id, text: 'Check: ' + d.area })])); });
    buildText();
    st.t0 = Date.now(); st.iv = setInterval(function () { timeEl.textContent = 'Time ' + U.fmtTime((Date.now() - st.t0) / 1000); }, 1000); timeEl.textContent = 'Time 0:00';
    paint(); status.say('Find ' + st.active.length + ' differences. Click or tap them in either picture.', 'info');
  }
  function buildText() {
    var t = document.getElementById('spot-text'); t.innerHTML = '';
    ['a', 'b'].forEach(function (pic) {
      t.appendChild(el('h3', { text: 'Picture ' + pic.toUpperCase() }));
      t.appendChild(el('ul', {}, DIFFS.map(function (d) { var diff = st.active.indexOf(d.id) > -1; return el('li', { text: d.area + ': ' + (pic === 'b' && diff ? d.b : d.a) + '.' }); })));
    });
  }
  function overlay() {
    var s = '';
    Object.keys(st.found).forEach(function (id, n) { var d = DIFFS.filter(function (x) { return x.id === id; })[0]; s += '<circle class="spot-found" cx="' + d.x + '" cy="' + d.y + '" r="' + (d.r - 2) + '"/><text class="spot-found-label" x="' + (d.x - 4) + '" y="' + (d.y - d.r - 4) + '">\u2713</text>'; });
    if (st.hintId) { var h = DIFFS.filter(function (x) { return x.id === st.hintId; })[0]; s += '<circle class="spot-hint" cx="' + h.x + '" cy="' + h.y + '" r="' + (h.r + 4) + '"/>'; }
    return s;
  }
  function paint() {
    svgA.innerHTML = st.base.a + overlay(); svgB.innerHTML = st.base.b + overlay();
    var n = Object.keys(st.found).length;
    foundEl.textContent = 'Found ' + n + ' of ' + st.active.length; missEl.textContent = 'Misses ' + st.misses; hintEl.textContent = 'Hints used ' + st.hints;
  }
  function markFound(id) {
    st.found[id] = true; paint();
    var d = DIFFS.filter(function (x) { return x.id === id; })[0], left = st.active.length - Object.keys(st.found).length;
    if (left === 0) finish(); else status.say('Difference found: ' + d.area.toLowerCase() + ' (' + d.a + ' in A, ' + d.b + ' in B). ' + left + ' to go.', 'ok');
  }
  function clickAt(x, y) {
    if (st.over) return null;
    var id = hit(st.active, x, y);
    if (id && !st.found[id]) { markFound(id); return id; }
    if (id) { status.say('You already found that one.', 'info'); return id; }
    st.misses++; paint(); status.say('No difference there. Look at the shapes and details closely.', 'bad');
    return null;
  }
  [svgA, svgB].forEach(function (s) {
    s.addEventListener('click', function (e) {
      var r = s.getBoundingClientRect(); if (!r.width) return;
      clickAt((e.clientX - r.left) * W / r.width, (e.clientY - r.top) * H / r.height);
    });
  });
  areaList.addEventListener('click', function (e) {
    var b = e.target.closest('[data-area]'); if (!b || st.over) return;
    var id = b.getAttribute('data-area'), d = DIFFS.filter(function (x) { return x.id === id; })[0], diff = st.active.indexOf(id) > -1;
    if (!diff) { status.say(d.area + ': both pictures show ' + d.a + '. This is not a difference.', 'bad'); return; }
    if (st.found[id]) { status.say(d.area + ': you already found this difference.', 'info'); return; }
    markFound(id);
  });
  hintBtn.addEventListener('click', function () {
    if (st.over || st.hints >= 3) return;
    var left = st.active.filter(function (id) { return !st.found[id]; }); if (!left.length) return;
    st.hints++; st.hintId = U.pick(left); paint();
    hintBtn.textContent = st.hints >= 3 ? 'No hints left' : 'Hint (' + (3 - st.hints) + ' left)'; hintBtn.disabled = st.hints >= 3;
    var d = DIFFS.filter(function (x) { return x.id === st.hintId; })[0];
    status.say('Hint: look near the ' + d.area.toLowerCase() + '. A dashed ring is shown for a few seconds.', 'info');
    clearTimeout(st.hintTimer); st.hintTimer = setTimeout(function () { st.hintId = null; if (!st.over) paint(); }, 4000);
  });
  function finish() {
    st.over = true; clearInterval(st.iv); clearTimeout(st.hintTimer); st.hintId = null; paint();
    var secs = Math.round((Date.now() - st.t0) / 1000);
    var best = BG.recordBest('spot-the-difference:' + st.level, secs, U.fmtTime(secs) + ', ' + st.misses + ' misses', 'low');
    status.say('All differences found.', 'ok');
    BG.ui.result(resultHost, 'All ' + st.active.length + ' differences found in ' + U.fmtTime(secs), [(best ? 'New personal best for ' + st.level + '. ' : '') + 'Misses: ' + st.misses + '. Hints used: ' + st.hints + '.', 'The differences were: ' + st.active.map(function (id) { var d = DIFFS.filter(function (x) { return x.id === id; })[0]; return d.area.toLowerCase() + ' (' + d.a + ' in A, ' + d.b + ' in B)'; }).join('; ') + '.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'New puzzle', onclick: function () { begin(controls.level()); } })]);
  }
  BG.games.spot.state = function () { return st; };
  BG.games.spot.clickAt = clickAt;
})();
