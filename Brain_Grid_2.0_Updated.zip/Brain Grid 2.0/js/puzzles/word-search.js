/* Word Search. Grids are generated from themed word lists. Select with mouse or touch by dragging in a straight line,
   or with the keyboard: arrow keys move the cursor, Enter marks the start and Enter again marks the end. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var THEMES = [
    { name: 'Animals', words: ['TIGER', 'ZEBRA', 'OTTER', 'PANDA', 'KOALA', 'EAGLE', 'HORSE', 'MOOSE', 'LLAMA', 'SHEEP', 'RABBIT', 'FALCON', 'GIRAFFE', 'DOLPHIN', 'PENGUIN', 'BADGER'] },
    { name: 'Kitchen', words: ['SPOON', 'KNIFE', 'PLATE', 'WHISK', 'LADLE', 'KETTLE', 'BLENDER', 'SKILLET', 'TEAPOT', 'GRATER', 'COLANDER', 'TOASTER', 'OVEN', 'FORK', 'BOWL'] },
    { name: 'Space', words: ['ORBIT', 'COMET', 'LUNAR', 'SOLAR', 'GALAXY', 'METEOR', 'PLANET', 'ROCKET', 'SATURN', 'NEBULA', 'ECLIPSE', 'MARS', 'STAR', 'TELESCOPE'] },
    { name: 'Weather', words: ['STORM', 'CLOUD', 'BREEZE', 'FROST', 'THUNDER', 'SUNNY', 'RAINBOW', 'TORNADO', 'DRIZZLE', 'MONSOON', 'HAIL', 'SNOW', 'FOGGY'] },
    { name: 'Garden', words: ['TULIP', 'DAISY', 'ROSES', 'PLANT', 'SEEDS', 'SHOVEL', 'TROWEL', 'COMPOST', 'LAVENDER', 'HEDGE', 'FENCE', 'GRASS', 'MARIGOLD'] }
  ];
  var LEVELS = {
    easy: { size: 8, count: 5, dirs: [[0, 1], [1, 0]] },
    medium: { size: 10, count: 7, dirs: [[0, 1], [1, 0], [1, 1], [-1, 1]] },
    hard: { size: 12, count: 9, dirs: [[0, 1], [1, 0], [1, 1], [-1, 1], [0, -1], [-1, 0], [-1, -1], [1, -1]] }
  };
  var ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

  function generate(level, rnd) {
    rnd = rnd || Math.random;
    var cfg = LEVELS[level], n = cfg.size;
    for (var attempt = 0; attempt < 60; attempt++) {
      var theme = U.pick(THEMES, rnd);
      var words = U.shuffle(theme.words.filter(function (w) { return w.length <= n; }), rnd).slice(0, cfg.count).sort(function (a, b) { return b.length - a.length; });
      var grid = []; for (var i = 0; i < n * n; i++) grid.push('');
      var placed = [], ok = true;
      for (var wi = 0; wi < words.length && ok; wi++) {
        var w = words[wi], done = false;
        for (var t = 0; t < 250 && !done; t++) {
          var d = U.pick(cfg.dirs, rnd), r = Math.floor(rnd() * n), c = Math.floor(rnd() * n);
          var er = r + d[0] * (w.length - 1), ec = c + d[1] * (w.length - 1);
          if (er < 0 || er >= n || ec < 0 || ec >= n) continue;
          var fits = true;
          for (var k = 0; k < w.length; k++) { var cell = grid[(r + d[0] * k) * n + c + d[1] * k]; if (cell && cell !== w[k]) { fits = false; break; } }
          if (!fits) continue;
          var cellsUsed = [];
          for (var k2 = 0; k2 < w.length; k2++) { var idx = (r + d[0] * k2) * n + c + d[1] * k2; grid[idx] = w[k2]; cellsUsed.push(idx); }
          placed.push({ word: w, cells: cellsUsed }); done = true;
        }
        if (!done) ok = false;
      }
      if (!ok) continue;
      for (var f = 0; f < grid.length; f++) if (!grid[f]) grid[f] = ALPHA[Math.floor(rnd() * 26)];
      return { n: n, grid: grid, words: placed, theme: theme.name };
    }
    throw new Error('Could not generate a word search');
  }
  /* The straight line of cell indexes from a to b (8 directions), or null if they are not aligned. */
  function lineBetween(a, b, n) {
    var ar = (a / n) | 0, ac = a % n, br = (b / n) | 0, bc = b % n, dr = br - ar, dc = bc - ac;
    if (!(dr === 0 || dc === 0 || Math.abs(dr) === Math.abs(dc))) return null;
    var steps = Math.max(Math.abs(dr), Math.abs(dc)), sr = Math.sign(dr), sc = Math.sign(dc), out = [];
    for (var i = 0; i <= steps; i++) out.push((ar + sr * i) * n + ac + sc * i);
    return out;
  }
  BG.games.wordSearch = { generate: generate, lineBetween: lineBetween, LEVELS: LEVELS };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { puzzle: null, found: {}, start: -1, end: -1, level: 'easy', t0: 0, timer: null, over: false, cursor: 0, kbActive: false };
  var cells = [], status = BG.ui.status(), resultHost = el('div', {}), timerEl = el('span', { text: 'Time 0:00' }), progEl = el('span', { text: '' });
  var controls = BG.ui.controls({ id: 'word-search', levels: [{ v: 'easy', label: 'Easy (8x8, 5 words)' }, { v: 'medium', label: 'Medium (10x10, 7 words)' }, { v: 'hard', label: 'Hard (12x12, 9 words, all directions)' }], onStart: newGame, onRestart: function () { if (st.puzzle) begin(st.puzzle); } });
  var gridEl = el('div', { class: 'ws-grid', role: 'grid', 'aria-label': 'Letter grid' });
  var listEl = el('ul', { class: 'ws-words', 'aria-label': 'Words to find' });
  var themeEl = el('p', { class: 'muted' });
  var layout = el('div', { class: 'ws-layout', hidden: true }, [gridEl, el('div', {}, [themeEl, el('h2', { text: 'Words to find' }), listEl, el('p', { class: 'small muted', text: 'Words run in straight lines. Drag across the letters, or use the keyboard: arrows to move, Enter to mark the first and last letter.' })])]);
  var meta = el('div', { class: 'game-meta', hidden: true }, [timerEl, progEl]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start to generate a new word search.' });
  [controls.el, intro, meta, layout, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function newGame(level) { st.level = level; begin(generate(level)); }
  function begin(p) {
    st.puzzle = p; st.found = {}; st.start = -1; st.end = -1; st.over = false; st.cursor = 0; st.kbActive = false;
    intro.hidden = true; layout.hidden = false; meta.hidden = false;
    BG.ui.clearResult(resultHost);
    gridEl.innerHTML = ''; cells = [];
    gridEl.style.gridTemplateColumns = 'repeat(' + p.n + ', minmax(0, 1fr))';
    p.grid.forEach(function (ch, i) {
      var b = el('button', { type: 'button', class: 'ws-cell', role: 'gridcell', tabindex: i === 0 ? '0' : '-1', 'data-i': String(i), 'aria-label': 'Row ' + ((i / p.n | 0) + 1) + ', column ' + (i % p.n + 1) + ', letter ' + ch, text: ch });
      cells.push(b); gridEl.appendChild(b);
    });
    listEl.innerHTML = '';
    p.words.forEach(function (w) { listEl.appendChild(el('li', { 'data-word': w.word, text: w.word })); });
    themeEl.textContent = 'Theme: ' + p.theme;
    clearInterval(st.timer); st.t0 = Date.now(); st.timer = setInterval(tick, 1000); tick(); updateProgress();
    status.say('New puzzle ready. Find all ' + p.words.length + ' words.', 'info');
  }
  function tick() { timerEl.textContent = 'Time ' + U.fmtTime((Date.now() - st.t0) / 1000); }
  function updateProgress() { progEl.textContent = Object.keys(st.found).length + ' of ' + st.puzzle.words.length + ' words found'; }
  function paintSelection() {
    var line = st.start > -1 && st.end > -1 ? lineBetween(st.start, st.end, st.puzzle.n) : (st.start > -1 ? [st.start] : []);
    cells.forEach(function (c, i) { c.classList.toggle('is-selecting', line && line.indexOf(i) > -1); });
  }
  function paintFound() {
    var foundCells = {};
    Object.keys(st.found).forEach(function (w) { st.found[w].forEach(function (i) { foundCells[i] = true; }); });
    cells.forEach(function (c, i) { c.classList.toggle('is-found', !!foundCells[i]); });
    Array.prototype.forEach.call(listEl.children, function (li) { li.classList.toggle('is-found', !!st.found[li.getAttribute('data-word')]); });
  }
  function evaluate() {
    if (st.start < 0 || st.end < 0) { clearSelection(); return; }
    var line = lineBetween(st.start, st.end, st.puzzle.n);
    clearSelection();
    if (!line || line.length < 2) return;
    var text = line.map(function (i) { return st.puzzle.grid[i]; }).join(''), rev = text.split('').reverse().join('');
    var match = st.puzzle.words.filter(function (w) { return !st.found[w.word] && (w.word === text || w.word === rev); })[0];
    if (!match) { status.say('"' + text + '" is not one of the hidden words.', 'bad'); return; }
    st.found[match.word] = line; paintFound(); updateProgress();
    var left = st.puzzle.words.length - Object.keys(st.found).length;
    if (left === 0) finish(); else status.say('Found ' + match.word + '. ' + left + (left === 1 ? ' word' : ' words') + ' left.', 'ok');
  }
  function clearSelection() { st.start = -1; st.end = -1; st.kbActive = false; paintSelection(); }
  function finish() {
    st.over = true; clearInterval(st.timer);
    var secs = Math.round((Date.now() - st.t0) / 1000);
    var best = BG.recordBest('word-search:' + st.level, secs, U.fmtTime(secs), 'low');
    status.say('All words found.', 'ok');
    BG.ui.result(resultHost, 'Puzzle complete in ' + U.fmtTime(secs), [(best ? 'New personal best for ' + st.level + ' word search. ' : '') + 'You found all ' + st.puzzle.words.length + ' words on the ' + st.puzzle.theme.toLowerCase() + ' theme.', 'Tip: scan for the rarest letters first (Q, Z, K, X), then follow the neighbours.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'New puzzle', onclick: function () { newGame(controls.level()); } })]);
  }
  /* Pointer selection (mouse, pen and touch share these events). */
  function cellFromEvent(e) {
    var t = typeof document.elementFromPoint === 'function' ? document.elementFromPoint(e.clientX, e.clientY) : null;
    t = t || e.target;
    var c = t && t.closest ? t.closest('.ws-cell') : null;
    return c && gridEl.contains(c) ? parseInt(c.getAttribute('data-i'), 10) : -1;
  }
  var dragging = false;
  gridEl.addEventListener('pointerdown', function (e) {
    if (!st.puzzle || st.over) return;
    if (e.button !== undefined && e.button > 0) return;
    var i = cellFromEvent(e); if (i < 0) return;
    e.preventDefault(); dragging = true; st.start = i; st.end = i; paintSelection();
  });
  gridEl.addEventListener('pointermove', function (e) {
    if (!dragging) return;
    var i = cellFromEvent(e); if (i < 0 || i === st.end) return;
    st.end = i; paintSelection();
  });
  function endDrag(e) { if (!dragging) return; dragging = false; var i = cellFromEvent(e); if (i > -1) st.end = i; evaluate(); }
  gridEl.addEventListener('pointerup', endDrag);
  gridEl.addEventListener('pointercancel', function () { dragging = false; clearSelection(); });
  /* Keyboard selection. */
  function moveCursor(i) {
    st.cursor = i;
    cells.forEach(function (c, n) { c.tabIndex = n === i ? 0 : -1; c.classList.toggle('is-cursor', n === i); });
    cells[i].focus();
    if (st.kbActive) { st.end = i; paintSelection(); }
  }
  gridEl.addEventListener('focusin', function (e) { var c = e.target.closest('.ws-cell'); if (c) { st.cursor = parseInt(c.getAttribute('data-i'), 10); c.classList.add('is-cursor'); } });
  gridEl.addEventListener('focusout', function (e) { var c = e.target.closest('.ws-cell'); if (c) c.classList.remove('is-cursor'); });
  gridEl.addEventListener('keydown', function (e) {
    if (!st.puzzle || st.over) return;
    var n = st.puzzle.n, r = st.cursor / n | 0, c = st.cursor % n, moved = true;
    if (e.key === 'ArrowUp') r = Math.max(0, r - 1);
    else if (e.key === 'ArrowDown') r = Math.min(n - 1, r + 1);
    else if (e.key === 'ArrowLeft') c = Math.max(0, c - 1);
    else if (e.key === 'ArrowRight') c = Math.min(n - 1, c + 1);
    else moved = false;
    if (moved) { e.preventDefault(); moveCursor(r * n + c); return; }
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      if (!st.kbActive) { st.kbActive = true; st.start = st.cursor; st.end = st.cursor; paintSelection(); status.say('Start letter marked. Move to the last letter and press Enter again.', 'info'); }
      else { st.end = st.cursor; evaluate(); }
    } else if (e.key === 'Escape' && st.kbActive) { e.preventDefault(); clearSelection(); status.say('Selection cancelled.', 'info'); }
  });
  BG.games.wordSearch.state = function () { return st; };
})();
