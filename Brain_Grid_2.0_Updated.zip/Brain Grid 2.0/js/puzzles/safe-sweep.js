/* Safe Sweep: reveal every safe square without touching a hidden mine. Numbers show how many of the 8 neighbours hold mines.
   The first reveal (and its neighbours) is always safe. Flag mode and right-click place flags. Keyboard: arrows, Space/Enter to reveal, F to flag. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var LEVELS = { easy: { n: 7, mines: 6 }, medium: { n: 8, mines: 10 }, hard: { n: 9, mines: 16 } };

  function neighbours(i, n) {
    var r = (i / n) | 0, c = i % n, out = [];
    for (var dr = -1; dr <= 1; dr++) for (var dc = -1; dc <= 1; dc++) {
      if (!dr && !dc) continue;
      var rr = r + dr, cc = c + dc;
      if (rr >= 0 && rr < n && cc >= 0 && cc < n) out.push(rr * n + cc);
    }
    return out;
  }
  /* Place mines anywhere except the first-clicked square and its neighbours. */
  function placeMines(n, count, safeIndex, rnd) {
    var banned = {}; banned[safeIndex] = true; neighbours(safeIndex, n).forEach(function (i) { banned[i] = true; });
    var pool = []; for (var i = 0; i < n * n; i++) if (!banned[i]) pool.push(i);
    var mines = {}; U.shuffle(pool, rnd).slice(0, count).forEach(function (i) { mines[i] = true; });
    var counts = []; for (var k = 0; k < n * n; k++) counts.push(mines[k] ? -1 : neighbours(k, n).filter(function (x) { return mines[x]; }).length);
    return { mines: mines, counts: counts };
  }
  /* Reveal from index; zeros spread outward. Returns the list of newly revealed indexes. */
  function reveal(counts, revealed, flags, n, start) {
    var opened = [], stack = [start];
    while (stack.length) {
      var i = stack.pop();
      if (revealed[i] || flags[i]) continue;
      revealed[i] = true; opened.push(i);
      if (counts[i] === 0) neighbours(i, n).forEach(function (x) { if (!revealed[x]) stack.push(x); });
    }
    return opened;
  }
  BG.games.safeSweep = { neighbours: neighbours, placeMines: placeMines, reveal: reveal, LEVELS: LEVELS };

  var root = document.getElementById('game-root');
  if (!root) return;
  var st = { n: 7, total: 6, mines: null, counts: null, revealed: {}, flags: {}, started: false, over: true, flagMode: false, t0: 0, iv: null, level: 'easy', cursor: 0 };
  var cells = [], status = BG.ui.status(), resultHost = el('div', {});
  var controls = BG.ui.controls({ id: 'safe-sweep', levels: [{ v: 'easy', label: 'Easy (7x7, 6 mines)' }, { v: 'medium', label: 'Medium (8x8, 10 mines)' }, { v: 'hard', label: 'Hard (9x9, 16 mines)' }], newLabel: 'New board', onStart: start, onRestart: function () { start(st.level); } });
  var timeEl = el('span', { text: 'Time 0:00' }), flagsEl = el('span', { text: '' });
  var flagBtn = el('button', { type: 'button', class: 'btn', 'aria-pressed': 'false', text: 'Flag mode: off' });
  var meta = el('div', { class: 'game-meta', hidden: true }, [timeEl, flagsEl]);
  var grid = el('div', { class: 'ss-grid', role: 'grid', 'aria-label': 'Minefield' });
  var play = el('div', { hidden: true }, [el('div', { class: 'btn-row', style: 'margin-bottom:.75rem' }, [flagBtn]), grid, el('p', { class: 'small muted', text: 'Tap or click to reveal. Turn on flag mode (or right-click, or press F) to mark a suspected mine.' })]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. Your first reveal is always safe.' });
  [controls.el, intro, meta, play, status.el, resultHost].forEach(function (n) { root.appendChild(n); });

  function start(level) {
    var cfg = LEVELS[level]; st.level = level; st.n = cfg.n; st.total = cfg.mines;
    st.mines = null; st.counts = null; st.revealed = {}; st.flags = {}; st.started = false; st.over = false; st.cursor = 0;
    clearInterval(st.iv); timeEl.textContent = 'Time 0:00';
    intro.hidden = true; play.hidden = false; meta.hidden = false; BG.ui.clearResult(resultHost);
    grid.style.gridTemplateColumns = 'repeat(' + st.n + ', minmax(0, 1fr))'; grid.innerHTML = ''; cells = [];
    for (var i = 0; i < st.n * st.n; i++) (function (idx) {
      var b = el('button', { type: 'button', class: 'ss-cell', role: 'gridcell', tabindex: idx === 0 ? '0' : '-1', 'data-i': String(idx) });
      b.addEventListener('click', function () { st.cursor = idx; tap(idx); });
      b.addEventListener('contextmenu', function (e) { e.preventDefault(); toggleFlag(idx); });
      cells.push(b); grid.appendChild(b);
    })(i);
    paintAll(); status.say('Board ready. Reveal any square to begin.', 'info');
  }
  function label(i) {
    var r = (i / st.n | 0) + 1, c = i % st.n + 1, s = 'Row ' + r + ', column ' + c + ', ';
    if (st.revealed[i]) s += st.mines && st.mines[i] ? 'mine' : (st.counts[i] === 0 ? 'empty, no neighbouring mines' : st.counts[i] + ' neighbouring ' + (st.counts[i] === 1 ? 'mine' : 'mines'));
    else s += st.flags[i] ? 'flagged' : 'hidden';
    return s;
  }
  function paint(i) {
    var b = cells[i], rev = st.revealed[i], mine = st.mines && st.mines[i];
    b.className = 'ss-cell' + (rev ? ' is-open' : '') + (rev && mine ? ' is-mine' : '') + (st.flags[i] && !rev ? ' is-flag' : '') + (rev && !mine && st.counts[i] > 0 ? ' n' + st.counts[i] : '');
    b.textContent = rev ? (mine ? '\u2738' : (st.counts[i] > 0 ? String(st.counts[i]) : '')) : (st.flags[i] ? '\u2691' : '');
    b.setAttribute('aria-label', label(i));
  }
  function paintAll() { cells.forEach(function (_, i) { paint(i); }); flagsEl.textContent = 'Mines left ' + (st.total - Object.keys(st.flags).length); }
  function tap(i) {
    if (st.over) return;
    if (st.flagMode) return toggleFlag(i);
    if (st.flags[i] || st.revealed[i]) return;
    if (!st.started) {
      var m = placeMines(st.n, st.total, i); st.mines = m.mines; st.counts = m.counts; st.started = true;
      st.t0 = Date.now(); st.iv = setInterval(function () { timeEl.textContent = 'Time ' + U.fmtTime((Date.now() - st.t0) / 1000); }, 1000);
    }
    if (st.mines[i]) return lose(i);
    reveal(st.counts, st.revealed, st.flags, st.n, i); paintAll();
    var safeLeft = st.n * st.n - st.total - Object.keys(st.revealed).length;
    if (safeLeft === 0) win(); else status.say(safeLeft + ' safe squares left.', 'info');
  }
  function toggleFlag(i) {
    if (st.over || st.revealed[i]) return;
    if (st.flags[i]) delete st.flags[i]; else st.flags[i] = true;
    paint(i); flagsEl.textContent = 'Mines left ' + (st.total - Object.keys(st.flags).length);
    status.say(st.flags[i] ? 'Flag placed.' : 'Flag removed.', 'info');
  }
  function lose(hit) {
    st.over = true; clearInterval(st.iv);
    Object.keys(st.mines).forEach(function (k) { st.revealed[k] = true; }); paintAll(); cells[hit].classList.add('is-hit');
    status.say('That square was a mine.', 'bad');
    BG.ui.result(resultHost, 'Boom: you hit a mine', ['All the mines are now shown. Each number counts the mines touching that square, including diagonals.', 'Tip: when a number equals the count of hidden squares around it, all of those squares are mines.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Try a new board', onclick: function () { start(controls.level()); } })]);
  }
  function win() {
    st.over = true; clearInterval(st.iv);
    var secs = Math.round((Date.now() - st.t0) / 1000);
    var best = BG.recordBest('safe-sweep:' + st.level, secs, U.fmtTime(secs), 'low');
    paintAll(); status.say('Every safe square is revealed.', 'ok');
    BG.ui.result(resultHost, 'Cleared in ' + U.fmtTime(secs), [(best ? 'New personal best for ' + st.level + '. ' : '') + 'You found every safe square without hitting a mine.'], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play again', onclick: function () { start(controls.level()); } })]);
  }
  flagBtn.addEventListener('click', function () { st.flagMode = !st.flagMode; flagBtn.setAttribute('aria-pressed', String(st.flagMode)); flagBtn.textContent = 'Flag mode: ' + (st.flagMode ? 'on' : 'off'); });
  grid.addEventListener('keydown', function (e) {
    if (st.over) return;
    var here = e.target.closest ? e.target.closest('.ss-cell') : null;
    if (here) st.cursor = parseInt(here.getAttribute('data-i'), 10);
    var n = st.n, r = st.cursor / n | 0, c = st.cursor % n, moved = true;
    if (e.key === 'ArrowUp') r = Math.max(0, r - 1); else if (e.key === 'ArrowDown') r = Math.min(n - 1, r + 1);
    else if (e.key === 'ArrowLeft') c = Math.max(0, c - 1); else if (e.key === 'ArrowRight') c = Math.min(n - 1, c + 1); else moved = false;
    if (moved) { e.preventDefault(); st.cursor = r * n + c; cells.forEach(function (b, i) { b.tabIndex = i === st.cursor ? 0 : -1; }); cells[st.cursor].focus(); return; }
    if (e.key === 'f' || e.key === 'F') { e.preventDefault(); toggleFlag(st.cursor); }
  });
  BG.games.safeSweep.state = function () { return st; };
  BG.games.safeSweep.tap = tap;
  BG.games.safeSweep.flag = toggleFlag;
})();
