/* Sudoku. Every board starts from a known-valid solved grid that is shuffled with symmetry-preserving moves
   (relabel digits, swap rows within a band, swap bands, same for columns, transpose). Clues are then removed one at a time,
   and a removal is kept only if a solver proves the puzzle still has exactly ONE solution. */
(function () {
  'use strict';
  var BG = window.BG, U = BG.util, el = U.el;
  var CLUES = { easy: 40, medium: 32, hard: 26 };

  function baseGrid() { var g = []; for (var r = 0; r < 9; r++) for (var c = 0; c < 9; c++) g.push((r * 3 + Math.floor(r / 3) + c) % 9 + 1); return g; }
  function transform(g, rnd) {
    var digits = U.shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9], rnd), rows = [], cols = [], out = [], flip = rnd() < 0.5;
    U.shuffle([0, 1, 2], rnd).forEach(function (b) { U.shuffle([0, 1, 2], rnd).forEach(function (x) { rows.push(b * 3 + x); }); });
    U.shuffle([0, 1, 2], rnd).forEach(function (b) { U.shuffle([0, 1, 2], rnd).forEach(function (x) { cols.push(b * 3 + x); }); });
    for (var r = 0; r < 9; r++) for (var c = 0; c < 9; c++) { var v = flip ? g[cols[c] * 9 + rows[r]] : g[rows[r] * 9 + cols[c]]; out.push(digits[v - 1]); }
    return out;
  }
  function isValidSolution(g) {
    if (g.length !== 81) return false;
    for (var i = 0; i < 9; i++) {
      var r = 0, c = 0, b = 0;
      for (var j = 0; j < 9; j++) {
        var rv = g[i * 9 + j], cv = g[j * 9 + i], bv = g[(Math.floor(i / 3) * 3 + Math.floor(j / 3)) * 9 + (i % 3) * 3 + (j % 3)];
        if (!(rv >= 1 && rv <= 9 && cv >= 1 && cv <= 9 && bv >= 1 && bv <= 9)) return false;
        r |= 1 << rv; c |= 1 << cv; b |= 1 << bv;
      }
      if (r !== 0x3FE || c !== 0x3FE || b !== 0x3FE) return false;
    }
    return true;
  }
  /* Counts solutions up to `limit` using bitmasks and the fewest-candidates-first rule. */
  function countSolutions(puzzle, limit) {
    var g = puzzle.slice(), rowM = [], colM = [], boxM = [], count = 0, i;
    for (i = 0; i < 9; i++) { rowM.push(0); colM.push(0); boxM.push(0); }
    for (i = 0; i < 81; i++) {
      if (!g[i]) continue;
      var bit = 1 << g[i], r = (i / 9) | 0, c = i % 9, b = ((r / 3) | 0) * 3 + ((c / 3) | 0);
      if ((rowM[r] | colM[c] | boxM[b]) & bit) return 0;
      rowM[r] |= bit; colM[c] |= bit; boxM[b] |= bit;
    }
    function pop(m) { var n = 0; while (m) { m &= m - 1; n++; } return n; }
    function rec() {
      var best = -1, bestMask = 0, bestN = 10, k;
      for (k = 0; k < 81; k++) {
        if (g[k]) continue;
        var rr = (k / 9) | 0, cc = k % 9, bb = ((rr / 3) | 0) * 3 + ((cc / 3) | 0);
        var m = ~(rowM[rr] | colM[cc] | boxM[bb]) & 0x3FE, n = pop(m);
        if (n < bestN) { bestN = n; best = k; bestMask = m; if (n === 0) return; }
      }
      if (best < 0) { count++; return; }
      var r2 = (best / 9) | 0, c2 = best % 9, b2 = ((r2 / 3) | 0) * 3 + ((c2 / 3) | 0);
      for (var v = 1; v <= 9 && count < limit; v++) {
        var bt = 1 << v;
        if (!(bestMask & bt)) continue;
        g[best] = v; rowM[r2] |= bt; colM[c2] |= bt; boxM[b2] |= bt;
        rec();
        rowM[r2] &= ~bt; colM[c2] &= ~bt; boxM[b2] &= ~bt;
      }
      g[best] = 0;
    }
    rec();
    return count;
  }
  function generate(level, rnd) {
    rnd = rnd || Math.random;
    var solution = transform(baseGrid(), rnd), puzzle = solution.slice();
    var target = 81 - CLUES[level], removed = 0;
    var order = U.shuffle(Array.apply(null, { length: 81 }).map(function (_, i) { return i; }), rnd);
    for (var n = 0; n < order.length && removed < target; n++) {
      var idx = order[n], keep = puzzle[idx];
      puzzle[idx] = 0;
      if (countSolutions(puzzle, 2) === 1) removed++; else puzzle[idx] = keep;
    }
    return { puzzle: puzzle, solution: solution, clues: 81 - removed };
  }
  BG.games.sudoku = { generate: generate, countSolutions: countSolutions, isValidSolution: isValidSolution, CLUES: CLUES };

  var root = document.getElementById('game-root');
  if (!root) return;

  var st = { puzzle: null, solution: null, values: [], sel: -1, level: 'easy', start: 0, timer: null, over: false, revealed: false, errors: {} };
  var cells = [], status = BG.ui.status(), resultHost = el('div', {}), timerEl = el('span', { text: 'Time 0:00' }), filledEl = el('span', { text: '' });
  var controls = BG.ui.controls({ id: 'sudoku', levels: [{ v: 'easy', label: 'Easy' }, { v: 'medium', label: 'Medium' }, { v: 'hard', label: 'Hard' }], onStart: newGame, onRestart: restart });
  var board = el('div', { class: 'sudoku-board', role: 'grid', 'aria-label': 'Sudoku board' });
  for (var i = 0; i < 81; i++) {
    (function (idx) {
      var b = el('button', { type: 'button', class: 'sd-cell', role: 'gridcell', tabindex: idx === 0 ? '0' : '-1', 'data-i': String(idx) });
      b.addEventListener('click', function () { select(idx); });
      cells.push(b); board.appendChild(b);
    })(i);
  }
  var keypad = el('div', { class: 'keypad', role: 'group', 'aria-label': 'Number keypad' });
  for (var d = 1; d <= 9; d++) (function (n) { keypad.appendChild(el('button', { type: 'button', class: 'btn', 'aria-label': 'Enter ' + n, text: String(n), onclick: function () { enter(n); } })); })(d);
  keypad.appendChild(el('button', { type: 'button', class: 'btn', 'aria-label': 'Erase selected cell', text: 'Erase', onclick: function () { enter(0); } }));
  var checkBtn = el('button', { type: 'button', class: 'btn', text: 'Check answers', onclick: check });
  var showBtn = el('button', { type: 'button', class: 'btn btn-quiet', text: 'Show solution', onclick: showSolution });
  var side = el('div', { class: 'sudoku-side' }, [keypad, el('div', { class: 'btn-row' }, [checkBtn, showBtn])]);
  var meta = el('div', { class: 'game-meta' }, [timerEl, filledEl]);
  var area = el('div', { class: 'sudoku-wrap', hidden: true }, [board, side]);
  var intro = el('div', { class: 'placeholder-box', text: 'Choose a difficulty and press Start. Difficulty is based on how many clues are given.' });
  root.appendChild(controls.el); root.appendChild(intro); root.appendChild(meta); root.appendChild(area); root.appendChild(status.el); root.appendChild(resultHost);
  meta.hidden = true;

  function setBusy(on) { [checkBtn, showBtn].concat([].slice.call(keypad.children)).forEach(function (b) { b.disabled = on; }); }
  function newGame(level) {
    st.level = level;
    var g = generate(level);
    st.puzzle = g.puzzle; st.solution = g.solution;
    begin();
  }
  function restart() { if (st.puzzle) begin(); }
  function begin() {
    st.values = st.puzzle.slice(); st.sel = -1; st.over = false; st.revealed = false; st.errors = {};
    intro.hidden = true; area.hidden = false; meta.hidden = false;
    BG.ui.clearResult(resultHost); setBusy(false);
    clearInterval(st.timer); st.start = Date.now();
    st.timer = setInterval(tick, 1000); tick();
    render();
    /* Move focus onto the board so keyboard users can start typing straight away. */
    select(st.puzzle.indexOf(0) > -1 ? st.puzzle.indexOf(0) : 0);
    status.say('New ' + st.level + ' puzzle ready. Select a cell, then type a number from 1 to 9.', 'info');
  }
  function tick() { timerEl.textContent = 'Time ' + U.fmtTime((Date.now() - st.start) / 1000); }
  function select(i, quiet) {
    st.sel = i;
    cells.forEach(function (c, n) { c.tabIndex = n === i ? 0 : -1; });
    render();
    if (!quiet) cells[i].focus();
  }
  function label(i) {
    var r = (i / 9 | 0) + 1, c = i % 9 + 1, v = st.values[i];
    var s = 'Row ' + r + ', column ' + c + ', ';
    if (st.puzzle[i]) s += 'given ' + v; else if (v) s += 'your entry ' + v; else s += 'empty';
    if (st.errors[i]) s += ', incorrect';
    return s;
  }
  function render() {
    var sr = st.sel > -1 ? (st.sel / 9 | 0) : -1, sc = st.sel > -1 ? st.sel % 9 : -1, sv = st.sel > -1 ? st.values[st.sel] : 0, filled = 0;
    cells.forEach(function (cell, i) {
      var r = i / 9 | 0, c = i % 9, v = st.values[i];
      if (v) filled++;
      cell.textContent = v ? String(v) : '';
      var peer = st.sel > -1 && i !== st.sel && (r === sr || c === sc || (((r / 3) | 0) === ((sr / 3) | 0) && ((c / 3) | 0) === ((sc / 3) | 0)));
      cell.className = 'sd-cell' + (st.puzzle[i] ? ' is-given' : '') + (peer ? ' is-peer' : '') + (sv && v === sv && i !== st.sel ? ' is-same' : '') + (i === st.sel ? ' is-selected' : '') + (st.errors[i] ? ' is-error' : '');
      cell.setAttribute('aria-label', label(i));
      cell.setAttribute('aria-selected', i === st.sel ? 'true' : 'false');
    });
    filledEl.textContent = filled + ' of 81 cells filled';
  }
  function enter(n) {
    if (st.over || st.sel < 0) { if (st.sel < 0) status.say('Select a cell first.', 'info'); return; }
    if (st.puzzle[st.sel]) { status.say('That number is a given clue and cannot be changed.', 'info'); return; }
    st.values[st.sel] = n; st.errors = {};
    render();
    if (n === 0) { status.say('Cell cleared.', 'info'); return; }
    if (st.values.every(function (v) { return v > 0; })) finish();
  }
  function finish() {
    var wrongCount = 0;
    st.values.forEach(function (v, i) { if (v !== st.solution[i]) { st.errors[i] = true; wrongCount++; } });
    if (wrongCount) { render(); status.say('The board is full, but ' + wrongCount + (wrongCount === 1 ? ' cell is' : ' cells are') + ' wrong. Marked cells show where. Change them to finish.', 'bad'); return; }
    st.over = true; clearInterval(st.timer);
    var secs = Math.round((Date.now() - st.start) / 1000);
    var isBest = st.revealed ? false : BG.recordBest('sudoku:' + st.level, secs, U.fmtTime(secs), 'low');
    setBusy(true); render();
    status.say('Puzzle solved.', 'ok');
    BG.ui.result(resultHost, 'Solved in ' + U.fmtTime(secs), [
      (isBest ? 'New personal best for ' + st.level + ' Sudoku. ' : '') + 'Every row, column and 3x3 box now holds each digit from 1 to 9 exactly once.',
      'Why it works: this puzzle has exactly one solution, so each cell can always be found by logic, with no guessing. Try looking for a digit with only one possible cell in a row, column or box.'
    ], [el('button', { type: 'button', class: 'btn btn-primary', text: 'Play another', onclick: function () { newGame(controls.level()); } })]);
  }
  function check() {
    if (!st.puzzle || st.over) return;
    st.errors = {}; var wrong = 0, empty = 0;
    st.values.forEach(function (v, i) { if (!v) empty++; else if (v !== st.solution[i]) { st.errors[i] = true; wrong++; } });
    render();
    if (wrong) status.say(wrong + (wrong === 1 ? ' entry is' : ' entries are') + ' incorrect (marked with a cross and stripes). ' + empty + ' cells are still empty.', 'bad');
    else status.say(empty ? 'No mistakes so far. ' + empty + ' cells left to fill.' : 'All correct.', 'ok');
  }
  function showSolution() {
    if (!st.puzzle || st.over) return;
    st.values = st.solution.slice(); st.errors = {}; st.revealed = true; st.over = true; clearInterval(st.timer);
    setBusy(true); render();
    status.say('Solution shown. This attempt is not saved as a personal best. Press New puzzle to try another.', 'info');
  }
  board.addEventListener('keydown', function (e) {
    if (st.sel < 0) return;
    var r = st.sel / 9 | 0, c = st.sel % 9, moved = true;
    if (e.key === 'ArrowUp') r = Math.max(0, r - 1);
    else if (e.key === 'ArrowDown') r = Math.min(8, r + 1);
    else if (e.key === 'ArrowLeft') c = Math.max(0, c - 1);
    else if (e.key === 'ArrowRight') c = Math.min(8, c + 1);
    else moved = false;
    if (moved) { e.preventDefault(); select(r * 9 + c); return; }
    if (/^[1-9]$/.test(e.key)) { e.preventDefault(); enter(parseInt(e.key, 10)); }
    else if (e.key === 'Backspace' || e.key === 'Delete' || e.key === '0') { e.preventDefault(); enter(0); }
  });
  BG.games.sudoku.state = function () { return st; };
})();
