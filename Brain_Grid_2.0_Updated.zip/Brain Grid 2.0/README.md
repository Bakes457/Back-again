# BrainGrid 2.0

**Give your brain a daily challenge.**

BrainGrid is a free, static puzzle website: **18 playable games**, a five-puzzle Daily Challenge, personal best scores and badges, and 12 strategy articles. It is plain HTML, CSS and vanilla JavaScript, with no frameworks, no build step, no backend and no third-party requests (unless ads are switched on).

## What is new in 2.0

- **8 new games:** WordGrid (daily and practice word game), Tile Merge, Safe Sweep, Slide Tiles, Grid Lights, Echo Sequence, Cipher Quest and Drop Four.
- **New look:** a warm palette, a colour for each puzzle family, illustrated game cards, a "Today" panel with a progress ring, "got 3 minutes?" shortcuts, and a **dark theme** (follows your device, or use the button in the header).
- **Badges** on My Best Scores, earned only from what you have really played on your own device.
- **Contact page, HTML site map, XML site map with dates**, and `tools/site-tools.py` to set your domain and rebuild the sitemap in one command.
- More text on every page (per-game guides, difficulty explanations, FAQs, "common mistakes" in every article).
- AdSense readiness work (see below).

## The games

| Family | Games |
| --- | --- |
| Logic | Sudoku, Logic Grid, Riddle Challenge, Safe Sweep, Grid Lights, Drop Four |
| Word | WordGrid, Word Search, Anagram Challenge, Cipher Quest |
| Number | Number Sequence, Math Sprint, Tile Merge |
| Memory | Memory Match, Echo Sequence |
| Visual | Pattern Completion, Spot the Difference, Slide Tiles |

How they are built: Sudoku boards are verified to have exactly one solution; sliding and light puzzles are shuffled with legal moves so they are always solvable; number sequences and visual patterns are generated from rules so the answer cannot disagree with the question; Logic Grid puzzles are checked by brute force; Drop Four's computer opponent uses minimax search at Medium and Hard.

### About WordGrid

WordGrid is an **original game**: its own code, design, marks (check, diamond, cross, so colour is never the only signal), and a hand-written list of 886 everyday answer words. It is not affiliated with any other word game, and "Wordle" is a trademark of The New York Times Company, so that name is not used anywhere. A guessing game with per-letter feedback is a general idea, but this is not legal advice.

- Daily mode picks the word from your **local date**, so the same date gives the same word on any device.
- Guesses are checked against `js/wordlist.js`: every five-letter word from the MIT-licensed [`word-list`](https://www.npmjs.com/package/word-list) npm package (about 12,600 words). I have not independently verified the original licensing of the list that package is built from, so review it if that matters to you. The answer list is separate and hand-written.

## Project structure

```
index.html  play.html  daily.html  leaderboard.html  articles.html  about.html  contact.html  sitemap.html  404.html
logic.html  word-games.html  number-games.html  memory-games.html  visual-puzzles.html   (category pages)
privacy.html  cookie-policy.html  terms.html  data-deletion.html
games/       one page per game (18)
articles/    one page per article (12)
css/         style.css (design system, light and dark themes), games.css, responsive.css
js/
  storage.js  main.js  pools.js  search.js  daily.js  leaderboard.js
  config.js        the ONE file to edit for ads, owner name and contact email
  consent.js       cookie/ad choice banner and the consent-gated AdSense loader
  privacy-tools.js data deletion and contact form tools
  catalog.js       copy of data/*.json plus game icons (used by search and filters)
  wordlist.js      WordGrid answer and guess lists
  puzzles/         one script per game
data/  puzzles.json, articles.json      assets/  logo.svg, favicon.svg
tools/site-tools.py                      robots.txt  sitemap.xml  ads.txt
```

Every page uses relative paths, so it works from the site root and from `/games/` and `/articles/`.

## Open it locally

Double-click `index.html`. Everything works from `file://`. Some browsers give `file://` pages no storage; if your progress does not persist, run `python3 -m http.server 8000` in this folder and open http://localhost:8000.

## Hosting

Upload the folder contents to any static host (GitHub Pages, Cloudflare Pages, Netlify or plain hosting). Use **HTTPS**, which every one of those provides. Netlify and Cloudflare Pages serve `404.html` automatically; its CSS uses relative paths, so on deep missing URLs it may lose styling on some hosts.

## Domain, canonical URLs and the sitemap

Pick a domain, then run once:

```
python3 tools/site-tools.py domain https://www.your-domain.com
```

It replaces the `YOUR-DOMAIN.example` placeholder in every page, `sitemap.xml` and `robots.txt`, turns on each page's canonical link, and enables the `Sitemap:` line in `robots.txt`. Then submit `https://www.your-domain.com/sitemap.xml` in Google Search Console.

After adding or removing pages, run `python3 tools/site-tools.py sitemap` to rebuild `sitemap.xml` from the HTML files that exist (404 is excluded; `lastmod` comes from file dates). `sitemap.html` is the visitor-facing site map and is updated by hand when you add pages.

The tool needs Python 3 and nothing else. The website itself never needs it.

## Google AdSense

Your AdSense publisher ID (`ca-pub-5264717241062710`) is already set in `js/config.js`, `ads.txt` and an account **meta tag in every page**. That tag only identifies your account for verification. It loads nothing and sets no cookies.

**Ads themselves are still off**, deliberately. They switch on only when you have created ad units (or turned on auto ads), so that visitors are never asked for consent to ads that cannot appear. Until then there is no banner, no ad script and no request to Google.

I did **not** paste Google's raw snippet (`<script async src="...adsbygoogle.js?client=...">`) into each page's `<head>`. That would load Google's script before a visitor has agreed, which would contradict the consent banner and the privacy policy. The site loads that same script itself, with your ID, only after a visitor chooses "Accept all" or "Non-personalized ads only".

### Finish setting up

1. **Verify the site in AdSense.** When AdSense asks you to connect your site, choose the **meta tag** option (already in place) rather than the code snippet. `ads.txt` is also in place. Once your domain is live, both can be checked.
2. **Create two display ad units** in AdSense (Ads > By ad unit) and copy their numeric IDs (the `data-ad-slot` number).
3. Put them in **`js/config.js`**:
   ```js
   adSlots: { content: '1111111111', article: '2222222222' },
   ownerName: 'Your Name or Organisation',
   contactEmail: 'you@your-domain.com'
   ```
   Ads and the consent banner turn on as soon as at least one ad unit ID is set.
   Alternatively set `autoAds: true` if you enabled Auto ads in AdSense. Google then chooses placements itself (you lose control of where ads appear; use AdSense's page exclusions to keep them away from games).
4. To change the publisher ID later: `python3 tools/site-tools.py adsense ca-pub-XXXXXXXXXXXXXXXX` updates `js/config.js`, `ads.txt` and every page together.

### How ads behave

- **Nothing is requested from Google until the visitor chooses.** The banner offers *Accept all*, *Non-personalized ads only* and *Reject* as identical buttons. Reject never loads the ad script. Choices are saved as `braingrid_consent` and can be changed from *Cookie settings* in the footer.
- Ads appear **below** games (never inside them), inside articles, and on the play, category and article-list pages, at most one per page. They are labelled "Advertisement" and kept clear of controls. There are none on the homepage, Daily Challenge, My Best Scores, legal pages, About, Contact or 404.

### AdSense readiness: what I checked and changed

I reviewed Google's published eligibility page and several third-party guides. Note the difference between the two:

- **Google's own stated basics:** you must be 18 or over, own the site (or have permission and access to its code), have original content, and follow the AdSense program policies. There is no official minimum word count or page count.
- **Common advice from blogs (not official rules):** a clear About page, Contact page and Privacy Policy, plenty of original pages, good navigation, mobile friendliness, and no thin or copied content. Many guides suggest 15 to 30 substantial pages and 600+ words per article. Those numbers are folk wisdom, not Google policy.

Changes made for readiness:

- **Content:** 18 games, 12 articles, 5 category pages and a text section on every game page. Game pages now average about 340 visible words (minimum about 300) and articles about 420 (minimum about 330). That is decent but still **below the 600+ words some guides recommend**; add more original writing if you want to go further. No invented statistics, reviews or expert claims.
- **Trust pages:** About (how puzzles are made, funding, owner), Contact, Privacy Policy, Cookie Policy, Terms and a Data Deletion page, all linked from every footer, plus `sitemap.html`.
- **Technical:** responsive layout checked to 320px, `lang` and viewport on every page, unique titles and descriptions, `robots.txt` allows `Mediapartners-Google`, `ads.txt` template, XML and HTML sitemaps, breadcrumb structured data, and FAQ structured data matching visible FAQs.
- **Ad placement:** one slot per page, below games and away from controls, never on pages without publisher content.

**Things only you can do:** be 18+, choose and own a domain with HTTPS, apply for AdSense, put your name and contact email in `js/config.js`, add more original content over time, and have enough real visitors. Approval is Google's decision and nothing here guarantees it.

### Consent in the EEA, UK and Switzerland

Google requires a **Google-certified consent management platform (CMP)** to serve *personalised* ads there. The built-in banner is a genuine consent gate but is **not a certified CMP**. According to Google's guidance, ads can still run on traffic from uncertified tools, but not personalised. For personalised ads in those regions, use Google's Privacy & messaging tool or another certified CMP. US state laws (for example, California) may also need an opt-out link.

## Privacy, cookie, terms and deletion pages

| Page | Covers |
| --- | --- |
| `privacy.html` | what is stored, what is not collected, ad choices, hosting logs, rights, children, retention |
| `cookie-policy.html` | no first-party cookies; LocalStorage table; third-party ad cookies only with consent |
| `terms.html` | use of the site, entertainment-only notice, advertising and third parties, disclaimer |
| `data-deletion.html` | live list of saved data, JSON download, delete everything, withdraw ad consent, email request |

BrainGrid collects no names, emails, passwords or payment details, and uses no analytics. The deletion tools remove everything BrainGrid holds, instantly, because it lives only in the visitor's browser. Email forms only open a draft in the visitor's own email app. **These texts are a plain-language starting point, not legal advice.** Have them reviewed for your situation.

## LocalStorage

All keys begin with `braingrid_`:

| Key | Contents |
| --- | --- |
| `braingrid_daily` | `{ "YYYY-MM-DD": { logic: true, ... } }`, last 45 days |
| `braingrid_streak` | `{ count, last }` |
| `braingrid_best` | `{ "sudoku:easy": { score, label, dir: "low"/"high", date } }` |
| `braingrid_recent`, `braingrid_favs` | arrays of game ids |
| `braingrid_prefs` | `{ game: { level, ... }, site: { theme } }` |
| `braingrid_consent` | `{ ads: "all"/"nonpersonal"/"none", date }`, only written when ads are on |

Everything is validated on read. Corrupted or wrongly typed values fall back to defaults. If LocalStorage is blocked, data is kept in memory for that page and a footer notice appears.

## Daily Challenge and daily WordGrid

Both use the visitor's **local** date (`YYYY-MM-DD`) hashed into a seeded generator, so the same date gives the same puzzles on any device with this version of the site. People in different time zones can see different sets at the same moment; the site never claims otherwise. **Editing the puzzle banks or word list changes which puzzle a date maps to.**

## Adding content

- **Riddle:** add to `P.riddles` in `js/pools.js`. **Anagram word:** `P.anagrams`. **Number sequence:** `P.sequences`.
- **Logic grid:** add to `PUZZLES` in `js/puzzles/logic-grid.js`, then check `BG.games.logicGrid.countSolutions(...)` returns `count: 1` in the console.
- **Cipher sentence:** `SENTENCES` in `js/puzzles/cipher-quest.js`. **Word search theme:** `THEMES` in `js/puzzles/word-search.js`.
- **A new game:** copy a page in `games/`, add a script in `js/puzzles/`, add entries to `data/puzzles.json` and `js/catalog.js` (and an icon under `icons` there), then run the sitemap tool.
- **An article:** copy a file in `articles/`, then add it to `data/articles.json`, `js/catalog.js`, `articles.html`, `sitemap.html` and run the sitemap tool.

## Accessibility

Semantic landmarks and headings, a skip link, visible focus rings, labelled inputs, ARIA live regions for feedback, keyboard control for every game, text alternatives for Spot the Difference, no colour-only signals (marks and words accompany colours), reduced-motion support, a dark theme, and no flashing (Echo Sequence shows one pad at a time for at least 450 ms). Text contrast was machine-checked to WCAG AA in both themes. Real screen-reader testing has **not** been done.

## Honest limitations

- No shared leaderboard, accounts or cross-device sync (static site). Badges are computed on the device.
- Dense grids (Sudoku, Safe Sweep) have cells about 28 to 29px wide on a 320px phone, smaller than the 44px ideal; the WordGrid on-screen keys are about 25px wide there (typing on a physical keyboard also works).
- Logic Grid has three puzzles. Spot the Difference has one scene with changing details. Sudoku difficulty is by clue count only.
- WordGrid's guess list is broad (including obscure words) and its answer list is deliberately everyday.
- Ads, consent and legal texts are untested against a live AdSense account and have not been legally reviewed. Your publisher ID is in place, but no ad unit IDs are, so no ads will show yet.
- Canonical URLs and the sitemap use a placeholder domain until you run the domain tool.
