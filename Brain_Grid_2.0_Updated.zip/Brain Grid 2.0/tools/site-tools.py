#!/usr/bin/env python3
"""BrainGrid site tools (optional, standard library only; the website itself needs no build step).

  python3 tools/site-tools.py domain https://your-domain.com
      Replaces the YOUR-DOMAIN.example placeholder in every page, sitemap.xml and robots.txt,
      turns on the canonical <link> in each page and the Sitemap line in robots.txt.

  python3 tools/site-tools.py adsense ca-pub-XXXXXXXXXXXXXXXX
      Sets your AdSense publisher ID in js/config.js, ads.txt and the account meta tag of every page.

  python3 tools/site-tools.py sitemap [https://your-domain.com]
      Rebuilds sitemap.xml from the .html files that actually exist (404.html is left out).
      <lastmod> comes from each file's modified date. Run it again whenever you add or remove pages.
"""
import os, re, sys, datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PLACEHOLDER = 'https://YOUR-DOMAIN.example'

def html_files():
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if not d.startswith('.') and d != 'tools']
        for f in sorted(files):
            if f.endswith('.html'):
                yield os.path.relpath(os.path.join(base, f), ROOT).replace(os.sep, '/')

def read(p):
    with open(os.path.join(ROOT, p), encoding='utf-8') as fh: return fh.read()
def write(p, t):
    with open(os.path.join(ROOT, p), 'w', encoding='utf-8', newline='\n') as fh: fh.write(t)

def clean_domain(url):
    url = url.strip().rstrip('/')
    if not re.fullmatch(r'https?://[A-Za-z0-9.-]+(:\d+)?(/[A-Za-z0-9._~/-]*)?', url):
        sys.exit('Please give a full address such as https://www.example.com')
    return url

def cmd_domain(url):
    url = clean_domain(url)
    changed = 0
    for p in list(html_files()) + ['sitemap.xml', 'robots.txt']:
        t = read(p); n = t.replace(PLACEHOLDER, url)
        n = re.sub(r'<!-- (<link rel="canonical" href="[^"]+">) -->', r'\1', n)
        if p == 'robots.txt':
            n = n.replace('# Sitemap:', 'Sitemap:')
            n = re.sub(r'# After you choose a domain.*\n# \(it replaces.*\n', '', n)
        if p == 'sitemap.xml': n = re.sub(r'<!-- Replace https://.*?-->\n', '', n)
        if n != t: write(p, n); changed += 1
    print('Updated %d files for %s' % (changed, url))
    print('Next: upload the site, then submit %s/sitemap.xml in Google Search Console.' % url)

def cmd_adsense(pub):
    if not re.fullmatch(r'ca-pub-\d{10,20}', pub):
        sys.exit('Please give your publisher ID in the form ca-pub-1234567890123456')
    n = 0
    for p in html_files():
        t = read(p); u = re.sub(r'(<meta name="google-adsense-account" content=")[^"]*(">)', r'\g<1>' + pub + r'\g<2>', t)
        if u != t: write(p, u); n += 1
    c = read('js/config.js'); write('js/config.js', re.sub(r"(adsensePublisherId:\s*')[^']*(')", r'\g<1>' + pub + r'\g<2>', c))
    write('ads.txt', '# ads.txt for Google AdSense (publisher %s)\ngoogle.com, pub-%s, DIRECT, f08c47fec0942fa0\n' % (pub, pub[7:]))
    print('Updated %d pages, js/config.js and ads.txt for %s' % (n, pub))
    print('Ads stay off until you also add ad unit IDs (adSlots) or set autoAds to true in js/config.js.')

def cmd_sitemap(url=None):
    base = clean_domain(url) if url else PLACEHOLDER
    if not url:
        m = re.search(r'<loc>(https?://[^/<]+)/', read('sitemap.xml')) if os.path.exists(os.path.join(ROOT, 'sitemap.xml')) else None
        if m: base = m.group(1)
    rows = []
    for p in html_files():
        if p == '404.html': continue
        d = datetime.date.fromtimestamp(os.path.getmtime(os.path.join(ROOT, p))).isoformat()
        rows.append('  <url><loc>%s/%s</loc><lastmod>%s</lastmod></url>\n' % (base, p, d))
    head = '<?xml version="1.0" encoding="UTF-8"?>\n'
    if base == PLACEHOLDER: head += '<!-- Replace %s with your real domain: python3 tools/site-tools.py domain https://your-domain -->\n' % PLACEHOLDER
    write('sitemap.xml', head + '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + ''.join(rows) + '</urlset>\n')
    print('sitemap.xml written with %d pages (base %s)' % (len(rows), base))

if __name__ == '__main__':
    a = sys.argv[1:]
    if len(a) >= 2 and a[0] == 'domain': cmd_domain(a[1])
    elif len(a) >= 2 and a[0] == 'adsense': cmd_adsense(a[1])
    elif a and a[0] == 'sitemap': cmd_sitemap(a[1] if len(a) > 1 else None)
    else: print(__doc__)
